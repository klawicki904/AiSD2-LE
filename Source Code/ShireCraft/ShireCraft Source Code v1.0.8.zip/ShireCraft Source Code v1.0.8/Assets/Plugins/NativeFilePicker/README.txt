= Native File Picker for Android & iOS (v1.4.0) =

Documentation: https://github.com/yasirkula/UnityNativeFilePicker
FAQ: https://github.com/yasirkula/UnityNativeFilePicker#faq
Example code: https://github.com/yasirkula/UnityNativeFilePicker#example-code
E-mail: yasirkula@gmail.com