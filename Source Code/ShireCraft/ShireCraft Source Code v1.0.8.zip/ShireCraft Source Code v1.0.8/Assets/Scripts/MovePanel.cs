using UnityEngine;

public class MovePanel : MonoBehaviour
{
    [SerializeField] RectTransform rectTransform;
    public void MoveRectTransform(float newY) // used when switching tabs
    {
        rectTransform.localPosition = new(rectTransform.localPosition.x, newY);
    }
}
