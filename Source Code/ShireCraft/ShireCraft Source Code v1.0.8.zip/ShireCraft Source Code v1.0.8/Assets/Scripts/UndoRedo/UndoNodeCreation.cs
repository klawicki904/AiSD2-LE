using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class UndoNodeCreation : IUndoableAction
{
    // nodes must be searched for by their IDs, 
    // searching by reference causes issues because Redo() creates a new node,
    // which is later missing its reference in UndoNodeDeletion
    private int nodeID;
    // node's data
    private Vector2 position;
    private GraphNode.NodeType nodeType;
    private float capacity;
    // node's data: attached arrows
    private List<ArrowData> arrowsFromThis;
    private List<ArrowData> arrowsToThis;
    public UndoNodeCreation(GraphNode undoNode)
    {
        // remember ID on GraphManager.CreateNode
        nodeID = undoNode.nodeID;
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        // find node in GraphManager.nodeDictionary
        if (GraphManager.instance.TryGetNodeByID(nodeID, out var undoNode))
        {
            // remember node's data before deleting to undo/redo later
            position = undoNode.transform.position;
            nodeType = undoNode.GetNodeType();
            capacity = undoNode.GetCapacity();

            // save node's arrow connections
            arrowsFromThis = undoNode.GetArrowsFromThis()
                .Select(a => new ArrowData(a.arrowID, a.GetFromNode().nodeID, a.GetToNode().nodeID, a.GetFlow(), a.GetRepairCost())).ToList();

            arrowsToThis = undoNode.GetArrowsToThis()
                .Select(a => new ArrowData(a.arrowID, a.GetFromNode().nodeID, a.GetToNode().nodeID, a.GetFlow(), a.GetRepairCost())).ToList();
            // delete node
            GraphManager.instance.SelectNode(undoNode);
            GraphManager.instance.DeleteSelected(true); 
        }
    }
    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        // restore the node
        GraphNode restoredNode = GraphManager.instance.CreateNode(position, nodeType, capacity, true, nodeID);
        nodeID = restoredNode.nodeID;
        // restore outgoing arrows with their old IDs
        foreach (var arrow in arrowsFromThis)
        {
            if (GraphManager.instance.TryGetNodeByID(arrow.to, out var toNode))
                GraphManager.instance.CreateArrow(restoredNode, toNode, arrow.flow, arrow.repairCost, true, arrow.id);
        }

        // restore incoming arrows with their old IDs
        foreach (var arrow in arrowsToThis)
        {
            if (GraphManager.instance.TryGetNodeByID(arrow.from, out var fromNode))
                GraphManager.instance.CreateArrow(fromNode, restoredNode, arrow.flow, arrow.repairCost, true, arrow.id);
        }
    }

    private class ArrowData
    {
        public int id, from, to;
        public float flow;
        public uint repairCost;

        public ArrowData(int id, int from, int to, float flow, uint repairCost)
        {
            this.id = id;
            this.from = from;
            this.to = to;
            this.flow = flow;
            this.repairCost = repairCost;
        }
    }
}

