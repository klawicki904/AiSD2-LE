using UnityEngine;
/// <summary>
/// Undo-Redo definition for updating arrow's values via the (Element) Arrow Info Panel
/// </summary>
public class UndoArrowUpdate : IUndoableAction
{
    readonly int arrowID;
    float flow;
    uint repairCost;

    public UndoArrowUpdate(GraphArrow arrow)
    {
        arrowID = arrow.arrowID;
        // constructor is called before the type is updated, so this saves the data the undo needs to revert to
        flow = arrow.GetFlow();
        repairCost = arrow.GetRepairCost();
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        if (GraphManager.instance.TryGetArrowByID(arrowID, out var undoArrow))
        {
            // remember new data for swapping
            float newFlow = undoArrow.GetFlow();
            uint newRepairCost = undoArrow.GetRepairCost();

            // update arrow with saved data
            undoArrow.SetArrowData(flow, repairCost);

            // save new data for potential Redo
            flow = newFlow;
            repairCost = newRepairCost;
        }

    }
    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        Undo();
    }
}
