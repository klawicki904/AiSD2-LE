using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class UndoNodeDeletion : IUndoableAction
{
    // arrows must be searched for by their IDs, 
    // searching by reference causes issues because Undo() creates a new node,
    // which is later missing its reference in UndoNodeCreation
    private int nodeID;
    // node's data
    private Vector2 position;
    private readonly GraphNode.NodeType nodeType;
    private readonly float capacity;
    // node's data: attached arrows
    private readonly List<ArrowData> arrowsFromThis;
    private readonly List<ArrowData> arrowsToThis;


    public UndoNodeDeletion(GraphNode undoNode)
    {
        // remember node's data to undo/redo later
        nodeID = undoNode.nodeID;
        position = undoNode.transform.position;
        nodeType = undoNode.GetNodeType();
        capacity = undoNode.GetCapacity();

        // save node's arrow connections
        arrowsFromThis = undoNode.GetArrowsFromThis()
            .Select(a => new ArrowData(a.arrowID, a.GetFromNode().nodeID, a.GetToNode().nodeID, a.GetFlow(), a.GetRepairCost())).ToList();

        arrowsToThis = undoNode.GetArrowsToThis()
            .Select(a => new ArrowData(a.arrowID, a.GetFromNode().nodeID, a.GetToNode().nodeID, a.GetFlow(), a.GetRepairCost())).ToList();
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        // restore the node
        GraphNode restoredNode = GraphManager.instance.CreateNode(position, nodeType, capacity, true, nodeID);
        nodeID = restoredNode.nodeID;
        // restore outgoing arrows
        foreach (var arrow in arrowsFromThis)
        {
            if (GraphManager.instance.TryGetNodeByID(arrow.to, out var toNode))
                GraphManager.instance.CreateArrow(restoredNode, toNode, arrow.flow, arrow.repairCost, true, arrow.id);
        }

        // restore incoming arrows
        foreach (var arrow in arrowsToThis)
        {
            if (GraphManager.instance.TryGetNodeByID(arrow.from, out var fromNode))
                GraphManager.instance.CreateArrow(fromNode, restoredNode, arrow.flow, arrow.repairCost, true, arrow.id);
        }
    }

    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        // delete node, the arrows connected to it were saved earlier
        if (GraphManager.instance.TryGetNodeByID(nodeID, out var node))
        {
            GraphManager.instance.SelectNode(node);
            GraphManager.instance.DeleteSelected(true);
        }
    }

    private class ArrowData
    {
        public int id, from, to;
        public float flow;
        public uint repairCost;

        public ArrowData(int id, int from, int to, float flow, uint repairCost)
        {
            this.id = id;
            this.from = from;
            this.to = to;
            this.flow = flow;
            this.repairCost = repairCost;
        }
    }
}
