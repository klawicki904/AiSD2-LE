using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Localization;

public class RandomizeTooltipOnHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] LocalizedString[] tooltipsPool;
    public void OnPointerEnter(PointerEventData eventData)
    {
        TooltipObjectSetter.instance.gameObject.SetActive(true);
        TooltipObjectSetter.instance.SetTooltipText(tooltipsPool[Random.Range(0, tooltipsPool.Length)].GetLocalizedString());
        TooltipObjectSetter.instance.UpdatePosition(transform);
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        TooltipObjectSetter.instance.gameObject.SetActive(false);
    }
}
