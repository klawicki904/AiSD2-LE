using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class FileTooLargeText : MonoBehaviour
{
    public static FileTooLargeText instance { get; private set; }
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }
    public void OpenAutosaveFile()
    {
        Application.OpenURL(FileToTMPInput.autosaveFilePath);
    }
    public void OpenSolutionFile()
    {
        Application.OpenURL(FileToTMPInput.simulationFilePath);
    }
}
