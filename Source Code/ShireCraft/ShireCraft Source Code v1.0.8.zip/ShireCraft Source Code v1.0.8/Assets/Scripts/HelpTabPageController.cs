using TMPro;
using UnityEngine;
using UnityEngine.Localization;

public class HelpTabPageController : MonoBehaviour
{
    [SerializeField] GameObject[] pages;
    [SerializeField] LocalizedString[] pageNames;
    [SerializeField] TextMeshProUGUI currentPageNameText;
    private void Awake()
    {
        pageNames[0].StringChanged += UpdatePageNameText;
    }
    public void PreviousPage()
    {
        for (int i=0; i<pages.Length; i++)
        {
            if (pages[i].activeSelf)
            {
                //Debug.Log($"pages[{i}] is active ({pages[i].name})");
                pages[i].SetActive(false);
                if (i == 0)
                {
                    i += pages.Length; // % doesn't work on negative numbers, so moving i to the end manually before subtracting
                }
                //Debug.Log($"switching to pages[{(i - 1) % pages.Length}] ({pages[(i - 1) % pages.Length].name})");
                pages[(i - 1) % pages.Length].SetActive(true);
                //currentPageNameText.SetText(pages[(i - 1) % pages.Length].name);
                pageNames[(i - 1) % pages.Length].StringChanged += UpdatePageNameText;
                break;
            }
        }
    }
    public void NextPage()
    {
        for (int i = 0; i < pages.Length; i++)
        {
            if (pages[i].activeSelf)
            {
                pages[i].SetActive(false);
                pages[(i + 1) % pages.Length].SetActive(true);
                pageNames[(i + 1)%pages.Length].StringChanged += UpdatePageNameText;
                break;
            }
        }
    }
    private void UpdatePageNameText(string localizedText)
    {
        currentPageNameText.text = localizedText;
    }
}
