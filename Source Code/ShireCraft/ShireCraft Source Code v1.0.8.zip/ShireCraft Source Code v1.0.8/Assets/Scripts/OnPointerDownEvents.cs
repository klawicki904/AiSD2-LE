using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class OnPointerDownEvents : MonoBehaviour, IPointerDownHandler
{
    [SerializeField] UnityEvent onPointerDown = new();

    public void OnPointerDown(PointerEventData eventData)
    {
        onPointerDown.Invoke();
    }
}
