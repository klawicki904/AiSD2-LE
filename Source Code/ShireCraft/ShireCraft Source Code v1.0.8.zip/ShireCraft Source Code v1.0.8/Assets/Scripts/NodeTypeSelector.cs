using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class NodeTypeSelector : MonoBehaviour
{
    [SerializeField] List<Button> buttons;
    [SerializeField] Transform currentlySelectedHandle;
    [SerializeField] int minValue = 0;
    [SerializeField] int maxValue = 4;
    public int value /*{ get; private set; }*/  = 0;
    [SerializeField] Color defaultColor = Color.white;
    [SerializeField] Color selectedColor = Color.white;
    [SerializeField] UnityEvent onValueChangedAfterValidation = new();
    public void SetValue(int newValue)
    {
        if(newValue < minValue) newValue = minValue;
        if(newValue > maxValue) newValue = maxValue;
        currentlySelectedHandle.position = buttons[newValue].transform.position;
        buttons[value].GetComponent<Image>().color = defaultColor;
        buttons[newValue].GetComponent<Image>().color = selectedColor;
        if (value != newValue)
        {
            value = newValue;
        }
        onValueChangedAfterValidation.Invoke();
    }
    public void SetValueWithoutNotify(int newValue)
    {
        if (newValue < minValue) newValue = minValue;
        if (newValue > maxValue) newValue = maxValue;
        currentlySelectedHandle.position = buttons[newValue].transform.position;
        buttons[value].GetComponent<Image>().color = defaultColor;
        buttons[newValue].GetComponent<Image>().color = selectedColor;
        if (value != newValue)
        {
            value = newValue;
        }
    }
    public void SetInteractable(bool interactable)
    {
        for (int i=minValue; i<maxValue; i++)
        {
            buttons[i].interactable = interactable;
        }
    }
}
