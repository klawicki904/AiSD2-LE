using UnityEngine;
using System.Threading;
using UnityEngine.Localization;

public class LoadingScreenText : MonoBehaviour
{
    [SerializeField] float refreshDelay = 1f;
    [SerializeField] TMPro.TextMeshProUGUI progressInfoText;
    [SerializeField] TMPro.TextMeshProUGUI funFactText;
    [SerializeField] LocalizedString[] funFacts;
    [SerializeField] LocalizedString emptyLocalizedStringText;
    [SerializeField] LocalizedString preparingText;
    [SerializeField] LocalizedString clearingGraphText;
    [SerializeField] LocalizedString generatingGraphText;
    [SerializeField] LocalizedString generatingNodesText;
    [SerializeField] LocalizedString generatingArrowsText;
    [SerializeField] LocalizedString generatingQuartersText;
    [SerializeField] LocalizedString generatingRoutesText;
    [SerializeField] LocalizedString verifyingNodesText;
    [SerializeField] LocalizedString synchronizingText;
    [SerializeField] LocalizedString launchingExternalProgramText;
    int lastFunFact = -1;
    CancellationTokenSource cancellationTokenSource;
    public static LoadingScreenText instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
        lastFunFact = Random.Range(0, funFacts.Length);
    }
    public enum OperationState
    {
        preparing,
        clearingGraph,
        generatingGraph,
        generatingNodes,
        generatingArrows,
        generatingQuarters,
        generatingRoutes,
        synchronizing,
        verifyingNodes,
        launchingExternalProgram
    }
    public static OperationState currentOperationState = OperationState.preparing;

    /*private void OnEnable()
    {
        UpdateProgressText();
    }*/
    public void SetOperationState(OperationState newOperationState)
    {
        currentOperationState = newOperationState;
    }
    public async void UpdateProgressText()
    {
        CancelPreviousAsync();
        CancellationToken token = cancellationTokenSource.Token;
        DisplayFunFactAsync(token);
        while (!token.IsCancellationRequested && progressInfoText.gameObject.activeInHierarchy)
        {
            switch (currentOperationState)
            {
                case OperationState.preparing:
                {
                    PreparingMessage();
                    break;
                }
                case OperationState.clearingGraph:
                {
                    //progressInfoText.SetText("Clearing graph");
                    ClearingGraphMessage();
                    break;
                }
                case OperationState.generatingGraph:
                    {
                        GeneratingGraphMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount());
                        break;
                    }
                case OperationState.generatingNodes:
                {
                        GeneratingNodesMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount());
                    break;
                }
                case OperationState.generatingArrows:
                    {
                        GeneratingArrowsMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount());
                        break;
                    }
                case OperationState.generatingQuarters:
                    {
                        GeneratingQuartersMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount(), GraphManager.instance.GetQuartersCount());
                        break;
                    }
                case OperationState.generatingRoutes:
                    {
                        GeneratingRoutesMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount(), GraphManager.instance.GetQuartersCount());
                        break;
                    }
                    case OperationState.synchronizing:
                    {
                            SynchronizingMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount(), GraphManager.instance.GetQuartersCount());
                        break;
                    }
                case OperationState.verifyingNodes:
                    {
                        VerifyingNodesMessage(GraphManager.instance.GetNodesCount(), GraphManager.instance.GetArrowsCount(), GraphManager.instance.GetQuartersCount());
                        break;
                    }
                case OperationState.launchingExternalProgram:
                    {
                            LaunchingExternalProgramMessage();
                        /*progressInfoText.SetText($"Launching external program");*/
                        break;
                    }
                }
            try { await Awaitable.WaitForSecondsAsync(refreshDelay, token); } catch { return; }
            //try { await Awaitable.EndOfFrameAsync(token); } catch { return; }
        }
        CancelPreviousAsync();
    }
    async void DisplayFunFactAsync(CancellationToken token)
    {
        while (funFactText.gameObject.activeInHierarchy)
        {
            try { await Awaitable.WaitForSecondsAsync(6f, token); } catch { return; }
            float fadeDuration = 1f;
            float fadeTime = 0f;
            Color originalColor = funFactText.color;
            // fade out
            if (funFactText.color.a > 0f)
            {
                while (fadeTime < fadeDuration)
                {
                    if (token.IsCancellationRequested) return;
                    fadeTime += Time.deltaTime;
                    float alpha = Mathf.Lerp(1f, 0f, fadeTime / fadeDuration);
                    funFactText.color = new Color(originalColor.r, originalColor.g, originalColor.b, alpha);
                    try { await Awaitable.NextFrameAsync(token); } catch { return; }
                }
            }

            // set new fun fact
            UpdateFunFactText(funFacts[(lastFunFact++) % funFacts.Length].GetLocalizedString());

            // fade in
            fadeTime = 0f;
            while (fadeTime < fadeDuration)
            {
                if (token.IsCancellationRequested) return;
                fadeTime += Time.deltaTime;
                float alpha = Mathf.Lerp(0f, 1f, fadeTime / fadeDuration);
                funFactText.color = new Color(originalColor.r, originalColor.g, originalColor.b, alpha);
                try { await Awaitable.NextFrameAsync(token); } catch { return; }
            }
        }
    }
    void PreparingMessage()
    {
        UpdateStatusText(preparingText.GetLocalizedString());
    }
    void ClearingGraphMessage()
    {
        UpdateStatusText(clearingGraphText.GetLocalizedString());
    }
    void GeneratingGraphMessage(int nodesCount, int arrowsCount)
    {
        generatingGraphText.Arguments = new object[] { nodesCount, arrowsCount };
        UpdateStatusText(generatingGraphText.GetLocalizedString());
    }
    void GeneratingNodesMessage(int nodesCount, int arrowsCount)
    {
        generatingNodesText.Arguments = new object[] { nodesCount, arrowsCount };
        UpdateStatusText(generatingNodesText.GetLocalizedString());
    }
    void GeneratingArrowsMessage(int nodesCount, int arrowsCount)
    {
        generatingArrowsText.Arguments = new object[] { nodesCount, arrowsCount };
        UpdateStatusText(generatingArrowsText.GetLocalizedString());
    }
    void GeneratingQuartersMessage(int nodesCount, int arrowsCount, int quartersCount)
    {
        generatingQuartersText.Arguments = new object[] { nodesCount, arrowsCount, quartersCount };
        UpdateStatusText(generatingQuartersText.GetLocalizedString());
    }
    void GeneratingRoutesMessage(int nodesCount, int arrowsCount, int quartersCount)
    {
        generatingRoutesText.Arguments = new object[] { nodesCount, arrowsCount, quartersCount };
        UpdateStatusText(generatingRoutesText.GetLocalizedString());
    }

    void SynchronizingMessage(int nodesCount, int arrowsCount, int quartersCount)
    {
        synchronizingText.Arguments = new object[] { nodesCount, arrowsCount, quartersCount };
        UpdateStatusText(synchronizingText.GetLocalizedString());
    }
    void VerifyingNodesMessage(int nodesCount, int arrowsCount, int quartersCount)
    {
        synchronizingText.Arguments = new object[] { nodesCount, arrowsCount, quartersCount };
        UpdateStatusText(synchronizingText.GetLocalizedString());
    }
    void LaunchingExternalProgramMessage()
    {
        //generatingGraphText.StringChanged += UpdateStatusText;
        UpdateStatusText(launchingExternalProgramText.GetLocalizedString());
    }

    void UpdateStatusText(string localizedText)
    {
        progressInfoText.text = localizedText;
        //UpdateProgressText(currentOperationState);
    }
    void UpdateFunFactText(string localizedText)
    {
        funFactText.text = localizedText;
        //UpdateProgressText(currentOperationState);
    }

    public void SetLoadingScreenRefreshDelay(float newRefreshDelay)
    {
        refreshDelay = newRefreshDelay;
    }
    public void CancelPreviousAsync()
    {
        if (cancellationTokenSource != null)
        {
            cancellationTokenSource.Cancel();
            cancellationTokenSource.Dispose();
        }
        cancellationTokenSource = new CancellationTokenSource();
        funFactText.SetText(emptyLocalizedStringText.GetLocalizedString());
        UpdateStatusText(emptyLocalizedStringText.GetLocalizedString());
        funFactText.color = new(funFactText.color.r, funFactText.color.g, funFactText.color.b, 0f);
    }
}
