using UnityEngine;
using System.Diagnostics;

public class GraphSimulation : MonoBehaviour
{
    public void Simulate()
    {
        ProcessStartInfo startInfo = new()
        {
            FileName = "C:/Unity Projects/AiSD-GUI/CPP test/wordCounter.exe",
            Arguments = FileToTMPInput.autosaveFilePath
        };
        Process.Start(startInfo);
        
    }
}
