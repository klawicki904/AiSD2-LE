using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using TMPro;
using System.Collections;

public class GraphNode : MonoBehaviour
{
    public enum NodeType
    {
        [InspectorNameAttribute("None")] brak,
        [InspectorNameAttribute("Field")] pole,
        [InspectorNameAttribute("Brewery")] browar,
        [InspectorNameAttribute("Pub")] karczma,
        [InspectorNameAttribute("Quarter")] cwiartka,

    }
    public int nodeID;

    public static int nextID = 1;

    //[SerializeField] GraphManager graphManager;
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] CircleCollider2D thisCollider;
    [SerializeField] SpriteRenderer selectedIcon;
    [SerializeField] SpriteRenderer multiSelectedIcon;
    [SerializeField] List<GraphArrow> arrowsFromThis = new();
    [SerializeField] List<GraphArrow> arrowsToThis = new();
    [SerializeField] TextMeshPro capacityText;
    //[SerializeField] Vector2 nodePosition = Vector2.zero;
    public static bool generatingGraph;
    [SerializeField] NodeType nodeType = NodeType.brak;
    [SerializeField] float capacity = 0f;

    public List<Collider2D> redNodes = new();

    private void Awake()
    {
        nodeID = nextID++;
    }
    // assign ID manually (for undo/redo)
    public void SetNodeID(int id)
    {
        nodeID = id;
        if (id >= nextID)
        { nextID = id + 1; }
    }
    public void AddArrowFromThis(GraphArrow arrow)
    {
        arrowsFromThis.Add(arrow);
    }
    public void AddArrowToThis(GraphArrow arrow)
    {
        arrowsToThis.Add(arrow);
    }
    public void RemoveArrow(GraphArrow arrow)
    {
        arrowsFromThis.Remove(arrow);
        arrowsToThis.Remove(arrow);
    }
    public void UpdateNode(Vector2 newPosition, NodeType nodeType, float capacity)
    {
        MoveNode(newPosition);
        ChangeNodeType(nodeType);
        SetCapacity(capacity);
    }
    public void MoveNode(Vector2 newPosition, float? forcedGridSize = null)
    {
        //Debug.Log(gameObject.gameObject.name + ": MoveNode");
        /*if (graphManager.GetDragThreshold() && Vector3.Distance(transform.position, (Vector3)newPosition) < graphManager.GetDragThresholdValue())
        { return; } // don't move node unless dragging*/
        float gridSize;
        if (forcedGridSize.HasValue)
        {
            gridSize = forcedGridSize.Value;
        }
        else
        {
            if (GraphManager.instance.GetSnapToGrid())
            {
                gridSize = GraphManager.instance.GetGridSize();
            }
            else
            {
                gridSize = 0.01f;
            }
        }

        //Vector2 centerPosition = graphManager.GetContentPosition();

        //Vector2 distanceFromCenter = newPosition - centerPosition;
        newPosition = new((float)System.Math.Round(Mathf.Round(newPosition.x / gridSize) * gridSize, 2),
                        (float)System.Math.Round(Mathf.Round(newPosition.y / gridSize) * gridSize, 2));
        /*newPosition = new(Mathf.Round(newPosition.x / gridSize) * gridSize,
                            Mathf.Round(newPosition.y / gridSize) * gridSize);*/

        //MoveNode(eventData.position);


        /*if (newPosition == (Vector2)transform.position) { return; }*/

        transform.position = newPosition;
        // update the quarter area this node belongs to
        if (nodeType == NodeType.cwiartka)
        {
            QuarterArea quarterArea = GraphManager.instance.GetQuarterAreaByBorderNode(this);
            if (quarterArea != null) { quarterArea.UpdateColliderPointsAndDraw(); }
        }
        // update arrows' positions for the new position of the node
        foreach (GraphArrow arrow in arrowsFromThis)
        {
            arrow.UpdatePosition();
        }
        foreach (GraphArrow arrow in arrowsToThis)
        {
            arrow.UpdatePosition();
        }
    }
    public void ChangeNodeType(NodeType nodeType)
    {
        //Debug.Log(gameObject.name + ": ChangeNodeType");
        this.nodeType = nodeType;
        transform.GetChild(0).GetComponent<SpriteRenderer>().sprite = GraphManager.instance.GetNodeSprite((int)nodeType);
        if (this.nodeType == NodeType.pole)
        {
            capacityText.gameObject.SetActive(true);
            CheckIfInsideQuarter();
        }
        else if(this.nodeType == NodeType.browar)
        {
            capacityText.gameObject.SetActive(true);
        }
        else
        {
            capacityText.gameObject.SetActive(false);
            //capacity = 0;
            //capacityText.SetText("0");
        }
        // update colors of all arrows coming from this node
        foreach (GraphArrow arrow in arrowsFromThis)
        {
            arrow.UpdateArrowColor();
        }
        CheckIfCorrectPosition();
    }
    /*public void SetFlow(GraphArrow arrow)
    {
        //Debug.Log(gameObject.name + ": SetFlow");
        if (arrow.GetFromNode().GetNodeType() == NodeType.pole ||
            arrow.GetFromNode().GetNodeType() == NodeType.browar)
        {
            arrow.SetArrowData(arrow.GetFromNode().GetCapacity());
        }
    }*/
    /*public void GenerateFlows()
    {
        //Debug.Log(gameObject.name + ": GenerateFlows");
        //Debug.Log(gameObject.gameObject.name + "GenerateFlows");
        foreach (GraphArrow arrow in arrowsFromThis)
        {
            SetFlow(arrow);
        }
    }*/
    public void CheckIfCorrectPosition()
    {
        if(generatingGraph) { return; }
        /*Debug.Log(gameObject.name + ": CheckIfCorrectPosition");*/
        // check if a node already exists in the same position
        bool wrongPosition = false;

        // check if field inside quarter area
        if (nodeType == NodeType.pole)
        {
            Collider2D[] collidingAreas;
            collidingAreas = Physics2D.OverlapPointAll(transform.position, GraphInputManager.instance.GetIgnoreRaycastLayer());

            wrongPosition = collidingAreas.Length == 0;

        }

        if (!wrongPosition)
        {
            // find all nodes in the exact same position
            Collider2D[] colliders = Physics2D.OverlapPointAll(transform.position, GraphInputManager.instance.GetNodesLayer());
            // check each node collider
            for (int i = 0; i < colliders.Length; i++)
            {
                // if node collider has the same position as this node and the node is not itself
                if (colliders[i].transform.position == transform.position && colliders[i] != thisCollider)
                {
                    // allow for quarter nodes to overlap regular nodes
                    if ((nodeType != NodeType.cwiartka || colliders[i].GetComponent<GraphNode>().GetNodeType() == NodeType.cwiartka) &&
                            (nodeType == NodeType.cwiartka || colliders[i].GetComponent<GraphNode>().GetNodeType() != NodeType.cwiartka))
                    {
                        wrongPosition = true; // wrongPosition detected
                                              // mark in the manager that this node is marked red
                        if (!GraphManager.instance.GetRedNodes().Contains(this)) { GraphManager.instance.GetRedNodes().Add(this); }

                        // if the list doesn't already contain the other node
                        if (!redNodes.Contains(colliders[i]))
                        {
                            redNodes.Add(colliders[i]); // add the other node to the list
                            colliders[i].GetComponent<SpriteRenderer>().color = new Color(1f, 0f, 0f, colliders[i].GetComponent<SpriteRenderer>().color.a); // change its color to red
                        }
                    }
                }
            }
        }

        
        if (wrongPosition)
        {
            spriteRenderer.color = new Color(1f, 0f, 0f, spriteRenderer.color.a); // mark this node red
            if (!GraphManager.instance.GetRedNodes().Contains(this))
            {
                GraphManager.instance.GetRedNodes().Add(this);
            }
        }
        else // only when no nodes collide with the selected one
        {
            // check the list
            foreach (Collider2D red in redNodes)
            {
                //if (red.transform.position != transform.position) // if the other node no longer has the same position
                //{
                    //red.GetComponent<SpriteRenderer>().color = Color.white; // mark it white
                if (red)
                {
                    red.GetComponent<GraphNode>().redNodes.Remove(thisCollider); // remove this collider from the other node's list (otherwise infinite loop in next line)
                    red.GetComponent<GraphNode>().CheckIfCorrectPosition(); // check if the unmarked node actually has no collisions (if 3 or more were stacked)
                }
                    
                //}
            }
            redNodes.Clear(); // clear the list with wrongPosition nodes for this node
            GraphManager.instance.GetRedNodes().Remove(this); // unmark in the manager that this node is marked red
            
            spriteRenderer.color = (nodeType == NodeType.cwiartka) ? new Color(0f, 1f, 0f, spriteRenderer.color.a) : new Color(1f, 1f, 1f, spriteRenderer.color.a); // return node to its original color
            
        }
    }
    // had to move destroying attached arrows to before OnDestroy
    // to make undo and redo working
    public void BeforeDestroy()
    {
        if (!generatingGraph) // is true OnApplicationQuit
        {
            foreach (GraphArrow arrow in arrowsFromThis)
            {
                //GraphManager.instance.RemoveArrow(arrow);
                //arrowsFromThis.Remove(arrow);
                if (arrow) { Destroy(arrow.gameObject); }
            }
            foreach (GraphArrow arrow in arrowsToThis)
            {
                //GraphManager.instance.RemoveArrow(arrow);
                //arrowsToThis.Remove(arrow);
                if (arrow) { Destroy(arrow.gameObject); }
            }
            /*foreach (Collider2D red in redNodes)
            {
                red.GetComponent<GraphNode>().redNodes.Remove(thisCollider);
            }*/
        }
    }
    
    private void OnDestroy()
    {
        if (!generatingGraph) // is true OnApplicationQuit
        {
            Debug.Log(gameObject.gameObject.name + "OnDestroy");
            Collider2D[] reds = redNodes.ToArray();
            //GraphManager.instance.RemoveNode(this);
            foreach (Collider2D red in reds)
            {
                if (red)
                {
                    redNodes.Remove(red);
                    red.GetComponent<GraphNode>().redNodes.Remove(thisCollider); // remove this collider from the other node's list (otherwise infinite loop in next line)
                    red.GetComponent<GraphNode>().CheckIfCorrectPosition(); // check if the unmarked node actually has no collisions (if 3 or more were stacked)
                }
            }
            GraphManager.instance.GetRedNodes().Remove(this);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (thisCollider.IsTouchingLayers(GraphInputManager.instance.GetNodesLayer()))
        {
            //Debug.Log(name+": touching nodes layer");
            spriteRenderer.color = new(spriteRenderer.color.r, spriteRenderer.color.g, spriteRenderer.color.b, 0.5f);
        }
        else
        {
            //Debug.Log(name+ ": not touching nodes layer");
            spriteRenderer.color = new(spriteRenderer.color.r, spriteRenderer.color.g, spriteRenderer.color.b, 1f);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (thisCollider.IsTouchingLayers(GraphInputManager.instance.GetNodesLayer()))
        {
            //Debug.Log(gameObject.name + ": touching nodes layer");
            spriteRenderer.color = new(spriteRenderer.color.r, spriteRenderer.color.g, spriteRenderer.color.b, 0.5f);
        }
        else
        {
            //Debug.Log(gameObject.name + ": not touching nodes layer");
            spriteRenderer.color = new(spriteRenderer.color.r, spriteRenderer.color.g, spriteRenderer.color.b, 1f);
        }
    }

    public float GetX() { return transform.localPosition.x; }
    public float GetY() { return transform.localPosition.y; }
    public NodeType GetNodeType() { return nodeType; }
    public float GetCapacity() { return capacity; }
    public void SetCapacity(float capacity)
    {
        //Debug.Log(gameObject.name + ": SetCapacity");
        switch (nodeType)
        {
            case NodeType.pole:
            case NodeType.browar:
            case NodeType.cwiartka:
                {
                    this.capacity = capacity;
                    capacityText.SetText(capacity.ToString());
                    break;
                }
            default: break;
        }
    }

    public static NodeType GetNodeTypeByName(string name)
    {
        switch (name)
        {
        case "pole": return NodeType.pole;
            case "browar": return NodeType.browar;
            case "karczma": return NodeType.karczma;
            case "brak":
            case "skrzy�owanie": return NodeType.brak;
            default: break;
        }
        return NodeType.brak;
    }

    public void CheckIfInsideQuarter()
    {
        // check for overlapping quarters
        Collider2D[] results = Physics2D.OverlapPointAll(transform.position, GraphInputManager.instance.GetIgnoreRaycastLayer());
        Debug.Log(gameObject.name + ": quarter areas at " + transform.position + ": " + results.Length);
        if (results.Length == 1 && results[0].TryGetComponent(out QuarterArea quarterArea))
        {
            quarterArea.UpdateFieldsYield();
        }
    }
    public bool HasArrows() { return arrowsFromThis.Count > 0 || arrowsToThis.Count > 0; }
    public GraphArrow GetFirstArrowFromThis() { return arrowsFromThis[0]; }
    public List<GraphArrow> GetArrowsFromThis() { return arrowsFromThis; }
    public List<GraphArrow> GetArrowsToThis() { return arrowsToThis; }
    public void SetSelectedIconState(bool state) { selectedIcon.enabled = state; }
    public void SetMultiSelectedIconState(bool state) { multiSelectedIcon.enabled = state; }
    Vector3 GetMousePosition => Camera.main.ScreenToWorldPoint(Mouse.current.position.ReadValue());
}
