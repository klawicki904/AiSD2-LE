using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

public class OnClickUnityEvents : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] UnityEvent onClick = new();
    public void OnPointerClick(PointerEventData eventData)
    {
        onClick.Invoke();
    }
}