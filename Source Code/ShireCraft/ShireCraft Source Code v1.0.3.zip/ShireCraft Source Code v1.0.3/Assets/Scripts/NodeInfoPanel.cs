using UnityEngine;
using TMPro;

public class NodeInfoPanel : MonoBehaviour
{
    public TMP_InputField xPosition;
    public TMP_InputField yPosition;
    public NodeTypeSelector nodeTypeSelector;
    public TMP_InputField capacity;
    public UnityEngine.UI.Image capacityImage;
    public UnityEngine.UI.Image yieldImage;
}
