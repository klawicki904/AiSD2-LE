using UnityEngine;

public class UndoQuarterAreaCreation : IUndoableAction
{
    //QuarterArea quarterArea;
    NodeData[] quarterNodes;
    float quarterValue;
    public UndoQuarterAreaCreation(QuarterArea quarterArea)
    {
        // save quarter area reference
        //this.quarterArea = quarterArea;
        //quarterArea = this.quarterArea;
        // save quarter nodes IDs and positions
        quarterNodes = new NodeData[quarterArea.quarterNodes.Count];
        Debug.Log("quarterArea.quarterNodes.Count: " + quarterArea.quarterNodes.Count);
        for (int i=0; i<quarterArea.quarterNodes.Count; i++)
        {
            quarterNodes[i] = new NodeData(quarterArea.quarterNodes[i].nodeID, quarterArea.quarterNodes[i].transform.position);
            Debug.Log($"quarterNodes[{i}]: {quarterNodes[i].id}, {quarterNodes[i].position}");
        }

    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        /*for (int i = 0; i < quarterArea.quarterNodes.Count; i++)
        {
            Debug.Log($"quarterNodes[{i}]: {quarterNodes[i].id}, {quarterNodes[i].position}");
        }*/
        if (GraphManager.instance.TryGetNodeByID(quarterNodes[0].id, out GraphNode undoNode))
        {
            quarterValue = undoNode.GetCapacity();
            Debug.Log("undoNode: " + undoNode.name +", " + undoNode.nodeID);
            GraphManager.instance.SelectNode(undoNode);
            GraphManager.instance.DeleteSelected(true);
        }
    }

    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        // recreate all nodes, then recreate quarte area
        foreach (NodeData nodeData in quarterNodes)
        {
            GraphManager.instance.CreateNode(nodeData.position, GraphNode.NodeType.cwiartka, quarterValue, true, nodeData.id);
        }
        if (GraphManager.instance.TryGetNodeByID(quarterNodes[0].id, out GraphNode undoNode))
        {
            GraphManager.instance.CreateArrowInput(undoNode, true);
            //quarterArea = GraphManager.instance.GetQuarterAreaByBorderNode(undoNode); // remember recreated quarter area
        }
    }
    class NodeData
    {
        public int id;
        public Vector2 position;
        public NodeData(int id, Vector2 position)
        {
            this.id = id;
            this.position = position;
        }
    }
}

