using UnityEngine;
using UnityEngine.EventSystems;

public class DeselectEventSystemObjectOnClick : MonoBehaviour, IPointerClickHandler
{
    public void DeselectEventSystem()
    {
        EventSystem.current.SetSelectedGameObject(null);
    }
    public void OnPointerClick(PointerEventData _)
    {
        DeselectEventSystem();
    }
}