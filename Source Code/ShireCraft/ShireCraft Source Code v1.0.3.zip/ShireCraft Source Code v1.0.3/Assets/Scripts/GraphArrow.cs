using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

public class GraphArrow : MonoBehaviour/*, IPointerDownHandler*/
{
    public int arrowID;

    public static int nextID = 1;
    //[SerializeField] GraphManager graphManager;
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] SpriteRenderer outlineSpriteRenderer;
    [SerializeField] RectTransform labelAnchor;
    [SerializeField] TextMeshPro valueText;
    [SerializeField] GraphNode fromNode;
    [SerializeField] GraphNode toNode;
    [SerializeField] float flow = 0f;
    [SerializeField] uint repairCost = 0;
    static float offsetRadius = 0.45f;
    private void Awake()
    {
        arrowID = nextID++;
        gameObject.name += arrowID;
        spriteRenderer.color = new(Random.Range(0.2f, 1f), Random.Range(0.2f, 1f), Random.Range(0.2f, 1f));
        
    }
    // assign ID manually (for undo/redo)
    public void SetArrowID(int id)
    {
        arrowID = id;
        if (id >= nextID)
        { nextID = id + 1; }
    }
    /*public void OnPointerDown(PointerEventData eventData)
    {
        *//*Debug.Log(gameObject.name + ": OnPointerDown");*//*

        GraphManager.instance.SelectArrow(this);
    }*/
    public GraphNode GetFromNode() { if (fromNode) { return fromNode; } else { return null; } }
    public void SetFromNode(GraphNode node)
    {
        fromNode = node;
    }
    public GraphNode GetToNode() { return toNode; }
    public void SetToNode(GraphNode node)
    {
        toNode = node;
    }
    public void SetArrowData(float flow = float.MinValue, uint repairCost = uint.MaxValue)
    {
        /*Debug.Log(gameObject.name + ": SetArrowData");*/
        if (flow != float.MinValue) { this.flow = Mathf.Floor(flow * 100f) / 100f; }
        if (repairCost != uint.MaxValue) { this.repairCost = repairCost; }
        valueText.text = GetFlow().ToString() + "; " + GetRepairCost().ToString();
    }
    public static void UpdateOffsetRadius(float newRadius)
    {
        offsetRadius = newRadius;
    }

    public void UpdatePosition()
    {
        /*Debug.Log(gameObject.name + ": UpdatePosition");*/
        Vector2 startPos = fromNode.transform.localPosition;
        Vector2 endPos = toNode.transform.localPosition;
        //float fromRadius = fromNode.sizeDelta.x * 0.5f;

        Vector2 direction = (endPos - startPos).normalized;
        //Debug.Log("direction: " + direction);

        startPos += direction * offsetRadius;
        endPos -= direction * offsetRadius;

        //Vector2 newDirection = endPos - startPos;
        float distance = Vector3.Distance(startPos, endPos) / transform.localScale.x;

        
        //transform.right = direction; // point arrow at target
        transform.SetPositionAndRotation(startPos, Quaternion.LookRotation(Vector3.forward, Vector3.Cross(Vector3.forward, direction)));

        // stretch arrow length (assuming original sprite width = 1 unit)
        spriteRenderer.size = new(Mathf.Max(1f, distance), 1f);
        outlineSpriteRenderer.size = spriteRenderer.size;
        if (labelAnchor)
        {
            labelAnchor.sizeDelta = new(spriteRenderer.size.x, valueText.rectTransform.sizeDelta.y);
        }
        // update color based on new angle
        UpdateArrowColor();

        //valueText.rectTransform.localEulerAngles = -transform.localEulerAngles;
        //valueText.transform.position = 
        if (valueText)
        {
            valueText.rectTransform.localScale = new(
            (direction.x >= 0f) ? 1f : -1f,
            (direction.x >= 0f) ? 1f : -1f,
            valueText.rectTransform.localScale.z);
        }
    }
    private void OnDestroy()
    {
        if (!GraphNode.generatingGraph)
        {
            /*Debug.Log(gameObject.name + "OnDestroy");*/
            GraphManager.instance.RemoveArrow(this);
            if (fromNode) fromNode.RemoveArrow(this);
            if (toNode) toNode.RemoveArrow(this);
        }
    }
    public float GetFlow() { return flow; }
    public decimal GetFlowFromText()
    {
        return decimal.Parse(valueText.text.Substring(0, valueText.text.IndexOf(';')), System.Globalization.CultureInfo.InvariantCulture);
    }
    public decimal GetRepairCostFromText()
    {
        return decimal.Parse(valueText.text.Substring(valueText.text.IndexOf(' ')+1), System.Globalization.CultureInfo.InvariantCulture);
    }
    public uint GetRepairCost() { return repairCost; }
    public void SetSprite(Sprite newSprite)
    {
        spriteRenderer.sprite = newSprite;
    }
    public void SetArrowSelectedSprite(bool state)
    {
        if (outlineSpriteRenderer) // check if exists (otherwise fails if selected while generating graph)
        {
            outlineSpriteRenderer.enabled = state;
        }
    }
    public void SetArrowTexts(decimal flowValue, decimal costValue)
    {
        // sets a minimum of 0 in case of going back for negative cost while there's already an arrow back
        valueText.SetText($"{flowValue}; {costValue}");
    }
    public void SetArrowRepairCostText(float newValue)
    {
        valueText.SetText($"{flow}; {newValue}");
    }
    public void UpdateArrowColor()
    {
        /*Debug.Log(gameObject.name + ": UpdateArrowColor");*/
        // it's a switch statement but as expression
        var baseColor = fromNode.GetNodeType() switch
        {
            GraphNode.NodeType.pole => GraphManager.instance.arrowFromFieldColor,
            GraphNode.NodeType.browar => GraphManager.instance.arrowFromBreweryColor,
            GraphNode.NodeType.karczma => GraphManager.instance.arrowFromPubColor,
            GraphNode.NodeType.brak => GraphManager.instance.arrowFromNoneColor,
            _ => Color.white,
        };

        // get the Z rotation in degrees (-180f, 180f) (absolute value, so that the color doesn't change suddenly at certain angle)
        float zRotation = Mathf.Abs(transform.localEulerAngles.z - 180f);

        // normalize to [0, 1] and remap to hue adjustment range ([0.6, 1.4])
        float adjustment = Mathf.Lerp(0.2f, 1f, Mathf.InverseLerp(-180f, 180f, zRotation));

        // convert base color to HSV
        Color.RGBToHSV(baseColor, out float h, out float s, out float v);

        // apply adjustment to value (brightness)
        v = Mathf.Clamp01(v * adjustment);

        // convert back to RGB
        Color adjustedColor = Color.HSVToRGB(h, s, v);

        spriteRenderer.color = adjustedColor;
    }

}
