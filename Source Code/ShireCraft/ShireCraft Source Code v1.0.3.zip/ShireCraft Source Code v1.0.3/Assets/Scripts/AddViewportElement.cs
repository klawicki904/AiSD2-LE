using UnityEngine;
//using UnityEngine.UI;
//using System.Collections.Generic;

public class AddViewportElement: MonoBehaviour
{
    //[SerializeField] System.Collections.Generic.List<GameObject> elements = new();
    [SerializeField] RectTransform viewportContent;
    [SerializeField] GameObject elementPrefab;
    public void AddElement()
    {
        GameObject instance = Instantiate(elementPrefab);
        instance.transform.SetParent(viewportContent, false);
    }
}
