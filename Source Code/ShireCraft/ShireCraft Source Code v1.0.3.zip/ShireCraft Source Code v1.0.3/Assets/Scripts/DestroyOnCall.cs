using UnityEngine;

public class DestroyOnCall : MonoBehaviour
{
    public void SelfDesturct()
    {
        Destroy(gameObject);
    }
}
