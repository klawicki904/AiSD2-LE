using TMPro;
using UnityEngine;
using UnityEngine.Localization;

public class FileOperationInfoText : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI statusText;
    // localized entries from the table
    public LocalizedString emptyString;
    public LocalizedString fileLoadedString;
    public LocalizedString fileLoadingNotSupported;
    public LocalizedString fileSaved;
    public LocalizedString fileSavingNotSupported;
    public LocalizedString fileArrowsParseErrorString;
    public LocalizedString fileParseErrorString;
    public LocalizedString fileNotFoundString;
    public LocalizedString inputFileCannotBeTheSameAsOutputFileString;
    public static FileOperationInfoText instance { get; private set; }
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }
    public void ShowFileLoaded(string filePath)
    {
        fileLoadedString.Arguments = new object[] { filePath };
        fileLoadedString.StringChanged += UpdateStatusText;
    }
    public void ShowFileLoadingNotSupported()
    {
        fileLoadingNotSupported.StringChanged += UpdateStatusText;
    }
    public void ShowFileSaved(string filePath)
    {
        fileSaved.Arguments = new object[] { filePath };
        fileSaved.StringChanged += UpdateStatusText;
    }
    public void ShowFileSavingNotSupported()
    {
        fileSavingNotSupported.StringChanged += UpdateStatusText;
    }
    public void ShowArrowsParseError()
    {
        fileArrowsParseErrorString.StringChanged += UpdateStatusText;
    }
    public void ShowFileParseError(int lineNumber, string line, string errorMsg)
    {
        fileParseErrorString.Arguments = new object[] { lineNumber, line, errorMsg };
        fileParseErrorString.StringChanged += UpdateStatusText;
    }
    public void ShowFileNotFound(string filePath)
    {
        fileNotFoundString.Arguments = new object[] { filePath };
        fileNotFoundString.StringChanged += UpdateStatusText;
    }

    // compression - decompression program error when input file is the same as output file
    public void InputFileCannotBeTheSameAsOutputFileError()
    {
        inputFileCannotBeTheSameAsOutputFileString.StringChanged += UpdateStatusText;
    }
    public void ClearInfoText()
    {
        emptyString.StringChanged += UpdateStatusText;
    }

    private void UpdateStatusText(string localizedText)
    {
        statusText.text = localizedText;
    }
}
