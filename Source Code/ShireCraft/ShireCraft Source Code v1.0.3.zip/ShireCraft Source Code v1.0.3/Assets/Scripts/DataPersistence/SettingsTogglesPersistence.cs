using UnityEngine;
using UnityEngine.UI;
using TMPro;
using Unity.VisualScripting;
using System.Globalization;

public class SettingsTogglesPersistence : MonoBehaviour, ISettingsPersistence
{
    //[SerializeField] Toggle autoFlowToggle;
    [SerializeField] Toggle snapToGridToggle;
    [SerializeField] Toggle showGridToggle;
    [SerializeField] TMP_InputField gridSizeInputField;
    [SerializeField] Toggle dragThresholdToggle;
    [SerializeField] Slider dragThresholdSlider;
    [SerializeField] Slider elementsSizeSlider;
    [SerializeField] TMP_InputField horizontalSpacingInputField;
    [SerializeField] TMP_InputField verticalSpacingInputField;
    [SerializeField] TMP_InputField maxZoomInputField;
    [SerializeField] TMP_Dropdown languageDropdown;
    [SerializeField] Slider generationBatchingSlider;
    [Header("Colors")]
    [SerializeField] Slider arrowsFromFieldsHueSlider;
    [SerializeField] Slider arrowsFromBreweriesHueSlider;
    [SerializeField] Slider arrowsFromPubsHueSlider;
    [SerializeField] Slider arrowsFromNoneHueSlider;
    [SerializeField] Slider patternMatchHueSlider;
    
    
    public void LoadSettings(SettingsData data)
    {
        //autoFlowToggle.isOn = data.AutoFlow;
        snapToGridToggle.isOn = data.SnapToGrid;
        showGridToggle.isOn = data.ShowGrid;

        gridSizeInputField.text = data.GridSize.ToString();
        gridSizeInputField.onDeselect.Invoke(gridSizeInputField.text);

        dragThresholdToggle.isOn = data.DragThreshold;
        dragThresholdSlider.value = (float)data.DragThresholdValue;
        elementsSizeSlider.value = (float)data.ElementsSize;

        horizontalSpacingInputField.text = data.HorizontalSpacing.ToString();
        horizontalSpacingInputField.onDeselect.Invoke(horizontalSpacingInputField.text);

        verticalSpacingInputField.text = data.VerticalSpacing.ToString();
        verticalSpacingInputField.onDeselect.Invoke(verticalSpacingInputField.text);

        maxZoomInputField.text = data.MaxZoom.ToString();
        maxZoomInputField.onDeselect.Invoke(maxZoomInputField.text);

        languageDropdown.value = data.LanguageDropdownOption;
        generationBatchingSlider.value = data.generationBatching;
        /// colors
        arrowsFromFieldsHueSlider.value = data.ArrowsFromFieldsHue;
        arrowsFromBreweriesHueSlider.value = data.ArrowsFromBreweriesHue;
        arrowsFromPubsHueSlider.value = data.ArrowsFromPubsHue;
        arrowsFromNoneHueSlider.value = data.ArrowsFromNoneHue;
        patternMatchHueSlider.value = data.PatternMatchHue;

        /// only changeable by modifying the settings file
        LoadingScreenText.instance.SetLoadingScreenRefreshDelay(data.LoadingScreenRefreshDelay);
        FileToTMPInput.instance.SetLoadGraphOnLaunch(data.LoadGraphOnLaunch);
    }
    public void SaveSettings(SettingsData data)
    {
        //data.AutoFlow = autoFlowToggle.isOn;
        data.SnapToGrid = snapToGridToggle.isOn;
        data.ShowGrid = showGridToggle.isOn;
        data.GridSize = float.Parse(gridSizeInputField.text, CultureInfo.InvariantCulture);
        data.DragThreshold = dragThresholdToggle.isOn;
        data.DragThresholdValue = (int)dragThresholdSlider.value;
        data.ElementsSize = (int)elementsSizeSlider.value;
        data.HorizontalSpacing = float.Parse(horizontalSpacingInputField.text, CultureInfo.InvariantCulture);
        data.VerticalSpacing = float.Parse(verticalSpacingInputField.text, CultureInfo.InvariantCulture);
        data.MaxZoom = int.Parse(maxZoomInputField.text);
        data.LanguageDropdownOption = languageDropdown.value;
        data.generationBatching = (int)generationBatchingSlider.value;
        /// colors
        data.ArrowsFromFieldsHue = arrowsFromFieldsHueSlider.value;
        data.ArrowsFromBreweriesHue = arrowsFromBreweriesHueSlider.value;
        data.ArrowsFromPubsHue = arrowsFromPubsHueSlider.value;
        data.ArrowsFromNoneHue = arrowsFromNoneHueSlider.value;
        data.PatternMatchHue = patternMatchHueSlider.value;
    }
}
