using UnityEngine;

public class ChangeActiveStateOnThisStateChange : MonoBehaviour
{
    [SerializeField] GameObject[] objectsToChangeState;
    [SerializeField] bool onlyOnEnable;
    [SerializeField] bool stateOnEnable;
    [SerializeField] bool onlyOnDisable;
    [SerializeField] bool stateOnDisable;
    [Tooltip("When enabled, setting object's parent inactive will not trigger OnDisable behavior")]
    [SerializeField] bool explicitlyDisabled;
    
    private void OnEnable()
    {
        if (!onlyOnDisable)
        {
            foreach (GameObject obj in objectsToChangeState)
            {
                if (obj) { obj.SetActive(stateOnEnable); }
            }
        }
    }
    private void OnDisable()
    {
        if (!onlyOnEnable)
        {
            if (explicitlyDisabled && gameObject.activeSelf) { return; }

            foreach (GameObject obj in objectsToChangeState)
            {
                if (obj) { obj.SetActive(stateOnDisable); }
            }
        }
    }
}
