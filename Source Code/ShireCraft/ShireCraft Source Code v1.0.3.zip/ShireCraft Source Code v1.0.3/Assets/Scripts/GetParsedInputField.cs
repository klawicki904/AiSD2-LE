using System.Text;
using TMPro;
using UnityEngine;

public class GetParsedInputField : MonoBehaviour
{
    [SerializeField] TMP_InputField inputField;
    [SerializeField] StringBuilder savedOriginalText;
    [SerializeField] bool derichified = false;

    public void RichTextInputFieldOnSelect()
    {
        savedOriginalText = new(inputField.text);
        inputField.SetTextWithoutNotify(inputField.textComponent.GetParsedText());
        derichified = true;
    }
    public void RichTextInputFieldOnDeselect()
    {
        if (derichified && savedOriginalText != null && savedOriginalText.Length > 0)
        {
            inputField.SetTextWithoutNotify(savedOriginalText.ToString());
            savedOriginalText = null;
            derichified = false;
        }
    }

}
