using System.Threading;
using UnityEngine;

public class DeactivateAfterTime : MonoBehaviour
{
    [SerializeField] float deactivateAfter = 1f;
    CancellationTokenSource cancellationTokenSource;
    private void OnEnable()
    {
        DeactivateAfterTimeAsync();
    }
    public async void DeactivateAfterTimeAsync()
    {
        CancelPreviousAsync();
        CancellationToken token = cancellationTokenSource.Token;
        try { await Awaitable.WaitForSecondsAsync(deactivateAfter, token); } catch { Debug.Log(name + ": WaitForSecondsAsync cancelled"); }
        gameObject.SetActive(false);
    }
    void CancelPreviousAsync()
    {
        if (cancellationTokenSource != null)
        {
            cancellationTokenSource.Cancel();
            cancellationTokenSource.Dispose();
        }
        cancellationTokenSource = new();
    }
}
