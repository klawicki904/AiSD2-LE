using UnityEngine;

public class NodePrefabToPool : MonoBehaviour
{
    // Empty script to use by ObjectPooler
}
