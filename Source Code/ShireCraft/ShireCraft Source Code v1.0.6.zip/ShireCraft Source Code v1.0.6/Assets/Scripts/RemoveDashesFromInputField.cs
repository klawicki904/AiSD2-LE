using TMPro;
using UnityEngine;

public class RemoveDashesFromInputField : MonoBehaviour
{
    [SerializeField] TMP_InputField inputField;
    public void RemoveDashesOnSelect()
    {
        if (inputField.text.Equals("-,-"))
        {
            inputField.SetTextWithoutNotify(string.Empty);
        }
    }
}
