using System.IO;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections;
using UnityEngine.Networking;
#if UNITY_STANDALONE_WIN
using SFB;
#endif
using System.Linq;
using System;


#if UNITY_EDITOR
using UnityEditor;
using System.Threading.Tasks;
#endif

public class FileToTMPInput : MonoBehaviour
{
    [SerializeField] TMP_InputField arrowListInputField;
    [SerializeField] TMP_InputField detailedInputField;
    [SerializeField] TMP_InputField outputDataInputField;
    [SerializeField] TextMeshProUGUI operationStatusInfoText;
    
    
    [SerializeField] GameObject incorrectElementsConfirmationMenu;
    [SerializeField] GameObject chooseFileTypeConfirmationMenu;

    public static string simulationFilePath = "";
    //public static string currentlyOpenFile = temporaryFile;
    public static readonly string autosaveFilePath = Path.Combine(SettingsPersistenceManager.savesFolder, "autosave.txt");

    [SerializeField] bool loadGraphOnLaunch;

    public static FileToTMPInput instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }

        if (!File.Exists(autosaveFilePath))
        {
            // create settings folder in case if didn't exist
            Directory.CreateDirectory(SettingsPersistenceManager.savesFolder);
            File.Create(autosaveFilePath).Close();
        }
        // load autosave on launch
        if (loadGraphOnLaunch)
        {
            LoadText(autosaveFilePath);
        }
    }

    // ========== LOAD ==========
    public void OpenFileAndLoad()
    {
#if UNITY_EDITOR
        string path = EditorUtility.OpenFilePanel("Select Graph Data File", SettingsPersistenceManager.savesFolder, "txt");
        if (!string.IsNullOrEmpty(path))
        {
            LoadText(path);
            //graphTab.onClick.Invoke();
        }
        /*#elif UNITY_ANDROID || UNITY_IOS
                PickFileMobile();*/
#elif UNITY_STANDALONE
        var paths = StandaloneFileBrowser.OpenFilePanel("Load Graph Data File", SettingsPersistenceManager.savesFolder, "txt", false);
        /*if (paths.Length > 0) {
            StartCoroutine(OutputRoutine(new System.Uri(paths[0]).AbsoluteUri));
        }*/
        /*WriteResult(StandaloneFileBrowser.OpenFilePanel("Open File", SettingsPersistenceManager.savesFolder, "txt", false));*/
        if(paths.Length == 0) { return; } // opening file cancelled, so paths has no array, so checking element 0 would show "index out of bounds" error
        if (!string.IsNullOrEmpty(paths[0]))
        {
            LoadText(paths[0]);
        }
#else
        Debug.LogWarning("File loading not supported on this platform.");
        FileOperationInfoText.instance.ShowFileLoadingNotSupported();
        return;
#endif
    }

    public bool LoadText(string filePath, bool convertToGraph = true)
    {
        if (File.Exists(filePath))
        {
            LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.preparing);
            // get first line of the file
            //try
            //{
            
            string fileText = File.ReadLines(filePath).First();
            bool simulationData = fileText.Contains(':');
            Debug.Log("first line: " +  fileText);
            // detect format to use the right input field
            TMP_InputField currentInputField = (fileText.Contains(' ')) ? arrowListInputField : ((simulationData) ? outputDataInputField : detailedInputField);

            // get the whole file
            fileText = File.ReadAllText(filePath)/*.Replace('.', ',')*/;
            // copy file to autosave's path
            if (!filePath.Equals(autosaveFilePath) && !simulationData)
            {
                File.WriteAllText(autosaveFilePath, fileText);
            }

            if (fileText.Length <= 80000)
            {
                arrowListInputField.interactable = true;
                detailedInputField.interactable = true;
                currentInputField.SetTextWithoutNotify(fileText);
            }
            else
            {
                arrowListInputField.SetTextWithoutNotify(String.Empty);
                detailedInputField.SetTextWithoutNotify(String.Empty);
                outputDataInputField.SetTextWithoutNotify(String.Empty);
                arrowListInputField.interactable = false;
                detailedInputField.interactable = false;
            }

            if (!filePath.Equals(autosaveFilePath))
            { FileOperationInfoText.instance.ShowFileLoaded(filePath); }

            if (simulationData) // the output solution file contains ':' in the first line
            {
                OutputFileToSimulationData.instance.ResetSimulation();
                simulationFilePath = filePath;
                OutputFileToSimulationData.instance.ConvertSimulationGraphMain();
                //if (OutputFileToSimulationData.instance.GetInputCorrect()) {  }
                return false;
            }

            if (convertToGraph)
            {
                OutputFileToSimulationData.instance.ResetSimulation();
                FileGraphConverter.instance.ConvertGraphMain();
                //if (FileGraphConverter.instance.GetInputCorrect()) {  }
            }
                
                
            return fileText.Length <= 80000;
            //}
            //catch (Exception e) { Debug.LogWarning(e); return false; } // return if file empty
        }
        else
        {
            Debug.LogWarning("File not found: " + filePath);
            FileOperationInfoText.instance.ShowFileNotFound(filePath);
            return false;
        }
    }
    public void AutosaveToInputField()
    {
        LoadText(autosaveFilePath, false);
    }
    public void AutosaveToGraph() // used by input fields
    {
        if (!FileGraphConverter.instance.GetUpdateNeeded()) {  return; }
        //AutosaveFile(data);
        LoadText(autosaveFilePath);
    }
    public void AutosaveToAndPathAnalyzer(bool force = false) // called when clicking "Simulate" tab
    {
        Debug.Log("AutosaveToAndPathAnalyzer");
        if ((GraphManager.instance.GraphCorrect() && (FileGraphConverter.instance.GetUpdateNeeded() || !OutputFileToSimulationData.simulationGenerated))
            || force)
        {
            //OutputFileToSimulationData.simulationUpdateNeeded = false;
            GraphToTextConverter.instance.ConvertGraphToText(true);
            
        }
    }
    public static string GetAutosaveText()
    {
        return File.ReadAllText(autosaveFilePath);
    }
    /*public void AutosaveToDetailedInput(string data)
    {

    }*/
    public void AutosaveAndInputFields(ref string detailedData, ref string arrowsData)
    {
        AutosaveFile(ref detailedData);
        if (this && LoadText(autosaveFilePath, false)) { arrowListInputField.text = arrowsData; }
        // "this" makes sure the object still exists (so that it doesn't throw exception in LoadText() on application quit)
    }
    public static string GetAutosaveFirstLine()
    {
        return File.ReadLines(autosaveFilePath).First();
    }

    /*#if UNITY_ANDROID || UNITY_IOS
        private void PickFileMobile()
        {
            NativeFilePicker.Permission permission = NativeFilePicker.PickFile((path) =>
            {
                if (path != null)
                {
                    LoadText(path);
                }
            }, new string[] { "text/plain" });
        }
    #endif*/

    // ========== SAVE ==========
    /*public void SaveTextToFile()
    {
        if (!string.IsNullOrEmpty(currentFilePath))
        {
            File.WriteAllText(currentFilePath, arrowListInputField.text);
            Debug.Log($"Saved to: {currentFilePath}");
            operationStatusInfoText.SetText($"Saved to: {currentFilePath}");
        }
        else
        {
            SaveTextAsNewFile();
        }
    }*/
    public void AutosaveFile(string data)
    {
        AutosaveFile(ref data);
    }
    public void AutosaveFile(ref string data) // used by input fields
    {
        if (!FileGraphConverter.instance.GetUpdateNeeded()) { return; }
        if (!string.IsNullOrEmpty(autosaveFilePath))
        {
            // before saving to file, replace dots with commas (C++ uses dots for floats)
            File.WriteAllText(autosaveFilePath, data/*.Replace('.', ',')*/);
            Debug.Log($"Saved autosave to: {autosaveFilePath}");
        }
    }

    public void CheckGraphAndSaveFile() // used by save file button
    {
        // ask Graph Manager for permission to save
        if (!GraphManager.instance.GraphCorrect()) // if graph not correct
        {
            incorrectElementsConfirmationMenu.SetActive(true);
        }
        else if (OutputFileToSimulationData.simulationGenerated) // allow to choose input or output file to save
        {
            chooseFileTypeConfirmationMenu.SetActive(true);
        }
        else 
        {
            SaveAsNewFile(false);
        }
    }
    public void SaveAsNewFile(bool saveSimulation = false) // used by confirmation menu
    {
#if UNITY_EDITOR
        Debug.Log($"SaveAsNewFile:\nautosaveFilePath: {autosaveFilePath}\nsimulationFilePath: {simulationFilePath}\n");
        string path = EditorUtility.SaveFilePanel("Save Graph Data File", SettingsPersistenceManager.savesFolder, "GraphData", "txt");
        if (!string.IsNullOrEmpty(path))
        {
            if (!saveSimulation || (saveSimulation && !string.IsNullOrEmpty(simulationFilePath)))
            {
                File.WriteAllText(path, File.ReadAllText(saveSimulation ? simulationFilePath : autosaveFilePath));
                //currentFilePath = path;
                //Debug.Log($"Saved new file to: {path}\nsimulationFilePath: {simulationFilePath}");
                FileOperationInfoText.instance.ShowFileSaved(path);
            }
        }
        /*#elif UNITY_ANDROID || UNITY_IOS
                SaveTextMobile();*/
#elif UNITY_STANDALONE
        Debug.Log($"SaveAsNewFile:\nautosaveFilePath: {autosaveFilePath}\nsimulationFilePath: {simulationFilePath}\n");
        string path = StandaloneFileBrowser.SaveFilePanel("Save Graph Data File", SettingsPersistenceManager.savesFolder, "GraphData", "txt");
        if (!string.IsNullOrEmpty(path))
        {
            if (!saveSimulation || (saveSimulation && !string.IsNullOrEmpty(simulationFilePath)))
            {
                File.WriteAllText(path, File.ReadAllText(saveSimulation ? simulationFilePath : autosaveFilePath));
                //currentFilePath = path;
                //Debug.Log($"Saved new file to: {path}\nsimulationFilePath: {simulationFilePath}");
                FileOperationInfoText.instance.ShowFileSaved(path);
            }
        }
#else
        Debug.LogWarning("File saving not supported on this platform.");
        FileOperationInfoText.instance.ShowFileSavingNotSupported();
#endif
    }

    /*#if UNITY_ANDROID || UNITY_IOS
        private void SaveTextMobile()
        {
            string fileName = "MySavedText.txt";
            string tempPath = Path.Combine(Application.temporaryCachePath, fileName);
            File.WriteAllText(tempPath, inputField.text);
            NativeShare nativeShare = new NativeShare();
            nativeShare.AddFile(tempPath).SetSubject("Saved Graph Data File").SetText("Here's my graph data file!").Share();
            Debug.Log($"Saved to temp path and shared: {tempPath}");
            operationStatusInfoText.SetText($"Saved to temp path and shared: {tempPath}");
        }
    #endif*/



    /*public string WriteResult(string[] paths)
    {
        string result = string.Empty;
        if (paths.Length == 0)
        {
            return result;
        }

        //currentFilePath = "";
        foreach (var p in paths)
        {
            result += p + "\n";
        }
        return result;
    }*/

    /*public void WriteResult(string path)
    {
        currentFilePath = path;
    }*/
    private IEnumerator OutputRoutine(string url) // used in standalone
    {
        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                operationStatusInfoText.SetText("Request Error: " + request.error);
                Debug.LogError("Request Error: " + request.error);
            }
            else
            {
                //operationStatusInfoText.SetText("Loaded file: " + url);
                FileOperationInfoText.instance.ShowFileLoaded(url);
                arrowListInputField.text = request.downloadHandler.text;
            }
        }
    }
    public void SetLoadGraphOnLaunch(bool state)
    {
        loadGraphOnLaunch = state;
    }

    public static string OpenFileAndReturnPath(string windowName = "Select File", string startInPath = "", string extension = "")
    {
        if (startInPath == "")
        {
            startInPath = SettingsPersistenceManager.savesFolder;
        }
#if UNITY_EDITOR
        return EditorUtility.OpenFilePanel(windowName, startInPath, extension);
#elif UNITY_STANDALONE
        var paths = StandaloneFileBrowser.OpenFilePanel(windowName, startInPath, extension, false);
        if (paths.Length > 1) {
            return "";
        }
        return paths[0];
#else
        Debug.LogWarning("File loading not supported on this platform.");
        operationStatusInfoText.SetText("File loading not supported on this platform.");
        FileOperationInfoText.instance.ShowFileLoadingNotSupported();
        return;
#endif
    }
    public static string SaveFileAndReturnPath(string windowName = "Select File", string startInPath = "", string defaultFileName = "GraphData.txt", string extension = "")
    {
        if (startInPath == "")
        {
            startInPath = SettingsPersistenceManager.savesFolder;
        }

#if UNITY_EDITOR
        string savePath = EditorUtility.SaveFilePanel(windowName, startInPath, defaultFileName, extension);
#elif UNITY_STANDALONE
        string savePath = StandaloneFileBrowser.SaveFilePanel(windowName, startInPath, defaultFileName, extension);
#else
        Debug.LogWarning("File saving not supported on this platform.");
        FileOperationInfoText.instance.ShowFileSavingNotSupported();
#endif
        if (!File.Exists(savePath))
        {
            File.Create(savePath).Close();
        }
        return savePath;
    }
}
