using UnityEngine;
using UnityEngine.UI;

public class SetSpecialActionsInteractable: MonoBehaviour
{
    [SerializeField] Selectable[] selectablesToChangeState;
    [SerializeField] GameObject simulatePanel;
    public void SetSelectablesStates(bool state)
    {
        if (state && simulatePanel.activeSelf) { return; } // re-enable buttons only when simulate panel is not on
        foreach (Selectable selectable in selectablesToChangeState)
        {
            if (selectable) { selectable.interactable = state; }
        }
    }
    private void OnEnable()
    {
        SetSelectablesStates(true);
    }
    private void OnDisable()
    {
            SetSelectablesStates(false);
    }
}
