using UnityEngine;
/// <summary>
/// Undo for moving node by dragging
/// </summary>
public class UndoMoveNode : IUndoableAction
{
    readonly int nodeID;
    Vector2 position;

    public UndoMoveNode(GraphNode node)
    {
        nodeID = node.nodeID;
        // constructor is called before the node is moved, so position saves the old position
        position = node.transform.position;
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        if (GraphManager.instance.TryGetNodeByID(nodeID, out var undoNode))
        {
            // remember old position for swapping
            Vector2 oldPosition = undoNode.transform.position;
            undoNode.MoveNode(position);
            // save old position as position for potential Redo
            position = oldPosition;
        }

    }
    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        Undo();
    }

    
}
