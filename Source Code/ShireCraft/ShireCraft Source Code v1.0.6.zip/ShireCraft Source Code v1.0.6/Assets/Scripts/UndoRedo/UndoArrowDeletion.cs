using UnityEngine;

public class UndoArrowDeletion : IUndoableAction
{
    // arrows must be searched for by their IDs, 
    // searching by reference causes issues because Undo() creates a new arrow,
    // which is later missing its reference in UndoArrowCreation
    private int arrowID;
    private readonly ArrowData arrowData;

    public UndoArrowDeletion(GraphArrow arrow)
    {
        arrowID = arrow.arrowID;

        // store arrow data
        arrowData = new ArrowData(arrow.GetFromNode().nodeID, arrow.GetToNode().nodeID, arrow.GetFlow(), arrow.GetRepairCost());
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        // get nodes by their IDs and create an arrow if they exist
        if (GraphManager.instance.TryGetNodeByID(arrowData.from, out var fromNode) &&
            GraphManager.instance.TryGetNodeByID(arrowData.to, out var toNode))
            GraphManager.instance.CreateArrow(fromNode, toNode, arrowData.flow, arrowData.repairCost, true, arrowID);
    }
    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        if (GraphManager.instance.TryGetArrowByID(arrowID, out GraphArrow arrow))
        {
            GraphManager.instance.SelectArrow(arrow);
            GraphManager.instance.DeleteSelected(true);
        }
    }

    class ArrowData
    {
        public int from;
        public int to;
        public float flow;
        public uint repairCost;

        public ArrowData(int from, int to, float flow, uint repairCost)
        {
            this.from = from;
            this.to = to;
            this.flow = flow;
            this.repairCost = repairCost;
        }
    }
}

