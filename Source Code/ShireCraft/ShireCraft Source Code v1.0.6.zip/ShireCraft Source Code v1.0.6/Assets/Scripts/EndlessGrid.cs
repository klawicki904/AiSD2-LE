using UnityEngine;

public class EndlessGrid : MonoBehaviour
{
    [SerializeField] Vector2 parallaxEffectMultiplier;
    Transform cameraTransform;
    //Vector3 lastCameraPosition;
    float textureUnitSizeX;
    float textureUnitSizeY;

    public static EndlessGrid instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
        cameraTransform = Camera.main.transform;
    }
    void Start()
    {
        Sprite sprite = GetComponent<SpriteRenderer>().sprite;
        Texture2D texture = sprite.texture;
        textureUnitSizeX = texture.width / sprite.pixelsPerUnit;
        textureUnitSizeY = texture.height / sprite.pixelsPerUnit;
    }

    public void UpdateGridPosition()
    {
        if (Mathf.Abs(cameraTransform.position.x - transform.position.x) >= textureUnitSizeX * transform.localScale.x)
        {
            transform.position = new Vector3(cameraTransform.position.x - cameraTransform.position.x % transform.localScale.x, transform.position.y);
        }
        if (Mathf.Abs(cameraTransform.position.y - transform.position.y) >= textureUnitSizeY * transform.localScale.y)
        {
            transform.position = new Vector3(transform.position.x, cameraTransform.position.y - cameraTransform.position.y % transform.localScale.y);
        }
    }
    public void ForceUpdateGridPosition()
    {
        transform.position = new Vector3(
            (int)cameraTransform.position.x - (int)cameraTransform.position.x % transform.localScale.x,
            (int)cameraTransform.position.y - (int)cameraTransform.position.y % transform.localScale.y);
    }
}
