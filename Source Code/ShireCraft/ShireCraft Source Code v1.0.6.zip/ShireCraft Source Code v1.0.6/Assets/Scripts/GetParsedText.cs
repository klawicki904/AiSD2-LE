using TMPro;
using UnityEngine;

public class GetParsedText : MonoBehaviour
{
#if UNITY_EDITOR
    [SerializeField] TextMeshProUGUI text;
    [SerializeField] bool parseTextNow = false;
    private void OnValidate()
    {
        if (parseTextNow)
        {
            parseTextNow = false;
            Debug.Log(text.GetParsedText());
        }
    }
#endif
}
