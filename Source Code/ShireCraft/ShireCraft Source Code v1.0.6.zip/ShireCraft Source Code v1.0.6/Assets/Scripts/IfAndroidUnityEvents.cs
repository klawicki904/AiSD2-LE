using UnityEngine;
using UnityEngine.Events;

public class IfAndroidUnityEvents : MonoBehaviour
{
    [SerializeField] UnityEvent onAwakeIfAndroid = new();
#if UNITY_ANDROID
    private void Awake()
    {
        onActiveChange.Invoke();
    }
#endif
}
