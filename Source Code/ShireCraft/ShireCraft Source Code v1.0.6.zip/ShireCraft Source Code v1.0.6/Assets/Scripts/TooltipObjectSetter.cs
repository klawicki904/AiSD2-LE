using TMPro;
using UnityEngine;

public class TooltipObjectSetter : MonoBehaviour
{
    [SerializeField] RectTransform rectTransform;
    [SerializeField] Transform defaultParent;
    [SerializeField] TextMeshProUGUI tooltipText;
    [SerializeField] Vector2 offset;
    public static TooltipObjectSetter instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }
    public void SetTooltipText(string newText)
    {
        tooltipText.text = newText;
    }
    public Vector2 GetOffset() {  return offset; }
    public void UpdatePosition(Transform newParent)
    {
        transform.SetParent(newParent, false); // the object calling the method is the parent now
        rectTransform.anchoredPosition = offset; // moves the tooltip under the parent
        // sets the tooltip back to its original parent
        // so that it always displays above other UI elements
        transform.SetParent(defaultParent, true);
        // check if tooltip is inside visible screen area
        Vector3[] corners = new Vector3[4];
        rectTransform.GetWorldCorners(corners);

        float tooltipLeft = corners[0].x;
        float tooltipRight = corners[2].x;

        float screenLeft = 0;
        float screenRight = Screen.width;

        float shiftX = 0;

        if (tooltipLeft < screenLeft)
        {
            shiftX = screenLeft - tooltipLeft;
        }
        else if (tooltipRight > screenRight)
        {
            shiftX = screenRight - tooltipRight;
        }

        // adjust position if necessary
        if (Mathf.Abs(shiftX) > 0.01f)
        {
            rectTransform.position += new Vector3(shiftX, 0f, 0f);
        }
    }
}
