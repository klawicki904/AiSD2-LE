using System.Threading;
using System.Threading.Tasks;
using UnityEngine;
using UnityEngine.Localization;

public class StatisticsPanel : MonoBehaviour
{
    [SerializeField] GameObject loadingScreenPanel;
    [SerializeField] UnityEngine.UI.Button refreshButton;
    [SerializeField] float refreshDelay = 1f;
    [SerializeField] TMPro.TextMeshProUGUI statisticsText;
    [SerializeField] LocalizedString statisticsLocalizedString;
    public static StatisticsPanel instance { get; private set; }
    CancellationTokenSource cancellationTokenSource;
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }
    private void OnEnable()
    {
        if (GraphManager.instance.GetNodesCount() < 2000)
        {
            UpdateStatisticsText();
        }
        else
        {
            refreshButton.interactable = true;
        }
    }
    private void OnDisable()
    {
        CancelPreviousAsync();
    }
    public void UpdateStatisticsText()
    {
        _ = UpdateStatisticsTextAsync();
    }
    async Task UpdateStatisticsTextAsync()
    {
        CancelPreviousAsync();
        cancellationTokenSource = new CancellationTokenSource(); // Ensure new token
        CancellationToken token = cancellationTokenSource.Token;
        //Debug.Log("UpdateStatisticsTextAsync started");

        if (GraphManager.instance.GetNodesCount() > 2000)
        {
            Debug.Log("Nodes > 2000: One-time refresh");
            refreshButton.interactable = true;
            await FetchMapData(token, true);
        }
        else
        {
            //Debug.Log("Nodes <= 2000: Loop refresh");
            try
            {
                while (!token.IsCancellationRequested)
                {
                    //Debug.Log("Refreshing at time: " + Time.time);
                    refreshButton.interactable = false;
                    await FetchMapData(token, false);
                    //Debug.Log("Refreshed at time: " + Time.time);
                    if (GraphManager.instance.GetNodesCount() > 2000)
                    {
                        refreshButton.interactable = true;
                        break;
                    }

                    try { await Awaitable.WaitForSecondsAsync(refreshDelay, token); }
                    catch { break; }
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogError("Statistics loop failed: " + ex);
            }
        }

        CancelPreviousAsync();
    }

    async Task FetchMapData(CancellationToken token, bool showLoadingScreen)
    {
        bool loadingScreenPanelInitialState = loadingScreenPanel.activeSelf;
        try
        {
            int refreshCounter = 0;
            int generationBatching = GraphManager.instance.GetGenerationBatching() * 5;

            if (showLoadingScreen) 
            { 
                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.preparing);
                if (!loadingScreenPanelInitialState) { loadingScreenPanel.SetActive(true); }
            }
            // get long tasks asynchronously
            // count each node type amount
            int noneTypeNodesCount = 0;
            int fieldTypeNodesCount = 0;
            int breweryTypeNodesCount = 0;
            float minBreweryCapacity = float.MaxValue;
            float maxBreweryCapacity = -1f;
            int pubTypeNodesCount = 0;
            int quarterTypeNodesCount = GraphManager.instance.currentQuarter.Count;
            float minQuarterValue = float.MaxValue;
            float maxQuarterValue = -1f;
            foreach (GraphNode node in GraphManager.instance.GetNodes())
            {
                switch (node.GetNodeType())
                {
                    case GraphNode.NodeType.brak: { noneTypeNodesCount++; break; }
                    case GraphNode.NodeType.pole: { fieldTypeNodesCount++; break; }
                    case GraphNode.NodeType.browar: { breweryTypeNodesCount++; 
                            minBreweryCapacity = Mathf.Min(minBreweryCapacity, node.GetCapacity());
                            maxBreweryCapacity = Mathf.Max(maxBreweryCapacity, node.GetCapacity());
                                break;
                        }
                    case GraphNode.NodeType.karczma: { pubTypeNodesCount++; break; }
                }
                if (++refreshCounter % generationBatching == 0)
                {
                    await Task.Yield();
                    token.ThrowIfCancellationRequested();
                }
            }
            // count quarters' sizes
            int smallestQuarter = int.MaxValue;
            int largestQuarter = -1;
            
            foreach (QuarterArea area in GraphManager.instance.GetQuarters())
            {
                quarterTypeNodesCount += area.quarterNodes.Count;
                foreach (GraphNode node in area.quarterNodes)
                {
                    minQuarterValue = Mathf.Min(minQuarterValue, node.GetCapacity());
                    maxQuarterValue = Mathf.Max(maxQuarterValue, node.GetCapacity());
                }
                smallestQuarter = Mathf.Min(smallestQuarter, area.quarterNodes.Count);
                largestQuarter = Mathf.Max(largestQuarter, area.quarterNodes.Count);
                if (++refreshCounter % generationBatching == 0)
                {
                    await Task.Yield();
                    token.ThrowIfCancellationRequested();
                }
            }

            // get arrows stats
            float minFlow = float.MaxValue;
            float maxFlow = -1f;
            float minCost = float.MaxValue;
            float maxCost = -1f;
            foreach (GraphArrow arrow in GraphManager.instance.GetArrows())
            {
                minFlow = Mathf.Min(minFlow, arrow.GetFlow());
                maxFlow = Mathf.Max(maxFlow, arrow.GetFlow());
                minCost = Mathf.Min(minCost, arrow.GetRepairCost());
                maxCost = Mathf.Max(maxCost, arrow.GetRepairCost());
                if (++refreshCounter % generationBatching == 0)
                {
                    await Task.Yield();
                    token.ThrowIfCancellationRequested();
                }
            }

            // get solution data
            int solutionRoutes = OutputFileToSimulationData.instance.GetSolutionRoutesCount();
            int solutionSteps = OutputFileToSimulationData.instance.GetSolutionStepsCount();

            // pass values to the localized string
            statisticsLocalizedString.Arguments = new object[] {
            GraphManager.instance.GetNodesCount(),
            noneTypeNodesCount,
            fieldTypeNodesCount,
            breweryTypeNodesCount,
            minBreweryCapacity==float.MaxValue ? null : minBreweryCapacity,
            maxBreweryCapacity==-1f ? null : maxBreweryCapacity,
            pubTypeNodesCount,
            quarterTypeNodesCount,
            minQuarterValue==float.MaxValue ? null : minQuarterValue,
            maxQuarterValue==-1f ? null : maxQuarterValue,
            GraphManager.instance.GetRedNodes().Count,
            GraphManager.instance.GetArrowsCount(),
            minFlow==float.MaxValue ? null : minFlow,
            maxFlow==-1f ? null : maxFlow,
            minCost==float.MaxValue ? null : minCost,
            maxCost==-1f ? null : maxCost,       
            GraphManager.instance.GetQuartersCount(),
            smallestQuarter==int.MaxValue ? null : smallestQuarter,
            largestQuarter==-1 ? null : largestQuarter,
            solutionRoutes,
            solutionSteps
        };
            token.ThrowIfCancellationRequested();
            statisticsText.text = (statisticsLocalizedString.GetLocalizedString());
        }
        catch (System.Exception ex)
        {
            Debug.LogWarning("StatisticsPanel: " + ex);
            return;
        }
        finally
        {
            if (showLoadingScreen && !loadingScreenPanelInitialState) { loadingScreenPanel.SetActive(false); }
        }
    }
    public void CancelPreviousAsync()
    {
        if (cancellationTokenSource != null)
        {
            cancellationTokenSource.Cancel();
            cancellationTokenSource.Dispose();
        }
        cancellationTokenSource = new CancellationTokenSource();
        Debug.Log("Stats: Cancelled Async");
    }
}
