public interface ISettingsPersistence
{
    void LoadSettings(SettingsData data);

    void SaveSettings(SettingsData data);
}
