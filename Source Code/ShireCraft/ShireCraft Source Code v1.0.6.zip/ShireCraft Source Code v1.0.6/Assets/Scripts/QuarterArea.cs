using System.Collections.Generic;
using System.Threading;
using UnityEngine;

public class QuarterArea : MonoBehaviour
{
    public List<GraphNode> quarterNodes { get; private set; } // Assign your GameObjects here in the inspector
    [SerializeField] PolygonCollider2D polyCollider;
    [SerializeField] LineRenderer lineRenderer;
    [SerializeField] Material shapeConvexMaterial;
    [SerializeField] Material shapeNotConvexMaterial;
    [SerializeField] List<GraphNode> nodesOverlapping = new();
    [SerializeField] List<QuarterArea> areasOverlapping = new();
    static bool initializingQuarter; // prevents unneccessary calls to UpdateFieldsYield()
    /*void OnEnable()
    {
        InitializeQuarterBounds(points);
    }*/
    public async void InitializeQuarterBounds(List<GraphNode> points)
    {
        CancellationTokenSource cancellationTokenSource = new();
        CancellationToken token = cancellationTokenSource.Token;
        
        // when creating an area, every node inside it enters the collider, which calls UpdateFeildsYield for every new collider
        initializingQuarter = true; // stop UpdateFieldsYield to prevent freezing
        quarterNodes = new List<GraphNode>(points);
        UpdateColliderPointsAndDraw();

        await Awaitable.WaitForSecondsAsync(0.2f);
        // call UpdateFieldsYield once for every colliding node
        initializingQuarter = false;
        if (polyCollider)
        {
            UpdateFieldsYield();
        }
        //lineRenderer.useWorldSpace = false;
        //lineRenderer.loop = true;
        //lineRenderer.widthMultiplier = 0.05f;
    }
    public void UpdateColliderPointsAndDraw()
    {
        if (quarterNodes.Count < 3)
        {
            Debug.LogWarning("Polygon requires at least 3 points.");
            return;
        }

        Vector2[] colliderPoints = new Vector2[quarterNodes.Count];

        for (int i = 0; i < quarterNodes.Count; i++)
        {
            // convert world positions to local positions relative to the collider's object
            colliderPoints[i] = transform.InverseTransformPoint(quarterNodes[i].transform.position);
        }

        polyCollider.pathCount = 1;
        polyCollider.SetPath(0, colliderPoints);

        lineRenderer.positionCount = polyCollider.points.Length;
        for (int i = 0; i < polyCollider.points.Length; i++)
        {
            lineRenderer.SetPosition(i, polyCollider.points[i]);
        }
        UpdateFieldsYield();
        /*Debug.Log("Updated Collider bounds");*/
    }
    bool IsConvex()
    {
        // Unity�s built-in PolygonCollider2D is limited to a maximum of 8 points per convex path
        // for up to 8 vertices, if shapeCount is 1, it's convex
        if (!polyCollider) { return false; }
        if (polyCollider.points.Length <= 8) { return polyCollider.shapeCount == 1; }
        else
        {
            // check direction of cross product of every two adjacent sides
            bool? sign = null;
            int count = polyCollider.points.Length;

            for (int i = 0; i < count; i++)
            {
                Vector2 a = polyCollider.points[i];
                Vector2 b = polyCollider.points[(i + 1) % count];
                Vector2 c = polyCollider.points[(i + 2) % count];

                Vector2 ab = b - a;
                Vector2 bc = c - b;

                float cross = ab.x * bc.y - ab.y * bc.x;

                if (cross == 0)
                    continue; // colinear points

                bool currentSign = cross > 0;

                if (sign == null)
                {
                    sign = currentSign;
                }
                else if (sign != currentSign)
                {
                    return false; // non-matching cross product direction, shape is not convex
                }
            }

            return true;
        }
    }
    public bool IsAreaCorrect()
    {
        if (!IsConvex()) { /*Debug.Log(name+"Area not correct: Not convex");*/ return false; }
        if (areasOverlapping.Count > 0) { /*Debug.Log(name + "Area not correct: other areas overlapping");*/ return false; }

        // check if every border point is inside the area
        // it's not when it is not a polygon
        foreach (GraphNode quarterNode in quarterNodes)
        {
            if (!nodesOverlapping.Contains(quarterNode))
            {
                //Debug.Log(name + "Area not correct: border point not inside shape (not a polygon): " + quarterNode.name);
                return false;
            }
        }

        return true;
    }
    public bool CheckIfAreaCorrectAndSetColor()
    {
        if (IsAreaCorrect())
        {
            lineRenderer.material = shapeConvexMaterial;
            return true;
        }
        else
        {
            lineRenderer.material = shapeNotConvexMaterial;
            return false;
        }
    }
    public void UpdateFieldsYield()
    {
        if (initializingQuarter || !CheckIfAreaCorrectAndSetColor()) { return; }
        /*if (!CheckIfAreaCorrectAndSetColor())
        {
            foreach (GraphNode field in nodesOverlapping)
            {
                // make sure it is a field and the center of the field is inside the bound (not just its collider)
                if (field.GetNodeType() == GraphNode.NodeType.pole && polyCollider.OverlapPoint(field.transform.position))
                {
                    field.SetCapacity(0f);
                    GraphManager.instance.ShowNodeInfo();
                }
            }
            return;
        }*/

        //if (!CheckIfAreaCorrectAndSetColor()) { return; }
        //List<Collider2D> results = new();
        float newCapacity = quarterNodes[0].GetCapacity(); // store the capacity to update fields later
        //ContactFilter2D contactFilter = new();
        //contactFilter.SetLayerMask(GraphInputManager.nodesLayerMask); // detect only nodes
        //polyCollider.Overlap(contactFilter, results); // get nodes overlapping the collider and put them into results
        //Debug.Log("results.Count: " + results.Count + ": " + string.Join(", ", results));
        //GraphNode field;
        // set each field's yield to quarter's yield
        foreach (GraphNode node in nodesOverlapping)
        {
            //field = collider.GetComponent<GraphNode>();
            //if (field.GetNodeType() == GraphNode.NodeType.pole) // check if the overlapping node is of type pole (field)
            //{
            // make sure it is a field and the center of the field is inside the bound (not just its collider)
            if (node.GetNodeType() == GraphNode.NodeType.pole) 
            {
                if(polyCollider.OverlapPoint(node.transform.position))
                {
                    node.SetCapacity(newCapacity);
                    //GraphManager.instance.ShowNodeInfo();
                }
                else
                {
                    node.SetCapacity(0f);
                    //GraphManager.instance.ShowNodeInfo();
                }
                    
            }
            node.CheckIfCorrectPosition();
            //}
        }
    }
    /*public bool IsNodeInside(GraphNode node)
    {
        return polyCollider.OverlapPoint(node.transform.position);
    }*/
    public PolygonCollider2D GetPolygonCollider() { return polyCollider; }
    /*public bool ContainsNode(GraphNode field)
    {
        if (polyCollider.bounds.Contains(field.transform.position))
        {
            return true;
        }
        return false;
    }*/
    public void DeleteQuarterArea()
    {
        if (!GraphNode.generatingGraph)
        {
            PolygonCollider2D polyCollider2 = polyCollider;
            polyCollider = null;
            Destroy(polyCollider2);

            foreach (GraphNode node in nodesOverlapping)
            {
                if (node.GetNodeType() == GraphNode.NodeType.pole)
                {
                    node.CheckIfCorrectPosition();
                }
            }
        }
        foreach (GraphNode node in quarterNodes) // destroy all nodes in the quarter
        {
            Destroy(node.gameObject);
            GraphManager.instance.nodeDictionary.Remove(node.nodeID);
        }
        
        Destroy(gameObject); // destroy the quarter area (along with collider and line renderer)
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        /*Debug.Log("OnTriggerEnter: " +collision.gameObject);*/
        if (collision.gameObject.TryGetComponent<QuarterArea>(out var area))
        {
            //Debug.Log("field != null && field.GetNodeType() == GraphNode.NodeType.pole");
            if (!areasOverlapping.Contains(area))
            {
                //Debug.Log("!fieldsOverlapping.Contains(field)");
                areasOverlapping.Add(area);
                UpdateFieldsYield();
            }
        }
        if (collision.gameObject.TryGetComponent<GraphNode>(out var node))
        {
            //Debug.Log("field != null && field.GetNodeType() == GraphNode.NodeType.pole");
            if (!nodesOverlapping.Contains(node))
            {
                //Debug.Log("!fieldsOverlapping.Contains(field)");
                nodesOverlapping.Add(node);
                
                UpdateFieldsYield();
            }
        }
        
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        /*Debug.Log("OnTriggerExit: " + collision.gameObject);*/
        if (polyCollider == null)
        {
            return;
        }
        if (collision.gameObject.TryGetComponent<GraphNode>(out var node))
        {
            nodesOverlapping.Remove(node);
            UpdateFieldsYield();
        }
        else if (collision.gameObject.TryGetComponent<QuarterArea>(out var area))
        {
            areasOverlapping.Remove(area);
            UpdateFieldsYield();
        }

    }
}
