using UnityEngine;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using TMPro;
using System;
using System.Globalization;

public class LaunchExternalExecutable : MonoBehaviour
{
    [SerializeField] string exeOutputData;
    [SerializeField] GameObject loadingScreenPanel;
    [SerializeField] TextMeshProUGUI fileOperationInfoText;
    [SerializeField] TMP_Dropdown stringSearchMethodDropdown;
    [SerializeField] TMP_InputField stringSearchPatternInputField;
    [SerializeField] UnityEngine.UI.Toggle matchCaseToggle;
    string fileOperationWarningColorTag = "<color=#daa520>";
    [SerializeField] bool forceDisableExternalExecute;
    string generatedMapPath = Path.Combine(SettingsPersistenceManager.savesFolder, "generated_map.txt");
    DateTime generatedMapLastUpdate;
    Process runningProcess;
    public static LaunchExternalExecutable instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }
    public void ExecuteSearchString()
    {
        if (string.IsNullOrEmpty(FileToTMPInput.simulationFilePath))
        {
            fileOperationInfoText.text = fileOperationWarningColorTag + "Simulation has not been loaded";
            return;
        }
        string stringSearchMethodName = null;
        // prepare pattern parameter
        string pattern = stringSearchPatternInputField.text;
        // clear highlighting when pattern is empty
        if (string.IsNullOrEmpty(pattern))
        {
            ConvertStringSearchOutput.instance.ConvertSSOutput("", 0);
            return;
        }

        switch (stringSearchMethodDropdown.value)
        {
            case 0:
                {
                    stringSearchMethodName = "naiwny"; // Naive
                    break;
                }
            case 1:
                {
                    stringSearchMethodName = "rabin-karp"; // Rabin-Karp
                    break;
                }
            case 2:
                {
                    stringSearchMethodName = "kmp"; // Knuth-Morris-Pratt (KMP)
                    break;
                }
            case 3:
                {
                    stringSearchMethodName = "boyer-moore"; // Boyer-Moore
                    break;
                }
            case 4:
                {
                    // regular expressions
                    string output = ConvertStringSearchOutput.SearchRegexLinesAndColumns(File.ReadAllLines(FileToTMPInput.simulationFilePath), pattern, matchCaseToggle.isOn);
                    UnityEngine.Debug.Log("Regex output: " + output);
                    exeOutputData = string.Empty;
                    ConvertStringSearchOutput.instance.ConvertSSOutput(output, 0);
                    return; // return to not call the method below
                }
            default: break;
        }
        
        if (matchCaseToggle.isOn)
        {
            RunExe("SearchString.exe", stringSearchMethodName, FileToTMPInput.simulationFilePath, pattern);
        }
        else
        {
            RunExe("SearchString.exe", "-i", stringSearchMethodName, FileToTMPInput.simulationFilePath, pattern);
        }
        
        // prepare pattern file
        //string patternPath = Path.Combine(SettingsPersistenceManager.savesFolder, "pattern.txt");
        //File.WriteAllText(patternPath, stringSearchPatternInputField.text); // "Creates a new file, write the contents to the file, and then closes the file."
        //RunExe("SearchString.exe", stringSearchMethodName, FileToTMPInput.simulationFilePath, patternPath);

        // RunExe is async so lines below will execute before the RunExe
    }
    public void ExecutePathAnalyzer()
    {
        UnityEngine.Debug.Log("ExecutePathAnalyzer");
        string outputPath = Path.Combine(SettingsPersistenceManager.savesFolder, "analysis_result.txt");

        RunExe("PathAnalyzer.exe", FileToTMPInput.autosaveFilePath, outputPath);
    }
    public void ExecuteFileArchiver(string inputFile, bool compress)
    {
        string outputFile;
        if (compress)
        {
            //inputFile = FileToTMPInput.OpenFileAndReturnPath("Select File To Compress", "", "txt");
            //if (string.IsNullOrEmpty(inputFile)) { return; } // cancel operation if user cancelled selecting file
            outputFile = FileToTMPInput.SaveFileAndReturnPath("Save Compressed File", "", "compressed_file.huf", "huf");
            if (string.IsNullOrEmpty(outputFile)) { return; } // cancel operation if user cancelled selecting file
        }
        else
        {
            //inputFile = FileToTMPInput.OpenFileAndReturnPath("Select File To Decompress", "", "huf");
            //if (string.IsNullOrEmpty(inputFile)) { return; } // cancel operation if user cancelled selecting file
            outputFile = FileToTMPInput.SaveFileAndReturnPath("Save Decompressed File", "", "decompressed_file.txt", "txt");
            if (string.IsNullOrEmpty(outputFile)) { return; } // cancel operation if user cancelled selecting file
        }
        if (inputFile == outputFile)
        {
            FileOperationInfoText.instance.InputFileCannotBeTheSameAsOutputFileError();
            return;
        }

        if (File.Exists(inputFile) && File.Exists(outputFile))
        {
            if (compress)
            {
                RunExe("FileArchiver.exe", "-c", inputFile, outputFile);
            }
            else
            {
                RunExe("FileArchiver.exe", "-d", inputFile, outputFile);
            }
            // RunExe is async so lines below will execute before the RunExe
        }
    }
    public void ExecuteInputGeneratorUI()
    {
        generatedMapLastUpdate = File.GetLastWriteTime(generatedMapPath);
        RunExe("networkGenInterface.exe", generatedMapPath);
    }
    public void ExecuteFileArchiver(bool compression) // used by DragAndDropGraphData in Build
    {
        string inputFile;
        if (compression)
        {
            inputFile = FileToTMPInput.OpenFileAndReturnPath("Select File To Compress", "", "txt");
            if (string.IsNullOrEmpty(inputFile)) { return; } // cancel operation if user cancelled selecting file
            ExecuteFileArchiver(inputFile, compression);
        }
        else
        {
            inputFile = FileToTMPInput.OpenFileAndReturnPath("Select File To Decompress", "", "huf");
            if (string.IsNullOrEmpty(inputFile)) { return; } // cancel operation if user cancelled selecting file
            ExecuteFileArchiver(inputFile, compression);
        }
    }

    async void RunExe(string exeFileName, string argument1 = null, string argument2 = null, string argument3 = null, string argument4 = null)
    {
        if(forceDisableExternalExecute) { return; }
        bool loadingScreenPanelInitialState = loadingScreenPanel.activeSelf;
        if (!loadingScreenPanelInitialState)
        {
            loadingScreenPanel.SetActive(true);
        }
        //string exePath = Path.Combine(SettingsPersistenceManager.savesFolder, "ExternalTools", exeFileName);
        string exePath = Path.Combine(Application.streamingAssetsPath, exeFileName);
        // save previous output data to compare
        string oldOutputData = exeOutputData;

        
        bool success = await RunExecutableTask(exePath, argument1, argument2, argument3, argument4);
        
        // execute only if output has changed since the last time
        if (success)
        {
            // operations to do after external task finishes execution
            switch (exeFileName)
            {
                case "PathAnalyzer.exe":
                    {
                        if (!loadingScreenPanelInitialState)
                        {
                            loadingScreenPanel.SetActive(false);
                        }
                        if (!OutputFileToSimulationData.simulationGenerated)
                        {
                            // generate simulation from output file
                            //fileOperationInfoText.text = exeOutputData;
                            FileToTMPInput.instance.LoadText(argument2);
                        }
                        break;
                    }
                case "SearchString.exe":
                    {
                        if (oldOutputData != exeOutputData)
                        {
                            UnityEngine.Debug.Log("Analyzer Output:\n" + exeOutputData);
                            //fileOperationInfoText.text = exeOutputData;
                            ConvertStringSearchOutput.instance.ConvertSSOutput(exeOutputData, stringSearchPatternInputField.text.Length);
                        }
                        if (!loadingScreenPanelInitialState)
                        {
                            loadingScreenPanel.SetActive(false);
                        }
                        break;
                    }
                case "FileArchiver.exe":
                    {
                        if (oldOutputData != exeOutputData)
                        {
                            // should return 2 numbers: input_file_size output_file_size
                            string[] fileSizes = exeOutputData.Split(" ");
                            if (fileSizes.Length == 2)
                            {
                                decimal before = decimal.Parse(fileSizes[0], CultureInfo.InvariantCulture);
                                decimal after = decimal.Parse(fileSizes[1], CultureInfo.InvariantCulture);
                                decimal reduction = Math.Round(((after - before) / before) * 100, 2);
                                char sign = ' ';
                                if (reduction > 0)
                                {
                                    sign = '+'; // set sign prefix depending on the percentage difference
                                }

                                FileOperationInfoText.instance.ClearInfoText(); // set the localized string to empty, otherwise it will show last message on language change
                                fileOperationInfoText.text =
                                    $"{fileSizes[0]} B >> {fileSizes[1]} B ({sign}{reduction}%)";
                            }
                        }
                        if (!loadingScreenPanelInitialState)
                        {
                            loadingScreenPanel.SetActive(false);
                        }
                        break;
                    }
                case "networkGenInterface.exe":
                    {
                        if (!loadingScreenPanelInitialState)
                        {
                            loadingScreenPanel.SetActive(false);
                        }
                        if (File.Exists(generatedMapPath) && generatedMapLastUpdate != File.GetLastWriteTime(generatedMapPath))
                        {
                            UnityEngine.Debug.Log("loading text after generation");
                            FileToTMPInput.instance.LoadText(generatedMapPath);
                        }
                        
                        break;
                    }
                default:
                    {
                        UnityEngine.Debug.LogError("Undefined EXE file given as parameter for LaunchExternalExecutable");
                        if (!loadingScreenPanelInitialState)
                        {
                            loadingScreenPanel.SetActive(false);
                        }
                        break;
                    }
            }
        }
        else
        {
            FileOperationInfoText.instance.ClearInfoText(); // set the localized string to empty, otherwise it will show last message on language change
            fileOperationInfoText.text = $"<color=red>{exeFileName} exited with error";
            UnityEngine.Debug.LogWarning($"{exeFileName} failed or output file not found.");
            if (!loadingScreenPanelInitialState)
            {
                loadingScreenPanel.SetActive(false);
            }
        }
    }

    private async Task<bool> RunExecutableTask(string exePath, string argument1, string argument2, string argument3, string argument4)
    {
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.launchingExternalProgram);
        await Task.Yield();
        System.Text.StringBuilder args = new($"\"{argument1}\"");
        if (argument2 != null) { args.Append($" \"{argument2}\""); }
        if (argument3 != null) { args.Append($" \"{argument3}\""); }
        if (argument4 != null) { args.Append($" \"{argument4}\""); }

        if (!File.Exists(exePath))
        {
            UnityEngine.Debug.LogError("Executable not found: " + exePath);
            return false;
        }
        ProcessStartInfo startInfo = new ProcessStartInfo
        {
            FileName = exePath,
            Arguments = args.ToString(), // wrap in quotes to support spaces
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
        };
        UnityEngine.Debug.Log($"arguments: {startInfo.Arguments}");
        runningProcess = new Process();
        runningProcess.StartInfo = startInfo;

        try
        {
            runningProcess.Start();

            string output = await runningProcess.StandardOutput.ReadToEndAsync();
            string error = await runningProcess.StandardError.ReadToEndAsync();

            await Task.Run(() => runningProcess.WaitForExit());

            if (!string.IsNullOrEmpty(error))
            {
                UnityEngine.Debug.LogError("Executable error: " + error);
                FileOperationInfoText.instance.ClearInfoText(); // set the localized string to empty, otherwise it will show last message on language change
                fileOperationInfoText.text = "<color=red>" + error;
            }

            UnityEngine.Debug.Log("Executable finished with output:\n" + output);
            exeOutputData = output;

            return runningProcess.ExitCode == 0;
        }
        catch (System.Exception ex)
        {
            UnityEngine.Debug.LogError("Failed to run executable: " + ex.Message);
            FileOperationInfoText.instance.ClearInfoText(); // set the localized string to empty, otherwise it will show last message on language change
            fileOperationInfoText.text = "<color=red>Failed to run executable: " + ex.Message;
            return false;
        }
        finally
        {
            // ensure cleanup
            if (runningProcess != null && runningProcess.HasExited == false)
                runningProcess.Dispose();

            runningProcess = null;
        }
    }

    public void ForceKillRunningPrograms()
    {
        if (runningProcess != null && !runningProcess.HasExited)
        {
            runningProcess.Kill();
            runningProcess.Dispose();
            runningProcess = null;
        }
    }

    private void OnApplicationQuit()
    {
        ForceKillRunningPrograms();
    }

}
