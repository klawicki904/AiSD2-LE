using System.Globalization;
using TMPro;
using UnityEngine;
/// <summary>
/// limits the Conversion Rate Input Field to round to the nearest 0.05
/// </summary>
public class InputFieldLimitRange : MonoBehaviour
{
    [SerializeField] TMP_InputField inputField;
    [SerializeField] GameObject precisionLossWarning;
    [SerializeField] float maxValue = float.MaxValue;
    public void CheckRange()
    {
        if(float.TryParse(inputField.text, NumberStyles.Float, CultureInfo.InvariantCulture, out float inputValue2))
        {
            if (inputValue2 < 0f)
            {
                inputValue2 = 0f;
            }
            else if (inputValue2 > maxValue)
            {
                inputValue2 = maxValue;
            }
            float inputValue = Mathf.Floor(inputValue2 * 100f) / 100f;
            if (inputValue2 != inputValue)
            {
                inputField.text = inputValue.ToString();
            }
            precisionLossWarning.SetActive((inputValue / 0.5) % 1 != 0); // show a warning if there's a chance of precision loss
        }
    }
}
