using UnityEngine;
using System;
using System.IO;

public class SettingsDataHandler
{
    private string settingsDirPath = "";
    private string settingsFileName = "";

    public SettingsDataHandler(string dataDirPath, string dataFileName)
    {
        this.settingsDirPath = dataDirPath;
        this.settingsFileName = dataFileName;
    }

    public SettingsData Load()
    {
        // use Path.Combine to account for different OS's having different path separators
        string fullPath = Path.Combine(settingsDirPath, settingsFileName);
        SettingsData loadedData = null;
        if (File.Exists(fullPath))
        {
            try
            {
                string settingsToLoad = "";
                using (FileStream stream = new FileStream(fullPath, FileMode.Open))
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        settingsToLoad = reader.ReadToEnd();
                    }
                }

                // deserialize the data from Json back into the C# object
                loadedData = JsonUtility.FromJson<SettingsData>(settingsToLoad);

                Debug.Log("Settings loaded");
            }
            catch (Exception e)
            {
                Debug.LogError("Error occured when trying to load settings from file: " + fullPath + "\n" + e);
            }
        }
        return loadedData;
    }

    public void Save(SettingsData data)
    {
        // use Path.Combine to account for different OS's having different path separators
        string fullPath = Path.Combine(settingsDirPath, settingsFileName);
        try
        {
            // serialize the C# game data object into Json
            string dataToStore = JsonUtility.ToJson(data, true);

            // write the serialized data to the file
            using (FileStream stream = new FileStream(fullPath, FileMode.Create))
            {
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.Write(dataToStore);
                }
            }
            Debug.Log("Settings saved");
        }
        catch (Exception e)
        {
            Debug.LogError("Error occured when trying to save settings to file: " + fullPath + "\n" + e);
        }
    }
}