using UnityEngine;

public class ObjectPoolingManager : MonoBehaviour
{
    public Component pooledPrefab;
    [SerializeField] string key;
    void Awake()
    {
        SetupPool();
    }

    void SetupPool()
    {
        ObjectPooler.SetupPool(pooledPrefab, 4, key);
    }

    private void OnDestroy()
    {
        ObjectPooler.ClearPoolKey(key);
    }
}
