using UnityEngine;
using UnityEngine.InputSystem;

public class ActionsMapsStatus : MonoBehaviour
{
    
    [SerializeField] PlayerInput playerInput;
    [SerializeField] string currentActionMap;
    [SerializeField] bool graphMapStatus;
    [SerializeField] bool simulateMapStatus;
    void Update()
    {
        if (graphMapStatus != playerInput.actions.FindActionMap("Graph").enabled)
        {
            graphMapStatus = playerInput.actions.FindActionMap("Graph").enabled;
            Debug.Log("graphMapStatus changed: " + graphMapStatus);
        }
        currentActionMap = playerInput.currentActionMap.name;
        if (simulateMapStatus != playerInput.actions.FindActionMap("Simulate").enabled)
        {
            simulateMapStatus = playerInput.actions.FindActionMap("Simulate").enabled;
            Debug.Log("simulateMapStatus changed: " + simulateMapStatus);
        }
    }
}
