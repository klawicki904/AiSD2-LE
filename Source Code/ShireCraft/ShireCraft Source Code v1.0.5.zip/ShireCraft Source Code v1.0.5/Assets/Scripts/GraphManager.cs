using UnityEngine;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using System.Threading.Tasks;
using System.Threading;
using TMPro;
using System.Globalization;






#if UNITY_EDITOR
using UnityEditor.Localization.Plugins.XLIFF.V12;
using Unity.VisualScripting;
using UnityEditor.Experimental.GraphView;
#endif
public class GraphManager : MonoBehaviour
{
    [SerializeField] PlayerInput playerInput;
    [SerializeField] UnityEngine.UI.Toggle quarterModeToggle;
    [SerializeField] GameObject elementInfoPanel;
    [SerializeField] GameObject loadingScreenPanel;
    [SerializeField] [Range(0f, 1f)] float breweriesConversionRate = 1f;
    [SerializeField] GameObject simulatePanel;
    [Header("UI")]
    [SerializeField] TMP_InputField gridSizeInputField;
    [Header("Nodes")]
    [SerializeField] GameObject graphNodePrefab;
    [SerializeField] NodeInfoPanel nodeInfoPanel;
    [SerializeField] Sprite[] nodeSprites;
    [SerializeField] bool dragThreshold = true;
    [SerializeField] float dragThresholdValue = 0.2f;
    [Header("Arrows")]
    [SerializeField] GameObject arrowPrefab;
    [SerializeField] ArrowInfoPanel arrowInfoPanel;
    public Color arrowFromFieldColor;
    public Color arrowFromBreweryColor;
    public Color arrowFromPubColor;
    public Color arrowFromNoneColor;
    [Header("Quarters")]
    [SerializeField] GameObject quarterVerticePrefab;
    [SerializeField] GameObject quarterAreaPrefab;
    public List<GraphNode> currentQuarter { get; private set; } = new();
    [SerializeField] List<QuarterArea> quarterAreas = new();
    [Header("Debug")]
    [SerializeField] List<GraphNode> selectedNodes = new();
    [SerializeField] List<GraphNode> nodes = new();

    // dictionaries used for undo and redo;
    // had to add an ID system to each node and arrow for undo and redo to work properly
    public Dictionary<int, GraphNode> nodeDictionary { get; private set; } = new();
    Dictionary<int, GraphArrow> arrowDictionary = new();

    [SerializeField] List<GraphNode> redNodes = new();
    [SerializeField] List<GraphArrow> arrows = new();
    [SerializeField] GraphNode selectedNode;
    [SerializeField] GraphNode cursorNode;
    [SerializeField] List<GraphArrow> selectedArrows;
    [SerializeField] GraphArrow currentArrow;
    //[SerializeField] bool autoFlow = false;
    [SerializeField] bool snapToGrid;
    [SerializeField] float gridSize = 1f;
#if UNITY_EDITOR
    [SerializeField] bool generatingGraph;
#endif
    public LinkedList<IUndoableAction[]> undoStack { get; private set; } = new();
    public LinkedList<IUndoableAction[]> redoStack { get; private set; } = new();

    CancellationTokenSource cancellationTokenSource = new();

    public static int generationBatching = 100;
    public static GraphManager instance { get; private set; }

#if UNITY_EDITOR
    private void Update()
    {
        generatingGraph = GraphNode.generatingGraph;
    }
#endif

    [System.Serializable]
    public class GraphClipboard
    {
        public List<GraphNodeData> nodes = new();
        public List<GraphArrowData> arrows = new();
        public List<QuarterAreaData> quarterAreas = new();
    }
    [System.Serializable]
    public class GraphNodeData
    {
        public Vector2 position;
        public GraphNode.NodeType nodeType;
        public float capacity;
        public int originalID; // useful for mapping arrows later
    }

    [System.Serializable]
    public class GraphArrowData
    {
        public int fromNodeID;
        public int toNodeID;
        public float flow;
        public uint repairCost;
    }

    [System.Serializable]
    public class QuarterAreaData
    {
        public List<int> nodeIDs = new();
    }
    private GraphClipboard clipboard = new();

    public void CopySelected()
    {
        clipboard = new GraphClipboard();
        Dictionary<GraphNode, int> nodeToClipboardID = new();

        // Copy nodes
        for (int i = 0; i < selectedNodes.Count; i++)
        {
            if (selectedNodes[i].GetNodeType() != GraphNode.NodeType.cwiartka) // exclude quarter nodes from being saved here
            {
                var node = selectedNodes[i];
                clipboard.nodes.Add(new GraphNodeData
                {
                    position = node.transform.position,
                    nodeType = node.GetNodeType(),
                    capacity = node.GetCapacity(),
                    originalID = node.nodeID
                });
                nodeToClipboardID[node] = node.nodeID;
            }
        }

        // Copy arrows from selected nodes
        foreach (var node in selectedNodes)
        {
            foreach (var arrow in node.GetArrowsFromThis())
            {
                if (selectedNodes.Contains(arrow.GetToNode()))
                {
                    clipboard.arrows.Add(new GraphArrowData
                    {
                        fromNodeID = arrow.GetFromNode().nodeID,
                        toNodeID = arrow.GetToNode().nodeID,
                        flow = arrow.GetFlow(),
                        repairCost = arrow.GetRepairCost()
                    });
                }
            }
        }

        // copy quarter areas that include selected nodes
        foreach (var quarterArea in GetQuarters())
        {
            bool matched = (quarterArea.quarterNodes.Find(n => selectedNodes.Contains(n)) != null);
            Debug.Log($"{quarterArea}: found nodes to copy over?: {matched}");
            if (matched)
            {
                var quarterData = new QuarterAreaData();
                foreach (var qNode in quarterArea.quarterNodes)
                {
                    quarterData.nodeIDs.Add(qNode.nodeID);

                    // also add the quarter node to list of nodes to copy over
                    clipboard.nodes.Add(new GraphNodeData
                    {
                        position = qNode.transform.position,
                        nodeType = qNode.GetNodeType(),
                        capacity = qNode.GetCapacity(),
                        originalID = qNode.nodeID
                    });
                    nodeToClipboardID[qNode] = qNode.nodeID;
                }
                clipboard.quarterAreas.Add(quarterData);
            }
        }
    }
    public void PasteClipboard()
    {
        Dictionary<int, GraphNode> newNodeMap = new(); // map with old IDs for arrows to know which node to attach to, while pasted nodes get a new ID
        List<IUndoableAction> newUndoList = new();
        // create nodes
        foreach (var nodeData in clipboard.nodes)
        {
            Vector2 newPosition = nodeData.position + GraphInputManager.pasteOffset;
            //GraphInputManager.SetPasteOffsetX(GraphInputManager.pasteOffset.x + 1f);
            //GraphInputManager.SetPasteOffsetY(GraphInputManager.pasteOffset.y - 1f);
            var newNode = CreateNode(newPosition, nodeData.nodeType, nodeData.capacity, true, null, false);
            newNodeMap[nodeData.originalID] = newNode;
            if (newNode.GetNodeType() != GraphNode.NodeType.cwiartka) // don't undo quarters (otherwise it redos duplicate quarter nodes with duplicate IDs)
            {
                newUndoList.Add(new UndoNodeCreation(newNode));
            }
            
        }

        // create arrows
        foreach (var arrowData in clipboard.arrows)
        {
            if (newNodeMap.TryGetValue(arrowData.fromNodeID, out var fromNode) &&
                newNodeMap.TryGetValue(arrowData.toNodeID, out var toNode))
            {
                var newArrow = CreateArrow(fromNode, toNode, arrowData.flow, arrowData.repairCost, true);
                if (newArrow != null)
                {
                    ApplyArrow(toNode);

                    newUndoList.Add(new UndoArrowCreation(newArrow));
                }
            }
        }

        // create quarter areas
        foreach (var quarterData in clipboard.quarterAreas)
        {
            currentQuarter.Clear();
            foreach (var id in quarterData.nodeIDs)
            {
                if (newNodeMap.TryGetValue(id, out var quarterNode))
                    currentQuarter.Add(quarterNode);
            }

            if (currentQuarter.Count >= 3)
            {
                CreateArrowInput(currentQuarter[0], true);

                newUndoList.Add(new UndoQuarterAreaCreation(quarterAreas[^1]));
            }
        }

        // select all pasted nodes
        DeselectAllElements();
        foreach (var newNode in newNodeMap.Values)
        {
            SelectNode(newNode, true);
        }

        // add pasted actions to undo-redo
        IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
        newUndoList.CopyTo(newUndoArray, 0);
        PushStack(undoStack, ref newUndoArray);
        redoStack.Clear();
    }





    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
        Color.RGBToHSV(arrowFromFieldColor, out float h1, out float _, out float _);
        Debug.Log("arrowFromFieldColor hue: " + h1);
        Color.RGBToHSV(arrowFromBreweryColor, out float h2, out float _, out float _);
        Debug.Log("arrowFromFieldColor hue: " + h2);
        Color.RGBToHSV(arrowFromPubColor, out float h3, out float _, out float _);
        Debug.Log("arrowFromFieldColor hue: " + h3);
        Color.RGBToHSV(arrowFromNoneColor, out float h4, out float _, out float _);
        Debug.Log("arrowFromFieldColor hue: " + h4);
        Thread.CurrentThread.CurrentCulture = CultureInfo.InvariantCulture;
    }
    private void Start()
    {
        SetUpActionMaps();
    }
    async void SetUpActionMaps()
    {
        CancelPreviousAsync();
        CancellationToken token = cancellationTokenSource.Token;
        try { await Awaitable.NextFrameAsync(token); } catch { return; }
        foreach (var map in playerInput.actions.actionMaps)
        {
            map.Disable();
            Debug.Log(map.name + ": " + map.enabled);
        }

        playerInput.SwitchCurrentActionMap("Graph");
    }

    /// //////////////////////////////////////// 
    ///             CREATE METHODS
    /// 
    public GraphNode CreateNode(Vector2 newNodePosition, GraphNode.NodeType type = GraphNode.NodeType.brak, float capacity = 0f, bool undoRedoAction = false, int? forcedID = null, bool addToCurrentQuarter = true)
    {
        if (forcedID.HasValue && nodeDictionary.ContainsKey(forcedID.Value))
        {
            Debug.LogWarning("Something tried to create a node with a specific ID but a node with this ID already existed: " + forcedID.Value);
            return null; // don't create a node if a node with the same ID exists
        }
        GraphNode newNode;
        if (type == GraphNode.NodeType.cwiartka)
        {
            newNode = Instantiate(quarterVerticePrefab, transform, false).GetComponent<GraphNode>();
            newNode.name += newNode.nodeID;
            if (forcedID.HasValue)
            { newNode.SetNodeID(forcedID.Value); }
            newNode.UpdateNode(newNodePosition, GraphNode.NodeType.cwiartka, capacity);
            if (addToCurrentQuarter)
            {
                currentQuarter.Add(newNode);
            }
            newNode.transform.SetAsFirstSibling(); // to make sure they are always below regular nodes
            if (!undoRedoAction)
            {
                redoStack.Clear();
            }
        }
        else
        {
            newNode = Instantiate(graphNodePrefab, transform, false).GetComponent<GraphNode>(); // replace transform if used script on a different gameobject
            //newNode = ObjectPooler.DequeueObject<NodePrefabToPool>("Nodes").GetComponent<GraphNode>();
            newNode.name += newNode.nodeID;
            if (forcedID.HasValue)
            { newNode.SetNodeID(forcedID.Value); }
            newNode.UpdateNode(newNodePosition, type, capacity);
            nodes.Add(newNode);
            // create undo action only for normal nodes
            if (!undoRedoAction)
            {
                IUndoableAction[] newUndoArray = new IUndoableAction[1];
                newUndoArray[0] = new UndoNodeCreation(newNode);
                PushStack(undoStack, ref newUndoArray);
                redoStack.Clear();
            }
        }
        nodeDictionary[newNode.nodeID] = newNode; // add node with its ID to the dictionary
        newNode.CheckIfCorrectPosition();

        return newNode;
    }
    public void CreateArrowInput(GraphNode startNode, bool undoRedoAction = false)
    {
        if (startNode.GetNodeType() == GraphNode.NodeType.cwiartka)
        {
            // select whole quarter if the double-clicked node is in a quarter
            QuarterArea area = GetQuarterAreaByBorderNode(startNode);
            
            SelectNode(startNode, true); // toggle-select the double-clicked node before toggle-selecting it again
            // if the node belongs to a quarter, select quarter's nodes when double-clicked
            if (area)
            {
                foreach (GraphNode quarterNode in area.quarterNodes)
                {
                    SelectNode(quarterNode, true);
                }
                return;
            }

            // create quarter area
            Debug.Log("CreateArrowInput - quarterEditMode");
            if (currentQuarter.Count < 3)
            {
                Debug.LogWarning("Not enough points to create an area");
                return;
            }
            QuarterArea quarterArea = Instantiate(quarterAreaPrefab, transform, false).GetComponent<QuarterArea>();
            quarterArea.InitializeQuarterBounds(currentQuarter);
            // add undo action after setting up the quarter area
            if (!undoRedoAction)
            {
                IUndoableAction[] newUndoArray = new IUndoableAction[1];
                newUndoArray[0] = new UndoQuarterAreaCreation(quarterArea);
                PushStack(undoStack, ref newUndoArray);
                redoStack.Clear();
            }

            currentQuarter.Clear();
            quarterAreas.Add(quarterArea);
        }
        else
        {
            CreateArrow(startNode);
        }
    }
    public GraphArrow CreateArrow(GraphNode startNode, GraphNode endNode = null, float flow = 0f, uint repairCost = 0, bool undoRedoAction = false, int? forcedID = null)
    {
        if (undoRedoAction && (!startNode || !endNode)) // if doing undo/redo and the nodes haven't been undo-ed yet
        {
            return null;
        }
        currentArrow = Instantiate(arrowPrefab, transform, false).GetComponent<GraphArrow>();
        if (forcedID.HasValue)
        { currentArrow.SetArrowID(forcedID.Value); }

        currentArrow.transform.position = startNode.transform.position;
        currentArrow.transform.SetAsFirstSibling();
        currentArrow.SetFromNode(startNode);
        // set arrow color depending on startNode's type
        currentArrow.UpdateArrowColor();
        currentArrow.SetToNode(cursorNode);
        startNode.AddArrowFromThis(currentArrow);
        ShowArrowInfo();
        
        arrows.Add(currentArrow);
        

        if (flow != 0f || repairCost != 0f)
        {
            currentArrow.SetArrowData(flow, repairCost);
        }
        if (endNode != null)
        {
            ApplyArrow(endNode, undoRedoAction);
        }
        return arrows[^1];
    }
    public void ApplyArrow(GraphNode endNode, bool undoRedoAction = false)
    {
        if (currentArrow != null)
        {
            // it used to search all arrows,
            // now it's optimized by only searching in arrows leading to endNode

            // check if there's an identical arrow already
            foreach (var arrow in endNode.GetArrowsToThis())
            {
                if (arrow.GetFromNode() == currentArrow.GetFromNode())
                {
                    CancelArrow();
                    Debug.LogWarning("Cancelled a duplicate arrow.");
                    return;
                }
            }
            // don't connect a node to itself
            if (currentArrow.GetFromNode() == endNode)
            {
                CancelArrow();
                Debug.LogWarning("Cancelled an arrow (fromNode == toNode).");
                return;
            }
            
            // don't connect to a quarter node
            if (endNode.GetNodeType() == GraphNode.NodeType.cwiartka)
            {
                CancelArrow();
                Debug.LogWarning("Cancelled an attempt to apply an arrow to a quarter node.");
                return;
            }


            endNode.AddArrowToThis(currentArrow);
            currentArrow.SetToNode(endNode);
            currentArrow.UpdatePosition();

            // add to undo/redo before currentArrow is set to null
            arrowDictionary[currentArrow.arrowID] = currentArrow;
            if (!undoRedoAction)
            {
                IUndoableAction[] newUndoArray = new IUndoableAction[1];
                newUndoArray[0] = new UndoArrowCreation(currentArrow);
                PushStack(undoStack, ref newUndoArray);
                redoStack.Clear();
            }

            currentArrow = null;
            ShowArrowInfo();
            FileGraphConverter.instance.UpdateNeeded();

        }
    }
    
    public void InitializeQuarterArea()
    {
        CreateArrowInput(currentQuarter[^1], true);
    }
    public async Task CheckAllNodesCorrectPosition(CancellationToken token)
    {
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.verifyingNodes);
        //await Task.Yield();
        int i = 0;
        foreach (GraphNode node in nodes)
        {
            token.ThrowIfCancellationRequested();
            node.CheckIfCorrectPosition();
            i++;
            if (i % generationBatching*20 == 0)
            {
                await Task.Yield();
            }
        }
    }

    /// ////////////////////////////////////////
    ///             SELECT METHODS
    ///             
    public void SelectNode(GraphNode node, bool multiSelect = false)
    {
        if (selectedArrows.Count > 0)
        {
            DeselectAllArrows();
        } 
        if (node == null) { DeselectAllElements(); return; } // protection against null

        if (multiSelect)
        {
            if (selectedNodes.Count == 1 && selectedNode)
            {
                selectedNode.SetSelectedIconState(false);
                selectedNode.SetMultiSelectedIconState(true);
                selectedNode = null;
            }
            if (selectedNodes.Contains(node))
            {
                selectedNodes.Remove(node);
                node.SetMultiSelectedIconState(false);
            }
            else
            {
                selectedNodes.Add(node);
                node.SetMultiSelectedIconState(true);
            }
        }
        else
        {
            foreach (GraphNode snode in selectedNodes)
            {
                snode.SetMultiSelectedIconState(false);
            }
            if (selectedNode) selectedNode.SetSelectedIconState(false);
            selectedNode = node;
            selectedNode.SetSelectedIconState(true);
            selectedNodes.Clear();
            selectedNodes.Add(node);
        }
        ShowNodeInfo();
    }
    public void SelectAllNodes()
    {
        if (selectedNode) { selectedNode.SetSelectedIconState(false); selectedNode = null; }
        if (selectedArrows.Count > 0)
        {
            DeselectAllArrows();
        }
        DeselectAllElements();
        foreach (GraphNode node in nodes)
        {
            node.SetMultiSelectedIconState(true);
            selectedNodes.Add(node);
        }
        foreach (QuarterArea quarterArea in quarterAreas)
        {
            foreach (GraphNode quarterNode in quarterArea.quarterNodes)
            {
                quarterNode.SetMultiSelectedIconState(true);
                selectedNodes.Add(quarterNode);
            }
        }
        ShowNodeInfo();
    }
    public void SelectAllArrows()
    {
        DeselectAllElements();
        foreach (GraphArrow arrow in arrows)
        {
            SelectArrow(arrow, true);
        }
    }
    void DeselectAllNodes()
    {
        if (selectedNodes.Count == 1 && selectedNode)
        {
            selectedNode.SetSelectedIconState(false);
            selectedNode.SetMultiSelectedIconState(true);
            selectedNode = null;
        }
        foreach (GraphNode snode in selectedNodes)
        {
            snode.SetMultiSelectedIconState(false);
        }
        selectedNodes.Clear();
    }
    public void DeselectAllElements()
    {
        if (selectedNode) { selectedNode.SetSelectedIconState(false); selectedNode = null; }
        DeselectAllArrows();
        DeselectAllNodes();
        ShowNodeInfo();
    }
    public void DeselectAllArrows()
    {
        foreach (GraphArrow sarrow in selectedArrows)
        {
            sarrow.SetArrowSelectedSprite(false);
        }
        selectedArrows.Clear();
    }
    public void SelectArrow(GraphArrow arrow, bool multiSelect = false)
    {
        
        if (arrow == null) { DeselectAllElements(); return; } // protection against null

        if (multiSelect)
        {
            DeselectAllNodes();
            int arrowIndex = selectedArrows.IndexOf(arrow);
            if (arrowIndex == -1) // arrow not in the list of selected arrows
            {
                selectedArrows.Add(arrow);
                arrow.SetArrowSelectedSprite(true);
            }
            else
            {
                selectedArrows.RemoveAt(arrowIndex);
                arrow.SetArrowSelectedSprite(false);
            }
        }
        else
        {
            DeselectAllElements();
            arrow.SetArrowSelectedSprite(true);
            selectedArrows.Add(arrow);
        }
        ShowArrowInfo();
    }
    public bool IsNodeSelected(GraphNode node)
    {
        return selectedNodes.Contains(node);
    }
    public async void UpdatePositionFromInputField()
    {
        CancelPreviousAsync();
        CancellationToken token = cancellationTokenSource.Token;
        float? X = null;
        float? Y = null;
        if (float.TryParse(nodeInfoPanel.xPosition.text, out float _X))
        {
            X = _X;
        }
        if (float.TryParse(nodeInfoPanel.yPosition.text, out float _Y))
        {
            Y = _Y;
        }

        //nodeInfoPanel.xPosition.text = newPosition.x.ToString();
        //nodeInfoPanel.yPosition.text = newPosition.y.ToString();
        if (selectedNodes.Count > 0 && (X.HasValue || Y.HasValue))
        {
            Vector2 newPosition;
            List<IUndoableAction> newUndoList = new();
            foreach (GraphNode node in selectedNodes)
            {
                newPosition = new(X ?? node.transform.position.x, Y ?? node.transform.position.y); // Y ?? <==> Y.HasValue ? Y.Value : 
                Debug.Log(node.gameObject.name + "position: " + node.transform.position + " | newPosition: " + newPosition + " || X: " + X + " | Y: " + Y);
                if (newPosition != (Vector2)node.transform.position)
                {
                    newUndoList.Add(new UndoNodeUpdate(selectedNodes[0]));
                    
                    node.MoveNode(newPosition, 0.01f);
                    try { await Awaitable.EndOfFrameAsync(token); } catch { return; }
                    node.CheckIfCorrectPosition();
                }
            }
            IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
            newUndoList.CopyTo(newUndoArray, 0);
            PushStack(undoStack, ref newUndoArray);
            redoStack.Clear();
        }
    }
    public void MoveElementsInfoPanel(float newY) // used when switching tabs
    {
        Transform elementsInfoPanelTransform = nodeInfoPanel.transform.parent;
        elementsInfoPanelTransform.localPosition = new(elementsInfoPanelTransform.localPosition.x, newY);
    }
    public void ShowNodeInfo()
    {
        if (!nodeInfoPanel) { return; } // there's no nodeInfoPanel on application quit, where all objects are being destroyed        
        
        if (selectedNodes.Count == 0)
        {
            elementInfoPanel.SetActive(false); // hide panel if no nodes are selected
        }
        if (selectedNodes.Count == 1)
        {
            nodeInfoPanel.gameObject.SetActive(true);
            nodeInfoPanel.xPosition.interactable = !simulatePanel.activeSelf;
            nodeInfoPanel.yPosition.interactable = !simulatePanel.activeSelf;
            nodeInfoPanel.xPosition.SetTextWithoutNotify(selectedNodes[0].GetX().ToString());
            nodeInfoPanel.yPosition.SetTextWithoutNotify(selectedNodes[0].GetY().ToString());
            nodeInfoPanel.nodeTypeSelector.SetValueWithoutNotify((int)selectedNodes[0].GetNodeType());
            nodeInfoPanel.nodeTypeSelector.SetInteractable((!simulatePanel.activeSelf && selectedNodes[0].GetNodeType() != GraphNode.NodeType.cwiartka));
            if (!simulatePanel.activeSelf)
            {
                if (selectedNodes[0].GetNodeType() == GraphNode.NodeType.browar)
                {
                    nodeInfoPanel.capacity.interactable = true;
                    nodeInfoPanel.capacityImage.enabled = true;
                    nodeInfoPanel.yieldImage.enabled = false;
                }
                else if (selectedNodes[0].GetNodeType() == GraphNode.NodeType.cwiartka)
                {
                    nodeInfoPanel.capacity.interactable = true;
                    nodeInfoPanel.capacityImage.enabled = false;
                    nodeInfoPanel.yieldImage.enabled = true;
                }
                else
                {
                    nodeInfoPanel.capacity.interactable = false;
                }
            }
            else
            {
                nodeInfoPanel.capacity.interactable = false;
            }
            nodeInfoPanel.capacity.SetTextWithoutNotify(selectedNodes[0].GetCapacity().ToString());
            elementInfoPanel.SetActive(true);
        }
        else if (selectedNodes.Count > 1) // multi-select info for nodes
        {
            elementInfoPanel.SetActive(true);
            nodeInfoPanel.gameObject.SetActive(true);
            nodeInfoPanel.xPosition.interactable = !simulatePanel.activeSelf;
            nodeInfoPanel.yPosition.interactable = !simulatePanel.activeSelf;
            //nodeInfoPanel.xPosition.interactable = false;
            //nodeInfoPanel.yPosition.interactable = false;
            nodeInfoPanel.nodeTypeSelector.SetInteractable(!simulatePanel.activeSelf);
            nodeInfoPanel.capacity.gameObject.SetActive(true);
            nodeInfoPanel.capacity.SetTextWithoutNotify(selectedNodes[0].GetCapacity().ToString());
            nodeInfoPanel.capacity.interactable = (IsSelectedNodesType(GraphNode.NodeType.browar) || IsSelectedNodesType(GraphNode.NodeType.cwiartka)) && !simulatePanel.activeSelf;

            // display placeholder if values are different
            float compareValue = selectedNodes[0].transform.position.x;
            foreach (GraphNode node in selectedNodes)
            {
                if (compareValue != node.transform.position.x)
                {
                    nodeInfoPanel.xPosition.SetTextWithoutNotify(string.Empty);
                    break;
                }
                // update displayed value if all values are equal
                nodeInfoPanel.xPosition.SetTextWithoutNotify(selectedNodes[0].GetX().ToString());
            }
            compareValue = selectedNodes[0].transform.position.y;
            foreach (GraphNode node in selectedNodes)
            {
                if (compareValue != node.transform.position.y)
                {
                    nodeInfoPanel.yPosition.SetTextWithoutNotify(string.Empty);
                    break;
                }
                // update displayed value if all values are equal
                nodeInfoPanel.yPosition.SetTextWithoutNotify(selectedNodes[0].GetY().ToString());
            }
            // disable type selector if a quarter node is selected
            foreach (GraphNode node in selectedNodes)
            {
                if (node.GetNodeType() == GraphNode.NodeType.cwiartka)
                {
                    nodeInfoPanel.nodeTypeSelector.SetInteractable(false);
                    break;
                }
            }
            
            compareValue = selectedNodes[0].GetCapacity();
            foreach (GraphNode node in selectedNodes)
            {
                if (compareValue != node.GetCapacity())
                {
                    nodeInfoPanel.capacity.SetTextWithoutNotify(string.Empty);
                    break;
                }
            }
        }
    }
    public void ShowArrowInfo()
    {
        if (!nodeInfoPanel) { return; } // there's no nodeInfoPanel on application quit, where all objects are being destroyed

        if (selectedArrows.Count == 0)
        {
            elementInfoPanel.SetActive(false); // hide panel if no arrows are selected
        }
        if (selectedArrows.Count > 1)
        {
            float compareFlow = selectedArrows[0].GetFlow();
            float compareCost = selectedArrows[0].GetRepairCost();
            bool differentFlows = false, differentCosts = false;
            elementInfoPanel.SetActive(true);
            nodeInfoPanel.gameObject.SetActive(false);
            foreach (GraphArrow arrow in selectedArrows)
            {
                if (differentFlows && differentCosts)
                {
                    break;
                }
                if (compareFlow != arrow.GetFlow())
                {
                    differentFlows = true;
                }
                if (compareCost != arrow.GetRepairCost())
                {
                    differentCosts = true;
                }
            }
            arrowInfoPanel.flowInputField.SetTextWithoutNotify(differentFlows ? string.Empty : selectedArrows[0].GetFlow().ToString());
            arrowInfoPanel.flowInputField.interactable = !simulatePanel.activeSelf;
            arrowInfoPanel.repairCostInputField.SetTextWithoutNotify(differentCosts ? string.Empty : selectedArrows[0].GetRepairCost().ToString());
            arrowInfoPanel.repairCostInputField.interactable = !simulatePanel.activeSelf;
        }
        else if (selectedArrows.Count == 1)
        {
            elementInfoPanel.SetActive(true);
            nodeInfoPanel.gameObject.SetActive(false);
            arrowInfoPanel.flowInputField.SetTextWithoutNotify(selectedArrows[0].GetFlow().ToString());
            arrowInfoPanel.flowInputField.interactable = !simulatePanel.activeSelf;
            arrowInfoPanel.repairCostInputField.SetTextWithoutNotify(selectedArrows[0].GetRepairCost().ToString());
            arrowInfoPanel.repairCostInputField.interactable = !simulatePanel.activeSelf;
        }
    }
    public void UndoLastAction()
    {
        
        // trying to turn off the edit mode or trying to delete unattached nodes here
        // always seems to cause errors, so locked undo and redo instead
        quarterModeToggle.isOn = false;
        
        if (undoStack.Count > 0)
        {
            DeselectAllElements();
            IUndoableAction[] actions = undoStack.Last.Value;
            undoStack.RemoveLast();
            Debug.Log($"undoStack.Count: {undoStack.Count}");
            foreach (IUndoableAction action in actions)
            {
                action.Undo();
            }
            // add the undo-ed element back to redoStack
            PushStack(redoStack, ref actions);
        }
    }
    public void RedoLastAction()
    {
        quarterModeToggle.isOn = false;

        if (redoStack.Count > 0)
        {
            DeselectAllElements();
            IUndoableAction[] actions = redoStack.Last.Value;
            redoStack.RemoveLast();
            Debug.Log($"redoStack.Count: {redoStack.Count}; action: {actions.GetType()}");
            foreach (IUndoableAction action in actions)
            {
                action.Redo();
            }
            // add the redo-ed element back to undoStack
            PushStack(undoStack, ref actions);
        }
    }
    public void PushStack(LinkedList<IUndoableAction[]> stack, ref IUndoableAction[] newActions)
    {
        // limit the stack to 100 elements
        if (stack.Count > 99)
        {
            stack.RemoveFirst();
        }
        // add the element to the stack
        stack.AddLast(newActions);
    }

    /// ////////////////////////////////////////
    ///             DELETE METHODS
    ///             
    public void CancelArrow()
    {
        if (currentArrow)
        {
            Debug.Log("Cancelled arrow");
            Destroy(currentArrow.gameObject);
        }
    }
    public void DeleteSelected(bool undoRedoAction = false)
    {
        if (selectedNodes.Count == 0 && selectedArrows.Count > 0)
        {
            if (!undoRedoAction)
            {
                IUndoableAction[] newUndoArray = new IUndoableAction[selectedArrows.Count];
                for (int i=0; i<selectedArrows.Count; i++)
                {
                    newUndoArray[i] = new UndoArrowDeletion(selectedArrows[i]);
                }
                PushStack(undoStack, ref newUndoArray);
                redoStack.Clear();
            }
            foreach (GraphArrow sarrow in selectedArrows)
            {
                Destroy(sarrow.gameObject);
            }
            selectedArrows.Clear();
        }
        else
        {
            // create a list of actions to undo
            // must be a list, because unattached quarter nodes do not count individually as actions
            List<IUndoableAction> newUndoList = new(selectedNodes.Count);
            foreach (GraphNode snode in selectedNodes)
            {
                if (snode.GetNodeType() == GraphNode.NodeType.cwiartka) // if node is a quarter node
                {
                    QuarterArea quarterArea = GetQuarterAreaByBorderNode(snode); // find its quarter area
                    if (quarterArea != null)
                    {
                        newUndoList.Add(new UndoQuarterAreaDeletion(quarterArea));
                        quarterArea.DeleteQuarterArea();
                        quarterAreas.Remove(quarterArea); // remove the empty quarter from list
                    }
                    else // the quarter node to delete is not in an area yet
                    {
                        foreach (GraphNode node in currentQuarter)
                        {
                            Destroy(node.gameObject);
                        }
                        currentQuarter.Clear();
                    }
                }
                else // if node is not a quarter node
                {
                    // add arrows connected to the node to be undo-ed at the end
                    newUndoList.Add(new UndoNodeDeletion(snode));
                    RemoveNode(snode);
                    snode.BeforeDestroy();
                    Destroy(snode.gameObject);
                }
            }
            if (!undoRedoAction && newUndoList.Count > 0) // also check if there's anything in the list (there may be nothing if the last action was undoing creating quarter nodes without a quarter area)
            {
                // convert list to array and add to stack
                IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
                newUndoList.CopyTo(newUndoArray, 0);
                PushStack(undoStack, ref newUndoArray);
                redoStack.Clear();
            }
            selectedNodes.Clear();
        }

        FileGraphConverter.instance.UpdateNeeded();
        elementInfoPanel.SetActive(false);
    }
    public void RemoveNode(GraphNode node)
    {
        nodeDictionary.Remove(node.nodeID); // remove id from dictionary
        nodes.Remove(node); // remove node
    }
    public void RemoveArrow(GraphArrow arrow)
    {
        arrowDictionary.Remove(arrow.arrowID);
        arrows.Remove(arrow);
    }
    public async void ClearGraph()
    {
        CancelPreviousAsync();
        CancellationToken token = cancellationTokenSource.Token;
        LoadingScreenText.currentOperationState = LoadingScreenText.OperationState.clearingGraph;
        loadingScreenPanel.SetActive(true);
        await Awaitable.EndOfFrameAsync(token);
        await ClearGraphTask(token);
        loadingScreenPanel.SetActive(false);
        FileGraphConverter.instance.UpdateNeeded();
        generatingGraph = false;
    }
    public async Task ClearGraphTask(CancellationToken token)
    {
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.clearingGraph);
        await Task.Yield();
        int i = 0;
        Debug.Log("ClearGraphTask began");
        try
        {
            foreach (GraphNode node in nodes)
            {
                token.ThrowIfCancellationRequested();
                node.BeforeDestroy();
                Destroy(node.gameObject);
                i++;
                if (i % generationBatching == 0)
                {
                    await Task.Yield();
                }
            }
            GraphNode.generatingGraph = true; // skips some checks for quarters
            foreach (var quarter in quarterAreas)
            {
                token.ThrowIfCancellationRequested();
                QuarterArea quarterArea = GetQuarterAreaByBorderNode(quarter.quarterNodes[0]);
                if (quarterArea != null)
                {
                    quarterArea.DeleteQuarterArea();
                }
                else // the quarter node to delete is not in an area yet
                {
                    foreach (GraphNode node in currentQuarter)
                    {
                        Destroy(node.gameObject);
                    }
                    currentQuarter.Clear();
                }
                i++;
                if (i % generationBatching == 0)
                {
                    await Task.Yield();
                }
            }
            quarterAreas.Clear();
        }
        catch // clearing cancelled
        {
            selectedNodes.Clear();
            // lists contain empty elements after destroying some objects, remove missing elements
            nodes.RemoveAll(x => x == null);
            quarterAreas.RemoveAll(x => x == null);
            foreach (var quarter in quarterAreas)
            {
                quarter.quarterNodes.RemoveAll(x => x == null);
            }
            Debug.Log("ClearGraphTask cancelled");
            return;
        }
        quarterModeToggle.isOn = false; // removes quarter nodes without quarter area
        selectedNodes.Clear();
        nodes.Clear();
        quarterAreas.Clear();
        redNodes.Clear();
        nodeDictionary.Clear();
        GraphNode.nextID = 0;
        GraphArrow.nextID = 0;
        arrowDictionary.Clear();
        await Task.Yield();
        token.ThrowIfCancellationRequested();
        if (transform.childCount > 0)
        {
            while (transform.childCount > 0) // if some objects are left other than the cursor node
            {
                try { Destroy(transform.GetChild(0).gameObject); }// force destroy all remaining objects (in case of a previous file read fail)
                catch { Debug.LogWarning("ClearGraphTask got an error while deleting leftover children"); } // don't leave the method if suddenly no child found
                await Task.Yield();
                token.ThrowIfCancellationRequested();
            } // don't finish the task until all arrows have been destroyed
        }
        arrows.Clear();
        undoStack.Clear();
        redoStack.Clear();
        await Task.Yield();
        token.ThrowIfCancellationRequested();
        Debug.Log("ClearGraphTask finished");
        GraphNode.generatingGraph = false;
    }


    /// ////////////////////////////////////////
    ///             SETTERS
    ///             
    public void SetDragThreshold(bool state) { dragThreshold = state; }
    public void SetDragThresholdValue(float sliderValue) { dragThresholdValue = sliderValue * 0.2f; } // used by slider in settings
    public void SetSnapToGrid(bool state) { snapToGrid = state; }
    //public void SetAutoFlow(bool state) { autoFlow = state; } // used by button in settings
    
    public void SetGridSize(float newSize)
    {
        gridSize = Mathf.Floor(newSize*100f)/100f;
        // if the camera's view size is 15 times larger than the grid size, don't show the grid
        //EndlessGrid.instance.gameObject.SetActive(Camera.main.orthographicSize < gridSize * 15);
        EndlessGrid.instance.transform.localScale = new(gridSize, gridSize, 1f);
        
        EndlessGrid.instance.ForceUpdateGridPosition();
    }
    public void SetGridSizeFromInput(string inputString)
    {
        if (float.TryParse(inputString, out float newSize))
        {
            if (newSize < 0.01f)
            {
                newSize = 0.01f;
            }
            gridSizeInputField.text = newSize.ToString("0.##");

            SetGridSize(newSize);
        }
        else // failed to parse - empty input field
        {
            newSize = 0.01f;
            gridSizeInputField.text = newSize.ToString("0.##");
            gridSizeInputField.onDeselect.Invoke(gridSizeInputField.text);
        }
    }
    void SetArrowMainColor(float value, ref Color colorReference)
    {
        // convert color to HSV
        Color.RGBToHSV(colorReference, out _, out float s, out float v);
        // set value as hue and convert back to RGB
        colorReference = Color.HSVToRGB(value, s, v);
        // update all arrows' colors
        foreach (GraphArrow arrow in arrows)
        {
            arrow.UpdateArrowColor();
        }
    }
    public void SetArrowFromFieldColor(float value) { SetArrowMainColor(value, ref arrowFromFieldColor); }
    public void SetArrowFromBreweryColor(float value) { SetArrowMainColor(value, ref arrowFromBreweryColor); }
    public void SetArrowFromPubColor(float value) { SetArrowMainColor(value, ref arrowFromPubColor); }
    public void SetArrowFromNoneColor(float value) { SetArrowMainColor(value, ref arrowFromNoneColor); }
    public void SetgenerationBatchingValue(float value) { generationBatching = (int)value*10; }

    /// ////////////////////////////////////////
    ///             GETTERS
    ///             
    public bool GraphCorrect()
    {
        return (GetFirstIncorrectElementsPosition() == Vector2.zero);
    }
    public Vector2 GetFirstIncorrectElementsPosition()
    {
        if (redNodes.Count > 0)
        {
            Debug.Log("The graph contains red nodes.");
            return redNodes[0].transform.position;
        }
        foreach (QuarterArea quarterArea in quarterAreas)
        {
            if (!quarterArea.IsAreaCorrect())
            {
                Debug.Log("The graph contains concave quarters.");
                return quarterArea.quarterNodes[0].transform.position;
            }
        }
        return Vector2.zero; // no incorrect element found
    }
    public List<GraphNode> GetNodes() { return nodes; }
    public int GetNodesCount() { return nodes.Count; }
    public List<GraphArrow> GetArrows() { return arrows; }
    public int GetArrowsCount() { return arrows.Count; }
    public List<QuarterArea> GetQuarters() { return quarterAreas; }
    public int GetQuartersCount() { return quarterAreas.Count; }
    public List<GraphNode> GetSelectedNodes() { return selectedNodes; }
    public float GetBreweriesConversionRate() { return breweriesConversionRate; }
    public bool GetDragThreshold() { return dragThreshold; }
    public float GetDragThresholdValue() { return dragThresholdValue; }
    public bool GetSnapToGrid() { return snapToGrid; }
    public float GetGridSize() { return gridSize; }
    public int GetGenerationBatching() { return generationBatching; }
    public GraphArrow GetCurrentArrow() { return currentArrow; }
    public QuarterArea GetQuarterAreaByBorderNode(GraphNode node)
    {
        foreach (QuarterArea quarterArea in quarterAreas)
        {
            if (quarterArea.quarterNodes.Contains(node))
            {
                return quarterArea;
            }
        }
        return null;
    }
    public List<GraphNode> GetRedNodes() { return redNodes; }
    public bool TryGetNodeByID(int id, out GraphNode node)
    {
        return nodeDictionary.TryGetValue(id, out node);
    }
    public bool TryGetArrowByID(int id, out GraphArrow arrow)
    {
        return arrowDictionary.TryGetValue(id, out arrow);
    }
    public GraphNode FindNodeByPosition(Vector3 position)
    {
        foreach (GraphNode node in nodes)
        {
            if (node.transform.position == position)
            {
                Debug.Log($"Node at position {(Vector2)position}: {node}");
                return node;
            }
        }
        return null;
    }
    public GraphArrow FindArrowByNodes(GraphNode fromNode, GraphNode toNode)
    {
        // find the arrow fromNode -> toNode
        foreach (GraphArrow arrow in fromNode.GetArrowsFromThis())
        {
            if (arrow.GetToNode() == toNode)
            {
                Debug.Log($"Arrow from {fromNode} to {toNode}: {arrow}");
                return arrow;
            }
        }
        return null;
    }
    bool IsSelectedNodesType(GraphNode.NodeType comparedNodeType)
    {
        foreach (GraphNode node in selectedNodes)
        {
            if (node.GetNodeType() != comparedNodeType) return false;
        }
        return true;
    }
    public Sprite GetNodeSprite(int index) { return nodeSprites[index]; }




    /// ////////////////////////////////////////
    ///             MODIFIER METHODS
    ///
    
    public void UpdateType() // used in UI dropdown
    {
        IUndoableAction[] newUndoArray = new IUndoableAction[selectedNodes.Count];
        for (int i=0; i<selectedNodes.Count; i++)
        {
            newUndoArray[i] = new UndoNodeUpdate(selectedNodes[i]); // save old type for undo
            selectedNodes[i].ChangeNodeType((GraphNode.NodeType)nodeInfoPanel.nodeTypeSelector.value);
        }
        // update stack (this method is called only when using the UI dropdown)
        Debug.Log("updateType");
        PushStack(undoStack, ref newUndoArray);
        redoStack.Clear();

        //if (autoFlow) { foreach (GraphNode snode in selectedNodes) snode.GenerateFlows(); }
        ShowNodeInfo();
    }
    public void UpdateCapacityFromInput()
    {
        UpdateCapacity();
    }
    public void UpdateCapacity(bool undoRedoAction = false, float undoCapacity = -1f) // used in UI dropdown and by undo-redo
    {
        Debug.Log("UpdateCapacity");
        float newCapacity;
        if (undoRedoAction && undoCapacity != -1f)
        {
            newCapacity = undoCapacity;
        }
        else
        {
            if (!float.TryParse(nodeInfoPanel.capacity.text, out float newCapacity2))
            {
                newCapacity2 = 0f;
            }
            newCapacity = Mathf.Floor(newCapacity2*100f)/100f;
            if (newCapacity < 0) { newCapacity = -newCapacity; }
            if (newCapacity2 != newCapacity) { nodeInfoPanel.capacity.text = newCapacity.ToString(); }
        }
        List<IUndoableAction> newUndoList = new(selectedNodes.Count);

        for (int i = 0; i < selectedNodes.Count; i++)
        {
            if (!undoRedoAction && selectedNodes[i].GetCapacity() != newCapacity) // only when there's a change
            {
                newUndoList.Add(new UndoNodeUpdate(selectedNodes[i])); // save old type for undo
            }
            
            // update capacity only allowed in breweries and quarters
            if (selectedNodes[i].GetNodeType() == GraphNode.NodeType.browar)
            {
                selectedNodes[i].SetCapacity(newCapacity);
            }
            
            if (selectedNodes[i].GetNodeType() == GraphNode.NodeType.cwiartka)
            {
                Debug.Log("snode.GetNodeType() == GraphNode.NodeType.cwiartka");
                QuarterArea quarterArea = GetQuarterAreaByBorderNode(selectedNodes[i]);
                Debug.Log("quarterArea = " + quarterArea);
                if (quarterArea != null)
                {
                    foreach (GraphNode node in quarterArea.quarterNodes)
                    {
                        node.SetCapacity(newCapacity);
                    }
                    quarterArea.UpdateFieldsYield();
                }
                else // quarter node not found in any quarter area, it's in current quarter
                {
                    foreach (GraphNode node in currentQuarter)
                    {
                        node.SetCapacity(newCapacity);
                    }
                }
            }
        }
        // convert list to array and add to stack (if the list is not empty)
        if (!undoRedoAction && newUndoList.Count > 0)
        {
            IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
            newUndoList.CopyTo(newUndoArray, 0);
            // update stack (this method is called only when using the UI dropdown)
            PushStack(undoStack, ref newUndoArray);
            redoStack.Clear();
        }

        //if (autoFlow) { foreach (GraphNode snode in selectedNodes) snode.GenerateFlows(); }
    }
    public void UpdateArrowFlow() // used by input fields in Arrow Info Panel
    {
        if (!float.TryParse(arrowInfoPanel.flowInputField.text, out float newFlow))
        {
            newFlow = 0f;
        }
        if (newFlow < 0) { newFlow = -newFlow; }
        List<IUndoableAction> newUndoList = new();
        foreach (GraphArrow sarrow in selectedArrows)
        {
            if (sarrow && newFlow != sarrow.GetFlow() )
            {
                newUndoList.Add(new UndoArrowUpdate(sarrow));
                sarrow.SetArrowData(newFlow);
            }
        }
        if (newUndoList.Count > 0)
        {
            IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
            newUndoList.CopyTo(newUndoArray, 0);
            // update stack (this method is called only when using the UI dropdown)
            PushStack(undoStack, ref newUndoArray);
            redoStack.Clear();
        }
    }
    public void UpdateArrowCost() // used by input fields in Arrow Info Panel
    {
        if (!uint.TryParse(arrowInfoPanel.repairCostInputField.text, out uint newRepairCost))
        {
            newRepairCost = 0;
        }
        List<IUndoableAction> newUndoList = new();
        foreach (GraphArrow sarrow in selectedArrows)
        {
            if (sarrow && newRepairCost != sarrow.GetRepairCost())
            {
                newUndoList.Add(new UndoArrowUpdate(sarrow));
                sarrow.SetArrowData(sarrow.GetFlow(), newRepairCost);
            }
        }
        if (newUndoList.Count > 0)
        {
            IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
            newUndoList.CopyTo(newUndoArray, 0);
            // update stack (this method is called only when using the UI dropdown)
            PushStack(undoStack, ref newUndoArray);
            redoStack.Clear();
        }
    }
    /*public void UpdateArrowValues() // used by input fields in Arrow Info Panel
    {
        // if input fields empty, set them to 0
        if(!float.TryParse(arrowInfoPanel.flowInputField.text, out float newFlow))
        {
            newFlow = 0f;
        }
        if (!float.TryParse(arrowInfoPanel.repairCostInputField.text, out float newRepairCost))
        {
            newRepairCost = 0f;
        }
        List<IUndoableAction> newUndoList = new();
        foreach (GraphArrow sarrow in selectedArrows)
        {
            if (sarrow && (newFlow != sarrow.GetFlow() || newRepairCost != sarrow.GetRepairCost()))
            {
                newUndoList.Add(new UndoArrowUpdate(sarrow));
                sarrow.SetArrowData(newFlow, newRepairCost);
            }
        }
        if (newUndoList.Count > 0)
        {
            IUndoableAction[] newUndoArray = new IUndoableAction[newUndoList.Count];
            newUndoList.CopyTo(newUndoArray, 0);
            // update stack (this method is called only when using the UI dropdown)
            PushStack(undoStack, ref newUndoArray);
            redoStack.Clear();
        }
    }*/
    public bool MoveCurrentArrow()
    {
        if(currentArrow == null) return false;
        currentArrow.UpdatePosition();
        return true;
    }
    public void SnapUnattachedArrow(GraphNode node)
    {
        currentArrow.SetToNode(node ? node : cursorNode);
    }
    public void ResetCameraPosition()
    {
        Camera.main.transform.position = new Vector3(0f, 0f, -10f);
        EndlessGrid.instance.UpdateGridPosition();
    }
    public void ShowEntireGraph()
    {
        if (nodes.Count == 0)
        {
            ResetCameraPosition();
        }
        else if (nodes.Count == 1)
        {
            Camera.main.transform.position = new Vector3(nodes[0].transform.position.x, nodes[0].transform.position.y, -10f);
        }
        else
        {
            // get min and max bounds
            Vector2 min = nodes[0].transform.position;
            Vector2 max = nodes[0].transform.position;

            foreach (GraphNode node in nodes)
            {
                // remember the most extreme positions
                Vector2 pos = node.transform.position;
                min = Vector2.Min(min, pos);
                max = Vector2.Max(max, pos);
            }

            Vector2 center = (min + max) / 2f;
            Vector2 size = max - min;

            // move camera to center
            Camera.main.transform.position = new Vector3(center.x, center.y, -10f);

            // adjust orthographic size to fit entire bounds
            float screenRatio = (float)Screen.width / Screen.height;
            float targetSize = Mathf.Max(1f, size.y / 2f, (size.x / screenRatio) / 2f); // minimum targetSize is 1f

            Camera.main.orthographicSize = targetSize * 1.2f; // 1.2f is padding
            EndlessGrid.instance.UpdateGridPosition(); // refresh grid's position and scale
        }
    }
    public void MoveToIncorrectElement()
    {
        Vector2 newPosition;
        if ((newPosition = GetFirstIncorrectElementsPosition()) != Vector2.zero)
        {
            Camera.main.transform.position = new(newPosition.x, newPosition.y, -10f);
        }
        else
        {
            Debug.LogWarning("MoveToIncorrectElement(): no incorrect element found");
        }
    }
    public void ChangeElementsSize(float newSize)
    {
        newSize /= 10f;
        graphNodePrefab.transform.localScale = new(newSize, newSize);
        arrowPrefab.transform.localScale = new(newSize, newSize);
        GraphArrow.UpdateOffsetRadius(newSize / 2f - 0.05f);
        foreach (GraphNode node in nodes)
        {
            node.transform.localScale = new(newSize, newSize);
        }
        foreach (GraphArrow arrow in arrows)
        {
            arrow.transform.localScale = new(newSize, newSize);
            arrow.UpdatePosition();
        }
    }
    public void CancelPreviousAsync()
    {
        if (cancellationTokenSource != null)
        {
            cancellationTokenSource.Cancel();
            cancellationTokenSource.Dispose();
        }
        cancellationTokenSource = new CancellationTokenSource();
        GraphNode.generatingGraph = false;
        Debug.Log("GraphManager: Async tasks cancelled.");
    }
    
}
