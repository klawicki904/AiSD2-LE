using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class Tab : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] TabGroup tabGroup;

    public Image background;

    /*private void Start()
    {
        background = GetComponent<Image>();
        //TabGroup.Subscribe(this);
    }*/
#if UNITY_EDITOR
    [ExecuteInEditMode]
    private void OnValidate()
    {
        background = GetComponent<Image>();
        tabGroup = FindAnyObjectByType<TabGroup>();
    }
#endif
    public void SelectTab()
    {
        tabGroup.OnTabSelected(this);
    }
    public void OnPointerEnter(PointerEventData eventData)
    {
        tabGroup.OnTabEnter(this);
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        tabGroup.OnTabExit(this);
    }
}
