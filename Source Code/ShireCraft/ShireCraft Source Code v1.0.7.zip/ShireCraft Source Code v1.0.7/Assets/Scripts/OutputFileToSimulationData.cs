using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Text;
using System;
using System.IO;
using System.Threading;
using System.Globalization;

public class OutputFileToSimulationData : MonoBehaviour
{
    [SerializeField] TMP_InputField conversionRateInputField;
    [SerializeField] TextMeshProUGUI beerSoFarText;
    [SerializeField] TextMeshProUGUI costSoFarText;
    [SerializeField] TextMeshProUGUI currentSolutionLineText;
    [SerializeField] TMP_InputField outputDataInputField;
    [SerializeField] private GameObject loadingScreenPanel;
    [SerializeField] Slider stepsSlider;
    [SerializeField] Button simulationTab; // simulationTab is clicked after successfully reading the file
    [SerializeField] Button fileTab; // fileTab is re-opened if the file fails to load
    public static bool simulationGenerated { get; private set; } = false;
    [SerializeField] List<GraphArrow> arrowsOrder = new(); // arrow to highlight in each step, ordered by steps
    Dictionary<GraphArrow, decimal> originalCosts = new();
    Dictionary<GraphArrow, int> arrowsVisited = new(); // keeps track of which in which step arrows have been visited for the first time
    Dictionary<int, List<KeyValuePair<int, float>>> nodeUpdates = new(); // keeps track of the nodes' capacities changes at given step
    [SerializeField] List<decimal> flowsOrder = new(); // flows to adjust in the arrow each step, ordered by steps
    [SerializeField] decimal beerSoFar = 0, costSoFar = 0;
    [SerializeField] int currentStep = 0;
    string[] solutionLines;
    //[SerializeField] int solutionBeginLine = 0; // the line of the text file the solution starts at
    [SerializeField] float autoplaySpeed = 1f;

    //[SerializeField] Sprite arrowDefaultSprite;
    //[SerializeField] Sprite arrowHighlightedSprite; // arrow's sprite when shown as a step in simulation

    [SerializeField] GameObject playButton;
    [SerializeField] Button switchToInputLayoutButton; // toggles the visibility of buttons in File tab
    [SerializeField] Button switchToOutputLayoutButton; // toggles the visibility of buttons in File tab

    //public static bool simulationUpdateNeeded;
    enum GraphInputType
    {
        conversionRate,
        nodes,
        roads,
        solution,
        quarters
    }
    GraphInputType readingNow;

    private Dictionary<int, GraphNode> nodeTransforms = new();

    CancellationTokenSource autoplayTokenSource;
    public static OutputFileToSimulationData instance { get; private set; }
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
        readingNow = GraphInputType.solution;
        float t1 = 0f;
        float t2 = 5.69f;
        Debug.Log("0 + 5.69 = " + (t1 + t2));
    }
    public async void ConvertSimulationGraphMain()
    {
        Debug.Log("ConvertSimulationGraphMain");
        if(simulationGenerated) { ResetSimulation(); }
        
        loadingScreenPanel.SetActive(true); // show loading screen

        await ConvertGraphMainAsync();
    }
    async Task ConvertGraphMainAsync()
    {
        //FileGraphConverter.instance.CancelPreviousConversion();
        CancellationToken token = FileGraphConverter.conversionTokenSource.Token;
        // clear the graph of all children (nodes and arrows)
        simulationGenerated = true;
        simulationTab.onClick.Invoke(); // open the simulation tab
        //ResetSimulation();
        token.ThrowIfCancellationRequested();
        await GraphManager.instance.ClearGraphTask(token);
        /*Debug.Log(name + ": token: " + token.IsCancellationRequested);
        token.ThrowIfCancellationRequested();*/
        ConvertOutputToSimulationGraphAsync(token);
    }

    async void ConvertOutputToSimulationGraphAsync(CancellationToken token)
    {
        Debug.Log("Converting Output file to simulation graph");
        nodeTransforms.Clear();
        GraphNode.generatingGraph = true;
        string line = String.Empty;
        int currentLine = 0;
        float savedGridSize = GraphManager.instance.GetGridSize();
        // save path to the simulation file, because it gets resetted during generation
        string simulationFilePath = FileToTMPInput.simulationFilePath;
        try
        {
            token.ThrowIfCancellationRequested();
            // variables for use by arrows and StringBuilder
            int elementID = 0, fromID, toID, simulationSteps = 0, arrowsCount = 0;
            float flow;
            uint repairCost;
            List<int> augumentingPathsBegins = new(); // indexes of steps, where a new augmenting path begins
            StringBuilder solutionData = new();
            List<KeyValuePair<int, float>> fields = new(); // store IDs and capacity of fields to convert to edge list later (adding the start node)
            List<int> pubs = new(); // store IDs of pubs to add sink node later
            GraphArrow solutionArrow = null; // temp arrow for calculating solution
            const Int32 BufferSize = 128;
            token.ThrowIfCancellationRequested();
            GraphManager.instance.SetGridSize(0.01f);
            using (var fileStream = File.OpenRead(simulationFilePath))
            {
                using var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, BufferSize);
                while ((line = streamReader.ReadLine()) != null)
                {
                    //line = line.Replace('.', ','); // replace dots with commas (C++ uses dots in decimal numbers)
                    token.ThrowIfCancellationRequested();
                    if (currentLine % GraphManager.generationBatching == 0)
                    {
                        await Task.Yield();
                    }
                    token.ThrowIfCancellationRequested();
                    currentLine++;
                    line = line.Trim();
                    if (string.IsNullOrEmpty(line))
                        continue;

                    switch (line.ToLower())
                    {
                        case "konwersja:":
                            {
                                readingNow = GraphInputType.conversionRate;
                                Debug.Log($"readingNow: {readingNow}");
                                GraphInputManager.instance.SetQuarterEditMode(false);
                                continue;
                            }
                        case "punkty:":
                            {
                                if (readingNow != GraphInputType.conversionRate)
                                {
                                    throw new FormatException("The output file is missing the keyword \"Konwersja:\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.nodes;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingNodes);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                GraphInputManager.instance.SetQuarterEditMode(false);
                                continue; // go to next line
                            }
                        case "drogi:":
                            {
                                if (readingNow != GraphInputType.nodes)
                                {
                                    throw new FormatException("The output file is missing the keyword \"Punkty:\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.roads;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingArrows);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                GraphInputManager.instance.SetQuarterEditMode(false);
                                GraphNode.nextID = elementID + 1; // set the next node ID to be the last of read from file + 1
                                continue; // go to next line
                            }
                        case "�wiartki:":
                            {
                                if (readingNow != GraphInputType.roads)
                                {

                                    throw new FormatException("The input file is missing the keyword \"Drogi:\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.quarters;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingQuarters);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                GraphArrow.nextID = arrowsCount; // set the next arrow ID to be the last of read IDs + 1
                                continue; // go to next line
                            }
                        case "rozwi�zanie:":
                            {
                                if (readingNow != GraphInputType.quarters)
                                {
                                    throw new FormatException("The output file is missing the keyword \"�wiartki:\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.solution;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingRoutes);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                // add an empty step to revert highlighted arrows correctly on reset
                                solutionData.AppendLine(line);
                                augumentingPathsBegins.Add(simulationSteps);
                                arrowsOrder.Add(null);
                                flowsOrder.Add(0);
                                simulationSteps++;
                                continue; // go to next line
                            }

                        default: break;
                    }

                    string[] parts = line.Split(' ');
                    //Debug.Log($"parts.Length: {parts.Length}: {String.Join(" ", parts)}");
                    if (parts.Length == 0) { continue; } // skip empty lines
                    switch (readingNow)
                    {
                        case GraphInputType.conversionRate:
                            {
                                float value = float.Parse(parts[0], CultureInfo.InvariantCulture); // throws exception if value is not a float
                                // make sure the value is in the correct range
                                if (value < 0f) throw new ArgumentOutOfRangeException("Breweries conversion rate too low");
                                Debug.Log("parts[0]: " + parts[0]);
                                conversionRateInputField.text = value.ToString();
                                break;
                            }
                        case GraphInputType.nodes:
                            {
                                //     0     1  2    3     4        5 6 7  8 9 10 11         12 13
                                // ie. Punkt 1: typ: pole; pozycja: x = 0, y = 2; wydajno��: 30 ton.
                                // parse node
                                /*Debug.Log($"parts[1].Substring(0, parts[1].Length - 1): {parts[1][..^1]}"); // [..^1] = .Substring(0, x.Length - 1)
                                Debug.Log($"parts[3].Substring(0, parts[3].Length - 1).ToLower(): {parts[3][..^1].ToLower()}");
                                Debug.Log($"float.Parse(parts[8].Substring(0, parts[8].Length - 1)): {float.Parse(parts[7][..^1], CultureInfo.InvariantCulture)}");
                                Debug.Log($"float.Parse(parts[10].Substring(0, parts[10].Length - 1)): {float.Parse(parts[10][..^1], CultureInfo.InvariantCulture)}");*/
                                elementID = int.Parse(parts[1][..^1]);
                                string typeStr = parts[3][..^1].ToLower();
                                float x = float.Parse(parts[7][..^1], CultureInfo.InvariantCulture);
                                float y = float.Parse(parts[10][..^1], CultureInfo.InvariantCulture);


                                GraphNode.NodeType type = GraphNode.GetNodeTypeByName(typeStr);

                                float capacity = 0;
                                switch (type)
                                {
                                    case GraphNode.NodeType.pole: // pole: "wydajno��"
                                    case GraphNode.NodeType.browar: // browar: "pojemno��"
                                        {
                                            capacity = float.Parse(parts[12], CultureInfo.InvariantCulture);
                                            break;
                                        }
                                    default: break;
                                }

                                Vector3 position = new(x, y, 0f);

                                GraphNode node = GraphManager.instance.CreateNode(position, type, capacity, true, elementID);
#if UNITY_EDITOR
                                //node.name = $"Node_{elementID}";
                                Debug.Log("Created node " + node + " with id " + elementID);
#endif
                                nodeTransforms[elementID] = node;
                                break;
                            }
                        case GraphInputType.roads:
                            {
                                //     0     1  2 3    4   5  6       7   8  9  10      11  12 13      14  15  16             17 18   19    20       21
                                // ie. Droga 1: z pola [1] na pozycji (0, 2) do browaru [3] na pozycji (4, 2): przepustowo��: 25 ton; koszt naprawy: 0 srebrnych pens�w.
                                // parse arrow

                                /*Debug.Log($"parts[4][1..]: {parts[4][1..^1]}");
                                Debug.Log($"parts[11][1..]: {parts[11][1..^1]}");
                                Debug.Log($"parts[17]: {parts[17]}");
                                Debug.Log($"parts[21]: {parts[21]}");*/

                                elementID = int.Parse(parts[1][..^1]); // [1..^1] = .Substring(1, x.Length - 1)
                                fromID = int.Parse(parts[4][1..^1]); // [1..^1] = .Substring(1, x.Length - 1)
                                toID = int.Parse(parts[11][1..^1]);
                                flow = float.Parse(parts[17], CultureInfo.InvariantCulture);
                                repairCost = uint.Parse(parts[21], CultureInfo.InvariantCulture);
                                GraphNode fromT = nodeTransforms[fromID];
                                GraphNode toT = nodeTransforms[toID];
                                GraphArrow newArrow = GraphManager.instance.CreateArrow(fromT, toT, flow, repairCost, true, elementID);
                                if (newArrow == null)
                                {
                                    Debug.LogWarning("Failed to create an arrow while parsing solution data");
                                }
                                else
                                {
                                    originalCosts[newArrow] = repairCost;
                                }
                                arrowsCount++;
                                break;
                            }
                        case GraphInputType.quarters:
                            {   ///     0        1   2      3          4    5   6    7    8   9    10  11
                                /// ie. warto��: 30; punkty graniczne: (-1; 3), (-1; -3), (2; -3), (2; 3)
                                flow = float.Parse(parts[1][..^1]); // get the fields' yield in the quarter (re-using variable flow, CultureInfo.InvariantCulture)
                                // get border points of the quarter
                                for (int p = 4; p < parts.Length - 1; p += 2)
                                {
                                    //Debug.Log($"parts[p][1..^1]: {parts[p][1..^1]}, parts[p + 1][..^2]: {parts[p + 1][..^2]}");
                                    GraphManager.instance.CreateNode(new Vector2(float.Parse(parts[p][1..^1], CultureInfo.InvariantCulture), float.Parse(parts[p + 1][..^2], CultureInfo.InvariantCulture)), GraphNode.NodeType.cwiartka, flow);
                                }
                                GraphManager.instance.InitializeQuarterArea();
                                break;
                            }
                        case GraphInputType.solution:
                            {
                                switch (parts.Length)
                                {
                                    case 3:
                                        {
                                            // Trasa nr x:
                                            solutionData.AppendLine(line);
                                            augumentingPathsBegins.Add(simulationSteps);
                                            arrowsOrder.Add(null);
                                            flowsOrder.Add(0);
                                            simulationSteps++;
                                            break;
                                        }
                                    case 9:
                                        {
                                            //     0        1     2   3  4       5   6   7      8
                                            // ie. zawarto�� pola [2] na pozycji (0, -2) wynosi 0;
                                            int nodeId = int.Parse(parts[2][1..^1]);
                                            if (GraphManager.instance.TryGetNodeByID(nodeId, out GraphNode updatedNode))
                                            {
                                                float newCapacity = float.Parse(parts[8][..^1], CultureInfo.InvariantCulture);

                                                if (nodeUpdates.ContainsKey(simulationSteps - 1))
                                                {
                                                    // add old capacity to previous step in case of going back

                                                    // add element with node's ID and its capacity difference to the current step's list
                                                    nodeUpdates[simulationSteps - 1].Add(new(nodeId, newCapacity));
                                                    //Debug.Log($"nodeUpdates[{simulationSteps - 1}] = ({nodeUpdates[simulationSteps - 1][^1].Key}, {nodeUpdates[simulationSteps - 1][^1].Value})");
                                                }
                                                else
                                                {
                                                    List<KeyValuePair<int, float>> newElement = new()
                                                {
                                                    new(nodeId, newCapacity)
                                                };
                                                    nodeUpdates[simulationSteps - 1] = newElement; // add a new list with node's ID and its capacity difference to the current step
                                                    //Debug.Log($"nodeUpdates[{simulationSteps - 1}] = ({newElement[0].Key}, {newElement[0].Value})");
                                                }

                                            }
                                            else
                                            {
                                                Debug.LogWarning("Didn't find node by ID " + nodeId);
                                            }

                                            //simulationSteps++;
                                            break;
                                        }
                                    case 17:
                                        {
                                            //     0 1    2   3  4       5   6  7 8   9          10 11      12  13 14      15  16
                                            // ie. Z pola [1] na pozycji (0, 2) 4 ton j�czmienia do browaru [4] na pozycji (4, -2);
                                            solutionData.AppendLine(line);
                                            fromID = int.Parse(parts[2][1..^1]);
                                            if (GraphManager.instance.TryGetNodeByID(fromID, out GraphNode fromNode))
                                            {
                                                flow = float.Parse(parts[7], CultureInfo.InvariantCulture);
                                                toID = int.Parse(parts[12][1..^1], CultureInfo.InvariantCulture);
                                                if (GraphManager.instance.TryGetNodeByID(toID, out GraphNode toNode))
                                                {
                                                    solutionArrow = GraphManager.instance.FindArrowByNodes(fromNode, toNode);
                                                    if (solutionArrow == null)
                                                    {
                                                        Debug.LogWarning($"Failed to find an arrow that the solution found, the path must be going through a negative cost\nfrom: {fromNode.nodeID}; to: {toNode.nodeID}");
                                                        // failed to find an arrow that the solution found, the path must be going through a negative cost, so look for the arrow in the opposite direction
                                                        // find the arrow toNode -> fromNode
                                                        solutionArrow = GraphManager.instance.FindArrowByNodes(toNode, fromNode);
                                                        if (solutionArrow == null)
                                                        {
                                                            Debug.LogError($"Failed to find an arrow while parsing solution, even in the opposite direction, there must be an issue with the solution algorithm\nfrom: {fromNode.nodeID}; to: {toNode.nodeID}");
                                                        }
                                                        // add flow to that arrow
                                                        flow *= -1;
                                                    }
                                                    arrowsOrder.Add(solutionArrow);
                                                    flowsOrder.Add((decimal)flow);
                                                }
                                            }
                                            else
                                            {
                                                Debug.LogWarning("Failed to find node with fromID " + fromID);
                                            }
                                            solutionArrow = null;
                                            simulationSteps++;
                                            break;
                                        }
                                    default: break;
                                }
                                break;
                            }
                        default: break;
                    }
                }
                // add an empty step at the end
                augumentingPathsBegins.Add(simulationSteps);
                arrowsOrder.Add(null);
                flowsOrder.Add(0);
                simulationSteps++;
                for (int i = 0; i < arrowsOrder.Count; i++)
                {
                    if (arrowsOrder[i] != null && !arrowsVisited.ContainsKey(arrowsOrder[i])) // if arrow has been visited for the first time
                    {
                        arrowsVisited.Add(arrowsOrder[i], i); // rememeber what step it was visited in (to only include its repair cost once)
                    }
                }

                // arrows' flows cleanup (for cycles)

                if (flowsOrder.Count != arrowsOrder.Count)
                {
                    Debug.LogError("flowsOrder and arrowsOrder must be the same length.");
                    return;
                }

                List<int> nullIndices = new();

                // find all null indices
                for (int i = 0; i < arrowsOrder.Count; i++)
                {
                    if (arrowsOrder[i] == null)
                    {
                        nullIndices.Add(i);
                    }
                }

                // loop through ranges between neighboring nulls
                for (int i = 0; i < nullIndices.Count - 1; i++)
                {
                    int start = nullIndices[i] + 1;
                    int end = nullIndices[i + 1] - 1;

                    Dictionary<GraphArrow, int> firstOccurrences = new();

                    for (int j = end; j >= start; j--)
                    {
                        var arrow = arrowsOrder[j];
                        if (arrow == null) continue;

                        if (firstOccurrences.TryGetValue(arrow, out int firstIndex))
                        {
                            // duplicate found - set last to max, the earlier ones to 0
                            decimal lastValue = flowsOrder[firstIndex];
                            decimal previousValue = flowsOrder[j];

                            if (previousValue > lastValue)
                            {
                                flowsOrder[firstIndex] = previousValue;
                                flowsOrder[j] = 0;
                            }
                            else
                            {
                                flowsOrder[j] = 0;
                            }
                        }
                        else
                        {
                            firstOccurrences[arrow] = j;
                        }
                    }
                }

                Debug.Log("Flows cleanup completed.");
            }
            stepsSlider.maxValue = simulationSteps - 1;
            solutionLines = solutionData.ToString().Split('\n');
        }
        catch (Exception e)
        {
            GraphManager.instance.SetGridSize(savedGridSize);
            FileGraphConverter.inputCorrect = false;
            GraphNode.generatingGraph = false;
            loadingScreenPanel.SetActive(false); // hide loading screen
            Debug.LogError(e.ToString());
            if (e is not OperationCanceledException) // unless the operation was cancelled by user
            {
                FileOperationInfoText.instance.ShowFileParseError(currentLine, line, e.Message);
                fileTab.onClick.Invoke(); // open the file tab
            }
            return;
        }
        
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.verifyingNodes);
        GraphNode.generatingGraph = false;
        GraphManager.instance.SetGridSize(savedGridSize);
        await Task.Yield();
        await GraphManager.instance.CheckAllNodesCorrectPosition(token);

        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.synchronizing);
        await Task.Yield();
        // graph successfully generated and simulation steps are ready

        if (!FileGraphConverter.inputCorrect) // if last attempt was incorrect
        {
            FileGraphConverter.inputCorrect = true;
        }

        string testFlows = "";
        foreach (decimal flow in flowsOrder)
        {
            testFlows+= flow.ToString() + "\n";
        }
        Debug.Log("flowsOrder:\n" + testFlows);
        simulationGenerated = true;
        // the text was resetted before generation, reapply the text in the input field
        string simulationText = File.ReadAllText(simulationFilePath);
        if (simulationText.Length <= 80000)
        {
            outputDataInputField.SetTextWithoutNotify(File.ReadAllText(simulationFilePath));
        }
        
        FileGraphConverter.instance.UpdateNotNeeded();
        //FileOperationInfoText.instance.ClearInfoText();
        //GraphToTextConverter.instance.ConvertGraphToText();
        GraphManager.instance.DeselectAllElements();
        GraphInputManager.instance.SetQuarterEditMode(false);
        loadingScreenPanel.SetActive(false); // hide loading screen
        switchToOutputLayoutButton.onClick.Invoke(); // deactivate input-related buttons in File tab (activates the output-related ones)

        /*float costSum = 0f;
        foreach (GraphArrow arrow in GraphManager.instance.GetArrows())
        {
            Debug.Log($"{costSum} + {arrow.GetRepairCost()} = {costSum += arrow.GetRepairCost()}");
            costSum += arrow.GetRepairCost();
            
        }*/
    }
    public async void AutoPlaySimulation()
    {
        //Debug.Log("AutoPlaySimulation");
        StopAutoplay();
        if (!simulationGenerated) { return; }
        CancellationToken token = autoplayTokenSource.Token;

        if (stepsSlider.value == stepsSlider.maxValue)
        {
            stepsSlider.value = 0;
        }

        while (stepsSlider.value < stepsSlider.maxValue)
        {
            ShowNextSimulationStep(true);
            try { await Awaitable.WaitForSecondsAsync(autoplaySpeed, token); } catch { Debug.Log("Autoplay cancelled"); return; }
        }
        StopAutoplay();
    }
    public void ShowSimulationStep(float sliderValue) // used by slider
    {
        //Debug.Log("ShowSimulationStep");
        if (arrowsOrder.Count < 1) return;

        if ((int)sliderValue < currentStep)
        {   // skipping back
            while ((int)sliderValue != currentStep) { ShowPreviousSimulationStep(false); }
        }
        else if ((int)sliderValue > currentStep)
        {   // skipping forward
            while ((int)sliderValue != currentStep) { ShowNextSimulationStep(false); }
        }
    }
    public void ShowPreviousSimulationStep(bool changeSliderValue)
    {
        if (simulationGenerated && currentStep > 0) // if value in range
        {
            if (arrowsOrder[currentStep] != null) // if an arrow was affected in next step
            {
                arrowsOrder[currentStep].SetArrowSelectedSprite(false); // unhighlight the arrow from the old step
                arrowsOrder[currentStep].SetArrowTexts(arrowsOrder[currentStep].GetFlowFromText() + flowsOrder[currentStep], arrowsOrder[currentStep].GetRepairCostFromText()); // add flow to the old arrow
                // subtract flow from the old arrow in the opposite direction (if exists)
                GraphArrow oppositeArrow = GraphManager.instance.FindArrowByNodes(arrowsOrder[currentStep].GetToNode(), arrowsOrder[currentStep].GetFromNode());
                if (oppositeArrow != null)
                { oppositeArrow.SetArrowTexts(oppositeArrow.GetFlowFromText() - flowsOrder[currentStep], oppositeArrow.GetRepairCostFromText()); }
                if (arrowsOrder[currentStep].GetToNode().GetNodeType() == GraphNode.NodeType.karczma)
                {
                    beerSoFar -= flowsOrder[currentStep];
                    beerSoFarText.SetText(beerSoFar.ToString());
                }
                if (arrowsVisited[arrowsOrder[currentStep]] == currentStep) // if it's the arrow's first occurrence in the simulation
                {
                    arrowsOrder[currentStep].SetArrowTexts(arrowsOrder[currentStep].GetFlowFromText(), originalCosts[arrowsOrder[currentStep]]); // first revert the cost
                    costSoFar -= arrowsOrder[currentStep].GetRepairCostFromText(); // subtract arrow's original cost from the total
                    costSoFarText.SetText(costSoFar.ToString());
                }
            }
            else // if next step was a new route (route's arrows had been selected)
            {
                /// unhighlight all arrows in new route
                for (int i = currentStep + 1; i < arrowsOrder.Count; i++)
                {
                    if (arrowsOrder[i] == null)
                    {
                        Debug.Log("arrowsOrder[" + i + "] is null");
                        break;
                    }
                    Debug.Log("deselecting arrowsOrder[" + i + "]");
                    arrowsOrder[i].SetArrowSelectedSprite(false);
                }
            }

            currentSolutionLineText.SetText(solutionLines[currentStep - 1]);
            if (arrowsOrder[currentStep - 1] != null) // if an arrow is affected in previous step
            {
                arrowsOrder[currentStep - 1].SetArrowSelectedSprite(true); // highlight the arrow in new step
            }
            else // if previous step is a new route
            {
                /// highlight (DON'T SELECT, otherwise arrow info panel shows up) all arrows in new route
                //if (currentStep + 1 < arrowsOrder.Count)
                //{
                for (int i = currentStep; i < arrowsOrder.Count; i++)
                {
                    if (arrowsOrder[i] == null)
                    {
                        break;
                    }
                    arrowsOrder[i].SetArrowSelectedSprite(true);
                }
                //}
            }
            // if there are nodes to update in the dictionary
            if (nodeUpdates.ContainsKey(currentStep))
            {
                // update each (of max 2) nodes' capacities to update in the next step
                for (int i = 0; i < nodeUpdates[currentStep].Count; i++)
                {
                    // find the node to update
                    GraphManager.instance.TryGetNodeByID(nodeUpdates[currentStep][i].Key, out GraphNode node);
                    // prepare a swap value for the dictionary
                    float oldCapacity = node.GetCapacity();
                    node.SetCapacity(nodeUpdates[currentStep][i].Value);
                    // swap the value in the dictionary
                    nodeUpdates[currentStep][i] = new(nodeUpdates[currentStep][i].Key, oldCapacity);
                }
            }
            currentStep--;
            if (currentStep == 0)
            {
                /// unhighlight all arrows in the route that starts in the next step (to reset)
                for (int i = currentStep + 2; i < arrowsOrder.Count; i++)
                {
                    if (arrowsOrder[i] == null)
                    {
                        break;
                    }
                    arrowsOrder[i].SetArrowSelectedSprite(false);
                }
            }
            if (changeSliderValue) { stepsSlider.value--; }
        }
    }
    public void ShowNextSimulationStep(bool changeSliderValue)
    {
        if (simulationGenerated && currentStep < stepsSlider.maxValue)
        {
            if (arrowsOrder[currentStep] != null)
            {
                arrowsOrder[currentStep].SetArrowSelectedSprite(false);
            }
            else // if previous step was a new route (multiple arrows were highlighted)
            {
                /// unhighlight all arrows in new route
                if (currentStep + 2 < arrowsOrder.Count)
                {
                    for (int i = currentStep + 1; i < arrowsOrder.Count; i++)
                    {
                        if (arrowsOrder[i] == null)
                        {
                            break;
                        }
                        arrowsOrder[i].SetArrowSelectedSprite(false);
                    }
                }
            }

                currentSolutionLineText.SetText(solutionLines[currentStep + 1]);
            if (arrowsOrder[currentStep + 1] != null)
            {
                arrowsOrder[currentStep + 1].SetArrowSelectedSprite(true);
                arrowsOrder[currentStep + 1].SetArrowTexts(arrowsOrder[currentStep + 1].GetFlowFromText() - flowsOrder[currentStep + 1], arrowsOrder[currentStep + 1].GetRepairCostFromText()); // subtract flow from the old arrow
                // add flow to the old arrow in the opposite direction (if exists)
                GraphArrow oppositeArrow = GraphManager.instance.FindArrowByNodes(arrowsOrder[currentStep + 1].GetToNode(), arrowsOrder[currentStep + 1].GetFromNode());
                if (oppositeArrow != null)
                { oppositeArrow.SetArrowTexts(oppositeArrow.GetFlowFromText() + flowsOrder[currentStep + 1], oppositeArrow.GetRepairCostFromText()); }

                //arrowsOrder[currentStep + 1].GetFromNode().SetCapacity(arrowsOrder[currentStep + 1].GetFromNode().GetCapacity() - flowsOrder[currentStep + 1]); // subtract capacity from fromNode
                if (arrowsOrder[currentStep + 1].GetToNode().GetNodeType() == GraphNode.NodeType.karczma) // if pub is reached
                {   // update texts

                    Debug.Log($"costSoFar: {beerSoFar} | flowsOrder[{currentStep + 1}]: {flowsOrder[currentStep + 1]} = {beerSoFar + flowsOrder[currentStep + 1]}");
                    beerSoFar += flowsOrder[currentStep + 1];
                    beerSoFarText.SetText(beerSoFar.ToString());
                }
                if (arrowsVisited[arrowsOrder[currentStep + 1]] == currentStep + 1) // if it's the arrow's first occurrence in the simulation
                {
                    Debug.Log($"costSoFar: {costSoFar} | arrowsOrder[{currentStep + 1}].GetRepairCost: {arrowsOrder[currentStep + 1].GetRepairCostFromText()} = {costSoFar + (decimal)arrowsOrder[currentStep + 1].GetRepairCostFromText()}");
                    costSoFar += arrowsOrder[currentStep + 1].GetRepairCostFromText(); // add its cost to the total
                    arrowsOrder[currentStep + 1].SetArrowTexts(arrowsOrder[currentStep + 1].GetFlowFromText(), 0); // set repair cost to 0 (to update the texts)
                    costSoFarText.SetText(costSoFar.ToString());
                }
            }
            else // if the next step is a new route
            {
                /// highlight (DON'T SELECT, otherwise arrow info panel shows up) all arrows in new route
                if (currentStep + 3 < arrowsOrder.Count)
                {
                    for (int i = currentStep + 2; i < arrowsOrder.Count; i++)
                    {
                        if (arrowsOrder[i] == null)
                        {
                            break;
                        }
                        arrowsOrder[i].SetArrowSelectedSprite(true);
                    }
                }
                
            }
            // if there are nodes to update in the dictionary
            if (nodeUpdates.ContainsKey(currentStep + 1))
            {
                // update each (of max 2) nodes' capacities to update in the next step
                for (int i = 0; i < nodeUpdates[currentStep + 1].Count; i++)
                {
                    // find the node to update
                    GraphManager.instance.TryGetNodeByID(nodeUpdates[currentStep + 1][i].Key, out GraphNode node);
                    // prepare a swap value for the dictionary
                    float oldCapacity = node.GetCapacity();
                    node.SetCapacity(nodeUpdates[currentStep + 1][i].Value);
                    // swap the value in the dictionary
                    nodeUpdates[currentStep + 1][i] = new(nodeUpdates[currentStep + 1][i].Key, oldCapacity);
                }
            }
            currentStep++;
            if (changeSliderValue) { stepsSlider.value++; }
        }


    }
    public void StopAutoplay()
    {
        if (autoplayTokenSource != null)
        {
            autoplayTokenSource.Cancel();
            autoplayTokenSource.Dispose();
        }
        autoplayTokenSource = new();
        playButton.SetActive(true);
    }

    public void ResetSimulation()
    {
        if (simulationGenerated && !GraphNode.generatingGraph) // only reset if not currently generating graph (otherwise the simulationFilePath gets cleared)
        {
            // reset global variables for future re-using of the method and prevent using simulation controls when there's no simulation generated
            Debug.Log("ResetSimulation\n" + outputDataInputField.text);
            stepsSlider.value = 0f;
            stepsSlider.maxValue = 1f;
            arrowsOrder.Clear();
            flowsOrder.Clear();
            beerSoFar = 0; costSoFar = 0; currentStep = 0;
            simulationGenerated = false;
            nodeUpdates.Clear();
            switchToInputLayoutButton.onClick.Invoke(); // activate input-related buttons in File tab (deactivates the output-related ones)

            outputDataInputField.SetTextWithoutNotify(string.Empty); // clear the output data text
            FileToTMPInput.simulationFilePath = ""; // remove the output file path reference, so that pattern search no longer works
        }
    }

    public int GetSolutionRoutesCount()
    {
        int count = 0;
        foreach (GraphArrow step in arrowsOrder)
        {
            if(step == null) count++;
        }
        return Mathf.Max(0, count-2);
    }
    public int GetSolutionStepsCount()
    {
        return (int)stepsSlider.maxValue - 1;
    }
}