using UnityEngine;
using UnityEngine.EventSystems;

public class ShowTooltipOnHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] string tooltip;
    public void OnPointerEnter(PointerEventData eventData)
    {
        TooltipObjectSetter.instance.gameObject.SetActive(true);
        TooltipObjectSetter.instance.SetTooltipText(tooltip);
        TooltipObjectSetter.instance.UpdatePosition(transform);
    }
    public void OnPointerExit(PointerEventData eventData)
    {
        TooltipObjectSetter.instance.gameObject.SetActive(false);
    }
    public void ChangeTooltip(string newTooltip) // used by localization to translate tooltips
    {
        tooltip = newTooltip;
    }
}
