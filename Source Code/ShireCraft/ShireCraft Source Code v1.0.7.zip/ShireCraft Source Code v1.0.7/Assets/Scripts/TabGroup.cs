using UnityEngine;
using System.Collections.Generic;
//using UnityEngine.UI;

public class TabGroup : MonoBehaviour
{
    [SerializeField] List<Tab> tabButtons = new();
    [SerializeField] Color tabDefault;
    [SerializeField] Color tabHover;
    [SerializeField] Color tabActive;
    public Tab selectedTab;
    public List<GameObject> objectsToSwap = new();
    //int previouslyOpenTab = 1;

    /*    public void Subscribe(Tab button)
        {
            tabButtons.Add(button);
        }*/

    //int previouslyOpenTab = 1;

    /*    public void Subscribe(Tab button)
        {
            tabButtons.Add(button);
        }*/

#if UNITY_EDITOR
    [ExecuteInEditMode]
    private void OnValidate()
    {
        SetTabs();
    }
#endif
    public void OnTabEnter(Tab button)
    {
        if (selectedTab == null || button != selectedTab)
        {
            button.background.color = tabHover;
        }
    }
    public void OnTabExit(Tab button)
    {
        if (selectedTab != null && button != selectedTab) { button.background.color = tabDefault; }
    }

    public void OnTabSelected(Tab button)
    {
        // do nothing if the tab was already selected
        if (selectedTab == button) { return; }
        // find currently active panel and set it inactive
        foreach (var panel in objectsToSwap) 
        {
            if(panel.activeSelf) panel.SetActive(false);
        }
        selectedTab = button;
        SetTabs();
        button.background.color = tabActive;
        // enable the selected tab's panel (indexes of both lists must align)
        objectsToSwap[tabButtons.IndexOf(button)].SetActive(true);
    }

    public void SetTabs()
    {
        foreach (Tab button in tabButtons)
        {
            button.background.color = tabDefault;
        }
        if (selectedTab != null) { selectedTab.background.color = tabActive; }
    }
}
