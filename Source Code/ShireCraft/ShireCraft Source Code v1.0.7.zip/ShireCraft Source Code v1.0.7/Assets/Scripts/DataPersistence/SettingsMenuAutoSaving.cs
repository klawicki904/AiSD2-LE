using UnityEngine;

public class SettingsMenuAutoSaving : MonoBehaviour
{
    private void OnApplicationQuit()
    {
        SettingsPersistenceManager.instance.SaveSettings();
    }
}
