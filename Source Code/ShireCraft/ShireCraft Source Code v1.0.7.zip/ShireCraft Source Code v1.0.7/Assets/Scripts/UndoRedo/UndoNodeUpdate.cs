using UnityEngine;
/// <summary>
/// Undo-Redo definition for updating node's values via the (Element) Node Info Panel
/// </summary>
public class UndoNodeUpdate : IUndoableAction
{
    readonly int nodeID;
    Vector2 position;
    GraphNode.NodeType nodeType;
    float capacity;

    public UndoNodeUpdate(GraphNode node)
    {
        nodeID = node.nodeID;
        // constructor is called before the type is updated, so this saves the data the undo needs to revert to
        position = node.transform.position;
        nodeType = node.GetNodeType();
        capacity = node.GetCapacity();
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        if (GraphManager.instance.TryGetNodeByID(nodeID, out var undoNode))
        {
            // remember new position for swapping
            Vector2 newPosition = undoNode.transform.position;
            // remember new type for swapping
            GraphNode.NodeType newType = undoNode.GetNodeType();
            // remember new capacity for swapping
            float newCapacity = undoNode.GetCapacity();

            // select node (needed for updateCapacity to work)
            GraphManager.instance.SelectNode(undoNode, true);
            // update node with saved data
            undoNode.UpdateNode(position, nodeType, capacity);
            GraphManager.instance.UpdateCapacity(true, capacity); // advanced capacity update, taking quarter areas into consideration
            GraphManager.instance.SelectNode(null);
            // save new position for potential Redo
            position = newPosition;
            // save new type for potential Redo
            nodeType = newType;
            // save new capacity for potential Redo
            capacity = newCapacity;
        }

    }
    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        Undo();
    }
}
