using System.Collections.Generic;
using UnityEngine;
using System.Text;
using System.Threading.Tasks;
using System.Linq;
using TMPro;

public class GraphToTextConverter : MonoBehaviour
{
    [SerializeField] GraphManager graphManager;
    [SerializeField] TMP_InputField conversionRateInputField;
    public static GraphToTextConverter instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }

    /// <summary>
    /// Converts the graph into a formatted string asynchronously.
    /// </summary>
    public async void ConvertGraphToText(bool launchPathAnalyzer = false)
    {
        Debug.Log($"ConvertGraphToText: inputCorrect: {FileGraphConverter.instance.GetInputCorrect()} | UpdateNeeded: {FileGraphConverter.instance.GetUpdateNeeded()} | simulationGenerated: {OutputFileToSimulationData.simulationGenerated}");
        if (!FileGraphConverter.instance.GetInputCorrect() || (!launchPathAnalyzer && !FileGraphConverter.instance.GetUpdateNeeded()) ||
            OutputFileToSimulationData.simulationGenerated) return;

        // cache data on main thread
        var nodes = new List<GraphNode>(graphManager.GetNodes());
        var arrows = new List<GraphArrow>(graphManager.GetArrows());
        var quarters = new List<QuarterArea>(graphManager.GetQuarters());

        // sort nodes by position (X, then Y)
        nodes.Sort((a, b) =>
        {
            int x = a.transform.position.x.CompareTo(b.transform.position.x);
            return x != 0 ? x : a.transform.position.y.CompareTo(b.transform.position.y);
        });

        // build node dictionary and extract required info for async use
        Dictionary<GraphNode, int> nodesDictionary = new();
        List<(int index, float x, float y, GraphNode.NodeType type, float capacity)> nodeInfos = new();
        for (int i = 0; i < nodes.Count; i++)
        {
            var node = nodes[i];
            nodesDictionary[node] = i;
            nodeInfos.Add((i, node.GetX(), node.GetY(), node.GetNodeType(), node.GetCapacity()));
        }

        // extract arrow info for sorting and background use
        var arrowInfos = arrows.Select(a => (
            from: nodesDictionary[a.GetFromNode()],
            to: nodesDictionary[a.GetToNode()],
            flow: a.GetFlow(),
            cost: a.GetRepairCost()
        )).ToList();

        // sort arrows by `from`, then `to`
        arrowInfos.Sort((a, b) =>
        {
            int comp = a.from.CompareTo(b.from);
            return comp != 0 ? comp : a.to.CompareTo(b.to);
        });

        List<float> quartersYields = new();
        List<List<(float x, float y)>> quarterInfos = new();
        for (int i=0; i<quarters.Count; i++)
        {
            //if (quarters[i].quarterNodes.Count == 0) continue;
            //Debug.Log("quarters count: " + quarters.Count);
            quarterInfos.Add(new());
            quartersYields.Add(quarters[i].quarterNodes[0].GetCapacity());
            for (int j = 0; j < quarters[i].quarterNodes.Count; j++)
            {
                //Debug.Log($"quarters[{i}].quarterNodes.Count: {quarters[i].quarterNodes.Count}; j: {j}");
                /*Debug.Log(quarters[i].quarterNodes[j].GetX());
                Debug.Log(quarters[i].quarterNodes[j].GetY());*/
                quarterInfos[i].Add((quarters[i].quarterNodes[j].GetX(), quarters[i].quarterNodes[j].GetY()));
            }
        }

        // perform string conversion in background
        var result = await Task.Run(() =>
        {
            StringBuilder detailed = new();
            StringBuilder arrowsText = new();
            detailed.Append("KONWERSJA\n");
            detailed.Append($"{conversionRateInputField.text.Replace(',', '.')}\n");

            detailed.Append("PUNKTY\n");
            foreach (var (index, x, y, type, capacity) in nodeInfos)
            {
                detailed.Append($"{index+1} {x} {y} {type}");
                
                if (type == GraphNode.NodeType.browar)
                    detailed.Append($" {capacity}");
                detailed.Append('\n');
            }

            detailed.Append("DROGI\n");
            foreach (var (from, to, flow, cost) in arrowInfos)
            {
                arrowsText.Append($"{from+1} {to+1} {flow}\n");
                detailed.Append($"{from+1} {to+1} {flow} {cost}\n");
            }

            detailed.Append("CWIARTKI\n");
            for (int i=0; i<quarterInfos.Count; i++)
            {
                // print yield of all fields in the quarter
                detailed.Append(quartersYields[i]);
                foreach (var quarterNode in quarterInfos[i])
                {
                    detailed.Append($" {quarterNode.x} {quarterNode.y}");
                }
                detailed.Append('\n');
            }

            arrowsText.Insert(0, $"{nodeInfos.Count} {arrowInfos.Count}\n");

            return (detailed.ToString(), arrowsText.ToString());
        });

        // apply results back on the main thread
        FileToTMPInput.instance.AutosaveAndInputFields(ref result.Item1, ref result.Item2);
        FileGraphConverter.instance.UpdateNotNeeded();

        if (launchPathAnalyzer) { LaunchExternalExecutable.instance.ExecutePathAnalyzer(); }
    }
    private void OnApplicationQuit() // for autosave
    {
        ConvertGraphToText();
    }
}
