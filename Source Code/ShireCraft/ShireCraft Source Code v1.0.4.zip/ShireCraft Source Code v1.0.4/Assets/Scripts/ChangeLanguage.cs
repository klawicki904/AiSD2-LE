using System;
using UnityEngine;
using UnityEngine.Localization.Settings;

public class ChangeLanguage : MonoBehaviour
{
    public void SelectLanguage(Int32 value)
    {
        var availableLocales = LocalizationSettings.AvailableLocales;

        if (availableLocales.Locales.Count == 0)
        {
            Debug.LogWarning("No Locales included in the active Localization Settings.");
        }
        else
        {
            LocalizationSettings.SelectedLocale = availableLocales.Locales[value];
        }
    }
}
