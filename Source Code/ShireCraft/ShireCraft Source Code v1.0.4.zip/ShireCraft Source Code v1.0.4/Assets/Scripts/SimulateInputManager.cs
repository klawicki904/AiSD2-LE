using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.EventSystems;

public class SimulateInputManager : MonoBehaviour
{
    [SerializeField] GraphManager graphManager;

    [SerializeField] SpriteRenderer selectionArea;
    
    public static SimulateInputManager instance { get; private set; }

    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
    }
    public void OnLeftClick(InputAction.CallbackContext ctx) // called on left click down and up
    {
#if UNITY_ANDROID
        if (leftClickDown && ctx.control.IsPressed()) { return; }
#endif

        GraphInputManager.instance.leftClickDown = ctx.control.IsPressed(); // check for button state

        GraphInputManager.instance.rayHits = Physics2D.GetRayIntersectionAll(Camera.main.ScreenPointToRay(Pointer.current.position.ReadValue()), 11f);
        if (GraphInputManager.instance.leftClickDown) // if LMB down and not holding ctrl
        {
            if (GraphInputManager.instance.HasClickedOverUI()) { return; }
            //if (EventSystem.current.currentSelectedGameObject != null) return;

            if (GraphInputManager.instance.rayHits.Length > 0) // if clicked some object
            {
                if (GraphInputManager.instance.TryGetFirstNodeFromRayHits(out GraphNode node)) // if clicked a node
                {
                    if (!graphManager.IsNodeSelected(node)) // if clicking unselected node without ctrl and not selecting something in UI
                    { graphManager.SelectNode(node, GraphInputManager.instance.ctrlDown); } // select the single node (for dragging)
                }
            }
            else // clicked empty space
            {
                GraphInputManager.instance.origin = GetMousePosition;
                if (GraphInputManager.instance.inputState == GraphInputManager.InputState.none) GraphInputManager.instance.inputState = GraphInputManager.InputState.selectingAreaStart;
            }
        }
        else // click up
        {
            if (GraphInputManager.instance.dragging) // dragged on click down
            {
                if (GraphInputManager.instance.inputState == GraphInputManager.InputState.selectingArea)
                {
                    GraphInputManager.instance.inputState = GraphInputManager.InputState.none;
                    if (!GraphInputManager.instance.ctrlDown)
                    {
                        graphManager.DeselectAllElements();
                    }

                    Debug.Log($"origin: {GraphInputManager.instance.origin}; difference: {GraphInputManager.instance.difference}; origin + difference: {GraphInputManager.instance.origin + GraphInputManager.instance.difference}");
                    // select all nodes in the selection area:
                    // find all colliders in the selection area
                    Collider2D[] selectedColliders = Physics2D.OverlapAreaAll(GraphInputManager.instance.origin, GraphInputManager.instance.origin + GraphInputManager.instance.difference, GraphInputManager.instance.GetNodesLayer());
                    foreach (var col in selectedColliders)
                    {
                        Debug.Log("Selected: " + col.name);
                        graphManager.SelectNode(col.GetComponent<GraphNode>(), true);
                    }
                    selectionArea.enabled = false;
                }
                GraphInputManager.instance.dragging = false;


            }
            else // if didn't drag
            {
                if (!GraphInputManager.instance.HasClickedOverUI())
                {
                    if (GraphInputManager.instance.rayHits.Length > 0) // if clicked something and something is a node
                    {
                        /*if (rayHit.collider.TryGetComponent(out GraphNode node))
                        {
                            graphManager.SelectNode(node, GraphInputManager.instance.ctrlDown); // select node
                        }
                        else */
                        if (GraphInputManager.instance.TryGetArrowIfFirst(out GraphArrow arrow)) // if clicked an arrow and not selecting something in UI
                        {
                            graphManager.SelectArrow(arrow);
                        }
                    }
                    else // if clicked empty space
                    {
                        graphManager.CancelArrow(); // cancel arrow
                        graphManager.DeselectAllElements(); // deselect all nodes (and hide info panel)
                    }
                }
            }
        }
        //#endif
    }

    
    Vector3 GetMousePosition => Camera.main.ScreenToWorldPoint(Pointer.current.position.ReadValue());
}
