using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using UnityEngine.SceneManagement;
using System.IO;

public class SettingsPersistenceManager : MonoBehaviour
{
    [Header("File Storage Config")]
    [SerializeField] private string fileName;
    [SerializeField] public static string savesFolder = Path.Combine(Application.dataPath, "Saves");

    private SettingsData settingsData;
    private List<ISettingsPersistence> settingsPersistenceObjects;
    private SettingsDataHandler settingsHandler;

    public static SettingsPersistenceManager instance { get; private set; }
    private void Awake()
    {
        if (instance != null)
        {
            Debug.LogWarning("Found more than one Settings Persistence Manager in the scene. Destroying the newest one.");
            Destroy(gameObject);
            return;
        }
        instance = this;
        // create the Saves directory if it doesn't already exist
        Directory.CreateDirectory(Path.GetDirectoryName(Path.Combine(savesFolder, fileName)));
#if UNITY_ANDROID && !UNITY_EDITOR
        settingsHandler = new SettingsDataHandler(Application.persistentDataPath + "/Saves/", fileName);
#else
        settingsHandler = new SettingsDataHandler(savesFolder, fileName);
#endif
    }

    public void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        settingsPersistenceObjects = FindAllSettingsPersistenceObjects();
        LoadSettings();
    }
    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }
    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    public void NewSettings()
    {
        settingsData = new SettingsData();
    }

    public void LoadSettings()
    {
        // load any saved data from a file using the data handler
        settingsData = settingsHandler.Load();

        // if no data can be loaded, initialize to a new game
        if (settingsData == null)
        {
            Debug.Log("No settings was found. Initializing data to defaults.");
            NewSettings();
        }
        
        // push the loaded data to all other scripts that need it
        foreach (ISettingsPersistence settingsPersistenceObj in settingsPersistenceObjects)
        {
            settingsPersistenceObj.LoadSettings(settingsData);
        }
    }

    public void SaveSettings()
    {
        // pass the data to other scripts so they can update it
        foreach (ISettingsPersistence settingsPersistenceObj in settingsPersistenceObjects)
        {
            settingsPersistenceObj.SaveSettings(settingsData);
        }

        // save that data to a file using the data handler
        settingsHandler.Save(settingsData);
    }

    private List<ISettingsPersistence> FindAllSettingsPersistenceObjects()
    {
        IEnumerable<ISettingsPersistence> settingsPersistenceObjects = FindObjectsByType<MonoBehaviour>(FindObjectsInactive.Include, FindObjectsSortMode.None)
            .OfType<ISettingsPersistence>();

        return new List<ISettingsPersistence>(settingsPersistenceObjects);
    }
}