using UnityEngine;

[System.Serializable]
public class SettingsData
{
    //public bool AutoFlow = false;
    public bool SnapToGrid = true;
    public bool ShowGrid = true;
    public float GridSize = 1f;
    public bool DragThreshold = true;
    public int DragThresholdValue = 1;
    public int ElementsSize = 10;
    public float HorizontalSpacing = 4f;
    public float VerticalSpacing = 2f;
    public int MaxZoom = 10;
    public int LanguageDropdownOption = 0;
    public int generationBatching = 10;

    public float ArrowsFromFieldsHue = 0.1628571f;
    public float ArrowsFromBreweriesHue = 0.09215686f;
    public float ArrowsFromPubsHue = 0.08883537f;
    public float ArrowsFromNoneHue = 0.5f;
    public float PatternMatchHue = 0f;

    /// only changeable by modifying the settings file
    public float LoadingScreenRefreshDelay = 0.3f;
    public bool LoadGraphOnLaunch = false;

    public SettingsData()
    {
        //AutoFlow = false;
        SnapToGrid = true;
        ShowGrid = true;
        GridSize = 1f;
        DragThreshold = true;
        DragThresholdValue = 1;
        ElementsSize = 10;
        HorizontalSpacing = 4f;
        VerticalSpacing = 2f;
        MaxZoom = 10;
        LanguageDropdownOption = 0;
        generationBatching = 10;

        ArrowsFromFieldsHue = 0.1628571f;
        ArrowsFromBreweriesHue = 0.09215686f;
        ArrowsFromPubsHue = 0.08883537f;
        ArrowsFromNoneHue = 0.5f;
        PatternMatchHue = 0f;


        LoadingScreenRefreshDelay = 0.3f;
        LoadGraphOnLaunch = false;
    }
}
