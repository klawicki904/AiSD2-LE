using UnityEngine;
using UnityEngine.InputSystem;
using System.Threading;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class GraphInputManager : MonoBehaviour
{
    [SerializeField] GraphManager graphManager;
    [SerializeField] TMPro.TextMeshProUGUI gridSizePopupText;
    [SerializeField] TMPro.TMP_InputField maxCameraZoomInputField;
    public Vector3 origin;
    public Vector3 difference;
    Vector3 cameraOffset = new(0f, 0f, -10f);
    [SerializeField] private GraphicRaycaster graphicRaycaster;
    private PointerEventData clickData;
    private List<RaycastResult> UI_RaycastResults;
    public RaycastHit2D[] rayHits;

    public static Vector2 pasteOffset { get; private set; } = new(1f, -1f);

    uint maxCameraZoom = 10;

    public enum InputState
    {
        none,
        movingCamera,
        selectingAreaStart,
        selectingArea,
        draggingArrow,
    }
    public InputState inputState = InputState.none, savedInputState = InputState.none;

    public bool leftClickDown; // public used by SimulateInputManager
    bool rightClickDown;
    bool twoFingerPressDown;
    public bool ctrlDown; // public used by SimulateInputManager
    public bool dragging; // public used by SimulateInputManager
    bool mobileInputRightClick;
    int multiClickCount = 0;
    [SerializeField] float doubleClickWaitTime;
    [SerializeField] float buttonHoldRepeatDelay = 0.4f;
    bool quarterEditMode;
    [SerializeField] GraphNode cursorNode;
    [SerializeField] SpriteRenderer selectionArea;
    [SerializeField] LayerMask nodesLayer;
    [SerializeField] ContactFilter2D nodesContactFilter;
    [SerializeField] LayerMask ignoreRaycaseLayer;
    [SerializeField] LayerMask UILayer;
    CancellationTokenSource dragTokenSource;
    CancellationTokenSource doubleClickTokenSource;
    [Header("Node Type Buttons")]
    [SerializeField] GameObject nodeInfoPanel;
    [SerializeField] Button noneTypeButton;
    [SerializeField] Button fieldTypeButton;
    [SerializeField] Button breweryTypeButton;
    [SerializeField] Button pubTypeButton;
    [Header("Simulation Controls")]
    [SerializeField] GameObject simulationPanel;
    [SerializeField] Button previousStepButton;
    [SerializeField] Button playButton;
    [SerializeField] Button pauseButton;
    [SerializeField] Button nextStepButton;

    public static GraphInputManager instance { get; private set; }
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
        clickData = new PointerEventData(EventSystem.current);
        UI_RaycastResults = new();
    }
    public void OnPointerMove(InputAction.CallbackContext ctx)
    {
        switch (inputState)
        {
            case InputState.movingCamera:
                {
                    if (!rightClickDown) { inputState = InputState.none; break; }

                    difference = GetMousePosition - transform.position;
                    transform.position = origin - difference;
                    EndlessGrid.instance.UpdateGridPosition();
                    break;
                }
            case InputState.draggingArrow:
                {
                    cursorNode.transform.position = GetMousePosition - cameraOffset;
                    if (!graphManager.MoveCurrentArrow())
                    {
                        inputState = InputState.none;
                    }
                    break;
                }
            case InputState.selectingAreaStart: // waits for the mouse to move past the drag threshold before selecting
                {
                    if (!leftClickDown) { inputState = InputState.none; break; }

                    Vector2 offset = GetMousePosition - origin;
                    if (Mathf.Abs(offset.x) > graphManager.GetDragThresholdValue() || Mathf.Abs(offset.y) > graphManager.GetDragThresholdValue())
                    {
                        Debug.Log("Selecting area");
                        origin -= cameraOffset;
                        selectionArea.transform.position = origin;
                        selectionArea.size = Vector2.zero;
                        selectionArea.enabled = true;
                        dragging = true;
                        inputState = InputState.selectingArea; // continues in the next case
                        break;
                    }
                    break;
                }
            case InputState.selectingArea:
                {
                    difference = (GetMousePosition - cameraOffset) - origin;
                    selectionArea.size = difference;
                    break;
                }
            default: break;
        }
    }
    public void OnLeftClick(InputAction.CallbackContext ctx) // called on left click down and up
    {
#if UNITY_ANDROID
        if (leftClickDown && ctx.control.IsPressed()) { return; }
#endif
        //Debug.Log("IsPointerOverGameObject: " + EventSystem.current.IsPointerOverGameObject());
        leftClickDown = ctx.control.IsPressed(); // check for button state

        rayHits = Physics2D.GetRayIntersectionAll(Camera.main.ScreenPointToRay(Pointer.current.position.ReadValue()), 11f);
        //Debug.Log(EventSystem.current.currentSelectedGameObject);
        if (leftClickDown) // if LMB down and not holding ctrl
        {
            if (HasClickedOverUI()) { return; }
            //if (EventSystem.current.currentSelectedGameObject != null) return;
            multiClickCount++; // keep track of multiple clicks in succession
            if (multiClickCount > 1) // if double click
            {
                multiClickCount = 0; // reset click count
                if (rayHits.Length > 0 && TryGetFirstNodeFromRayHits(out GraphNode node)) // if there's a node on cursor position
                {
                    graphManager.CreateArrowInput(node); // create an arrow
                    Debug.Log("Created arrow input, inputState: " + inputState);
                    inputState = InputState.draggingArrow;
                    Debug.Log("Created arrow input, inputState: " + inputState);
                }
                else
                {
                    if (quarterEditMode)
                    {
                        graphManager.CreateNode(GetMousePosition - cameraOffset, GraphNode.NodeType.cwiartka); // create quarter node on cursor position
                    }
                    else
                    {
                        graphManager.CreateNode(GetMousePosition - cameraOffset); // create node on cursor position
                    }

                    FileGraphConverter.instance.UpdateNeeded();

                    // prevent selection area and creating node simulateously
                    if (inputState == InputState.selectingAreaStart)
                    {
                        inputState = InputState.none;
                        selectionArea.enabled = false;
                    }
                }
            }
            else if (multiClickCount == 1) // if single click
            {
                DoubleClickAsync(); // start tracking time for multi click
                if (rayHits.Length > 0) // if clicked some object
                {
                    //Debug.Log(rayHit.);
                    if (TryGetFirstNodeFromRayHits(out GraphNode node)) // if clicked a node
                    {
                        if (!ctrlDown) // if clicking unselected node without ctrl and not selecting something in UI
                        { if (!graphManager.IsNodeSelected(node)) graphManager.SelectNode(node); } // select the single node, allows for dragging
                        else
                        {
                            graphManager.SelectNode(node, true); // select with multi-select mode
                        }

                        if (graphManager.GetCurrentArrow()) // if there's an unattached arrow
                        {
                            graphManager.ApplyArrow(node); // apply the unattached arrow
                        }
                        else // if there's no unattached arrow
                        {
                            DragNodeAsync(); // drag the node
                        }
                    }
                    else if (TryGetArrowIfFirst(out GraphArrow arrow)) // if clicked an arrow and not selecting something in UI
                    {
                        graphManager.SelectArrow(arrow, ctrlDown);
                    }
                }
                else // clicked empty space
                {
                    origin = GetMousePosition;
                    if (inputState == InputState.none) inputState = InputState.selectingAreaStart;
                }
            }
        }
        else // click up 
        {
            if (dragging) // dragged on click down
            {
                if (inputState == InputState.selectingArea) // selecing area action
                {
                    inputState = InputState.none;
                    if (!ctrlDown)
                    {
                        graphManager.DeselectAllElements();
                    }

                    Debug.Log($"origin: {origin}; difference: {difference}; origin + difference: {origin + difference}");
                    // select all nodes in the selection area:
                    // find all colliders in the selection area
                    Collider2D[] selectedColliders = Physics2D.OverlapAreaAll(origin, origin + difference, nodesLayer);

                    foreach (var col in selectedColliders)
                    {
                        Debug.Log("Selected: " + col.name);
                        graphManager.SelectNode(col.GetComponent<GraphNode>(), true);
                    }
                    selectionArea.enabled = false;
                }
                dragging = false;
            }
            else // if didn't drag
            {
                if (!HasClickedOverUI())
                {
                    if (rayHits.Length > 0) // if clicked something
                    {
                        /*if (rayHit.collider.TryGetComponent(out GraphNode node))
                        {
                            graphManager.SelectNode(node, ctrlDown); // select node
                        }
                        else */

                    }
                    else // if clicked empty space
                    {
                        graphManager.CancelArrow(); // cancel arrow
                        if (!ctrlDown) { graphManager.DeselectAllElements(); } // deselect all nodes (and hide info panel)
                    }
                }
            }
        }
        //#endif
    }
    public void OnRightClick(InputAction.CallbackContext ctx)
    {
        rightClickDown = ctx.control.IsPressed();
        if (rightClickDown)
        {
            if (inputState == InputState.none || inputState == InputState.draggingArrow)
            {
                savedInputState = inputState;
                origin = GetMousePosition;
                inputState = InputState.movingCamera;
            }
        }
        else
        {
            if (inputState == InputState.movingCamera) { inputState = savedInputState; }
        }
    }

    public void OnFirstFingerPress(InputAction.CallbackContext ctx)
    {
        if (mobileInputRightClick)
        {
            OnRightClick(ctx);
        }
        else
        {
            OnLeftClick(ctx);
        }
    }

    public void OnScroll(InputAction.CallbackContext ctx)
    {
        Camera.main.orthographicSize -= Mouse.current.scroll.value.y;
        if (Camera.main.orthographicSize < 1)
        {
            Camera.main.orthographicSize = 1;
        }
        else if (Camera.main.orthographicSize > maxCameraZoom)
        {
            Camera.main.orthographicSize = maxCameraZoom;
        }
        // if the camera's view size is 15 times larger than the grid size, temporarily enlarge the grid scale
        if (EndlessGrid.instance.isActiveAndEnabled)
        {
            while (EndlessGrid.instance.transform.localScale.x * 10f < Camera.main.orthographicSize)
            {
                Debug.Log("grid *= 5f");
                EndlessGrid.instance.transform.localScale = new(EndlessGrid.instance.transform.localScale.x * 5f, EndlessGrid.instance.transform.localScale.y * 5f, 1f);
                gridSizePopupText.SetText(EndlessGrid.instance.transform.localScale.x.ToString());
                gridSizePopupText.gameObject.SetActive(true);
                EndlessGrid.instance.ForceUpdateGridPosition();
            }
            while (EndlessGrid.instance.transform.localScale.x > Camera.main.orthographicSize * 0.6f)
            {
                Debug.Log("grid /= 5f");
                EndlessGrid.instance.transform.localScale = new(EndlessGrid.instance.transform.localScale.x / 5f, EndlessGrid.instance.transform.localScale.y / 5f, 1f);
                gridSizePopupText.SetText(EndlessGrid.instance.transform.localScale.x.ToString());
                gridSizePopupText.gameObject.SetActive(true);
                EndlessGrid.instance.ForceUpdateGridPosition();
            }
        }
        //int multiplier = (int)(Camera.main.orthographicSize / (GraphManager.instance.GetGridSize() * 15f));
        //for(int i=0; i<multiplier; i++)
        //{
        //EndlessGrid.instance.transform.localScale *= 10f;
        //}
    }
    public void OnDelete(InputAction.CallbackContext ctx)
    {
        if (ctx.started && EventSystem.current.currentSelectedGameObject == null) // on press down
        {
            graphManager.DeleteSelected();
        }
    }
    public void OnCtrl(InputAction.CallbackContext ctx)
    {
        ctrlDown = ctx.ReadValueAsButton();
        if (dragging && inputState != InputState.selectingArea) { graphManager.SetSnapToGrid(ctrlDown); }
    }
    public void OnA(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            if (ctrlDown)
            {
                graphManager.SelectAllNodes();
            }
            else
            {
                graphManager.SelectAllArrows();
            }
        }
    }

    public void OnQ(InputAction.CallbackContext ctx)
    {
        if (ctx.started && nodeInfoPanel.activeSelf && noneTypeButton.interactable)
        {
            noneTypeButton.onClick.Invoke();
        }
    }
    public void OnW(InputAction.CallbackContext ctx)
    {
        if (ctx.started && nodeInfoPanel.activeSelf && fieldTypeButton.interactable)
        {
            fieldTypeButton.onClick.Invoke();
        }
    }
    public void OnE(InputAction.CallbackContext ctx)
    {
        if (ctx.started && nodeInfoPanel.activeSelf && breweryTypeButton.interactable)
        {
            breweryTypeButton.onClick.Invoke();
        }
    }
    public void OnR(InputAction.CallbackContext ctx)
    {
        if (ctx.started && nodeInfoPanel.activeSelf && pubTypeButton.interactable)
        {
            pubTypeButton.onClick.Invoke();
        }
    }


    public void OnJ(InputAction.CallbackContext ctx)
    {
        if (ctx.started || ctx.canceled)
        {
            OnRepeatJAsync(ctx.started);
        }
    }
    public void OnK(InputAction.CallbackContext ctx)
    {
        if (ctx.started)
        {
            if (playButton.gameObject.activeSelf)
            {
                playButton.onClick.Invoke();
            }
            else
            {
                pauseButton.onClick.Invoke();
            }

        }
    }
    public void OnL(InputAction.CallbackContext ctx)
    {
        Debug.Log(ctx);
        if (ctx.started || ctx.canceled)
        {
            OnRepeatLAsync(ctx.started);
        }
    }

    public void OnZ(InputAction.CallbackContext ctx)
    {
        if (ctrlDown)
        { 
            if (ctx.started) // after press
            {
                graphManager.UndoLastAction();
            }
            else if (ctx.performed) // after holding
            {
                OnZRepeatAsync();
            }
            else // cancelled
            {
                CancelPreviousAsync(ref doubleClickTokenSource);
            }
        }
    }
    public void OnY(InputAction.CallbackContext ctx)
    {
        if (ctrlDown)
        {
            if (ctx.started) // after press
            {
                graphManager.RedoLastAction();
            }
            else if (ctx.performed) // after holding
            {
                OnYRepeatAsync();
            }
            else // cancelled
            {
                CancelPreviousAsync(ref doubleClickTokenSource);
            }
        }
    }
    public void OnC(InputAction.CallbackContext ctx)
    {
        if (ctrlDown && ctx.started) { graphManager.CopySelected(); }
    }
    public void OnV(InputAction.CallbackContext ctx)
    {
        if (ctrlDown && ctx.started) { graphManager.PasteClipboard(); }
    }
    public void OnD(InputAction.CallbackContext ctx)
    {
        if (ctrlDown && ctx.started) { graphManager.CopySelected(); graphManager.PasteClipboard(); }
    }
    public void OnX(InputAction.CallbackContext ctx)
    {
        if (ctrlDown && ctx.started) { graphManager.CopySelected(); graphManager.DeleteSelected(); }
    }

    public async void DragNodeAsync()
    {
        CancelPreviousAsync(ref dragTokenSource);
        CancellationToken token = dragTokenSource.Token;
        int i;
        bool undoNodes = false;
        bool initialSnapToGrid = graphManager.GetSnapToGrid();
        List<GraphNode> nodesToDrag = graphManager.GetSelectedNodes(); // create list for dragging multiple nodes
        IUndoableAction[] newUndoArray = new IUndoableAction[graphManager.GetSelectedNodes().Count];
        Vector2[] positionsBeforeDrag = new Vector2[nodesToDrag.Count]; // save positions of nodes before dragging
        for (i = 0; i < nodesToDrag.Count; i++) // save initial position of all selected nodes
        {
            // add each node to list of nodes to undo move
            newUndoArray[i] = new UndoMoveNode(nodesToDrag[i]);
            // save each node's original position (before dragging)
            positionsBeforeDrag[i] = nodesToDrag[i].transform.position;
        }
        dragging = false;
        float dragThresholdValue = graphManager.GetDragThresholdValue();
        Vector3 mouseDownPosition = GetMousePosition;
        Vector2 offset;
        
        while (leftClickDown)
        {
            offset = GetMousePosition - mouseDownPosition;
            if (dragging)
            {
                for (i = 0; i < nodesToDrag.Count; i++)
                {
                    nodesToDrag[i].MoveNode(positionsBeforeDrag[i] + offset); // move all selected nodes by offset
                }
                GraphManager.instance.ShowNodeInfo();
            }
            else if (Mathf.Abs(offset.x) > dragThresholdValue || Mathf.Abs(offset.y) > dragThresholdValue)
            { 
                dragging = true;
                undoNodes = true;
            } // don't move node unless dragging
            // move node only when dragged (otherwise it snaps to grid on click)
            
            try { await Awaitable.EndOfFrameAsync(token); } catch { return; }
        }
        if (rightClickDown) // if right click down when stopped dragging
        {
            for (i = 0; i < nodesToDrag.Count; i++)
            {
                nodesToDrag[i].MoveNode(positionsBeforeDrag[i]); // move all selected nodes to their original positions
                undoNodes = false;
            }
        }
        // after dragging:
        dragging = false;
        graphManager.SetSnapToGrid(initialSnapToGrid);
        // only add to undo actions if the position actually changed
        // check only first because all nodes move by the same offset
        if (nodesToDrag.Count > 0 && (Vector2)nodesToDrag[0].transform.position != positionsBeforeDrag[0] && undoNodes) 
        {
            GraphManager.instance.PushStack(GraphManager.instance.undoStack, ref newUndoArray);
            // this method can be called only manually by the user, so
            // clear the redo stack
            GraphManager.instance.redoStack.Clear();
            // signal FileGraphConverter that the graph will need to be converted to text
            FileGraphConverter.instance.UpdateNeeded();
        }

        // check if no nodes collide
        // if nodes collide, make them red color
        foreach (var node in nodesToDrag)
        {
            if (node.GetNodeType() == GraphNode.NodeType.pole)
            {
                node.CheckIfInsideQuarter();
            }
            node.CheckIfCorrectPosition();
        }
    }

    async void DoubleClickAsync()
    {
        CancelPreviousAsync(ref doubleClickTokenSource);
        CancellationToken token = doubleClickTokenSource.Token;
        try { await Awaitable.WaitForSecondsAsync(doubleClickWaitTime, token); } catch { return; }
        multiClickCount = 0;
    }
    public async void OnRepeatJAsync(bool state)
    {
        CancelPreviousAsync(ref doubleClickTokenSource);
        CancellationToken token = doubleClickTokenSource.Token;
        if (state)
        {
            previousStepButton.onClick.Invoke();
            try { await Awaitable.WaitForSecondsAsync(buttonHoldRepeatDelay * 5, token); } catch { return; }
            while (!ctrlDown)
            {
                previousStepButton.onClick.Invoke();
                try { await Awaitable.WaitForSecondsAsync(buttonHoldRepeatDelay, token); } catch { return; }
            }
        }
    }
    public async void OnRepeatLAsync(bool state)
    {
        CancelPreviousAsync(ref doubleClickTokenSource);
        CancellationToken token = doubleClickTokenSource.Token;
        if (state)
        {
            nextStepButton.onClick.Invoke();
            try { await Awaitable.WaitForSecondsAsync(buttonHoldRepeatDelay * 5, token); } catch { return; }
            while (!ctrlDown)
            {
                nextStepButton.onClick.Invoke();
                try { await Awaitable.WaitForSecondsAsync(buttonHoldRepeatDelay, token); } catch { return; }
            }
        }
    }
    async void OnZRepeatAsync()
    {
        CancelPreviousAsync(ref doubleClickTokenSource);
        CancellationToken token = doubleClickTokenSource.Token;
        while (ctrlDown)
        {
            graphManager.UndoLastAction();
            try { await Awaitable.WaitForSecondsAsync(buttonHoldRepeatDelay, token); } catch { return; }
        }
    }
    async void OnYRepeatAsync()
    {
        CancelPreviousAsync(ref doubleClickTokenSource);
        CancellationToken token = doubleClickTokenSource.Token;
        while (ctrlDown)
        {
            graphManager.RedoLastAction();
            try { await Awaitable.WaitForSecondsAsync(buttonHoldRepeatDelay, token); } catch { return; }
        }
    }

    void CancelPreviousAsync(ref CancellationTokenSource tokenSource)
    {
        if (tokenSource != null)
        {
            tokenSource.Cancel();
            tokenSource.Dispose();
        }
        tokenSource = new CancellationTokenSource();
    }

    public void SetMaxCameraZoom(string input)
    {
        if (uint.TryParse(input, out uint newSize))
        {
            maxCameraZoom = newSize;
        }
        else
        {
            maxCameraZoomInputField.text = "10";
        }
    }
    public void SetQuarterEditMode(bool state)
    {
        quarterEditMode = state;
        // if left panel or turned the option off and there are border points without an area
        if (!state && GraphManager.instance.currentQuarter.Count > 0)
        {
            // remove quarter border nodes that haven't created an area
            Debug.Log("Deleted unattached quarter border nodes");
            GraphManager.instance.SelectNode(GraphManager.instance.currentQuarter[0]);
            GraphManager.instance.DeleteSelected();
        }
    }
    public static void SetPasteOffsetX(float newX)
    {
        pasteOffset = new(newX, pasteOffset.y);
    }
    public static void SetPasteOffsetY(float newY)
    {
        pasteOffset = new(pasteOffset.x, newY);
    }
    public void SetMobileInputRightClick(bool state)
    {
        mobileInputRightClick = state;
    }


    public bool HasClickedOverUI()
    {
        // retrieve current mouse position
        clickData.position = Mouse.current.position.ReadValue();
        // clear previous results
        UI_RaycastResults.Clear();
        // instruct the raycaster to cast a ray from current mouse
        // and stores the results in the given array
        graphicRaycaster.Raycast(clickData, UI_RaycastResults);

        // log all the UI elements hit by the ray
        /*foreach (var raycastResult in UI_RaycastResults)
        {
            Debug.Log($"Clicked in UI element: ${raycastResult}");
        }*/

        // return a boolean that will tell us whether at least one
        // UI element has been clicked on 
        return UI_RaycastResults.Count > 0;
    }
    public bool GetQuarterEditModeState() { return quarterEditMode; }
    public bool TryGetFirstNodeFromRayHits(out GraphNode node)
    {
        foreach (var rayHit in rayHits)
        {
            if (rayHit.collider.TryGetComponent(out GraphNode node2))
            {
                node = node2;
                return true;
            }
        }
        node = null;
        return false;
    }
    public bool TryGetArrowIfFirst(out GraphArrow arrow)
    {
        foreach (var rayHit in rayHits)
        {
            if (rayHit.collider.TryGetComponent(out GraphNode node2))
            {
                arrow = null;
                return false;
            }
            else if (rayHit.collider.transform.parent.TryGetComponent(out GraphArrow arrow2))
            {
                arrow = arrow2;
                return true;
            }
        }
        arrow = null;
        return false;
    }
    public LayerMask GetNodesLayer() { return nodesLayer; }
    public ContactFilter2D GetNodesContactFilter() { return nodesContactFilter; }
    public LayerMask GetIgnoreRaycastLayer() { return ignoreRaycaseLayer; }
    public uint GetMaxCameraZoom() { return maxCameraZoom; }
    Vector3 GetMousePosition => Camera.main.ScreenToWorldPoint(Pointer.current.position.ReadValue());


    private void OnApplicationQuit()
    {
        GraphNode.generatingGraph = true;
    }
}
