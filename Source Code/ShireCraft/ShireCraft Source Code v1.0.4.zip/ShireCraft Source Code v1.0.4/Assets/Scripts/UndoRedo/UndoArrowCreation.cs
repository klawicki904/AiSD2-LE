using UnityEngine;

public class UndoArrowCreation : IUndoableAction
{
    // arrows must be searched for by their IDs, 
    // searching by reference causes issues because Redo() creates a new arrow,
    // which is later missing its reference in UndoArrowDeletion
    private readonly int arrowID; 
    private ArrowData arrowData;

    public UndoArrowCreation(GraphArrow arrow)
    {
        arrowID = arrow.arrowID;
    }

    public void Undo()
    {
        Debug.Log(GetType() + ": Undo");
        if (GraphManager.instance.TryGetArrowByID(arrowID, out GraphArrow arrow))
        {
            // remember arrow's data before deleting to undo/redo later
            arrowData = new ArrowData(arrow.GetFromNode().nodeID, arrow.GetToNode().nodeID, arrow.GetFlow(), arrow.GetRepairCost());
            GraphManager.instance.SelectArrow(arrow);
            GraphManager.instance.DeleteSelected(true);
        }
    }
    public void Redo()
    {
        Debug.Log(GetType() + ": Redo");
        // get nodes by their IDs and create an arrow if they exist
        if (GraphManager.instance.TryGetNodeByID(arrowData.from, out var fromNode) &&
            GraphManager.instance.TryGetNodeByID(arrowData.to, out var toNode))
            GraphManager.instance.CreateArrow(fromNode, toNode, arrowData.flow, arrowData.repairCost, true, arrowID);
    }

    class ArrowData
    {
        public int from;
        public int to;
        public float flow;
        public uint repairCost;

        public ArrowData(int from, int to, float flow, uint repairCost)
        {
            this.from = from;
            this.to = to;
            this.flow = flow;
            this.repairCost = repairCost;
        }
    }
}

