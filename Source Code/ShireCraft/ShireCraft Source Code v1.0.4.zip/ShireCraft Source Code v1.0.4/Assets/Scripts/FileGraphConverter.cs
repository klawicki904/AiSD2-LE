using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text;
using System;
using System.IO;
using System.Threading;
using System.Globalization;

public class FileGraphConverter : MonoBehaviour
{
    [SerializeField] TMP_InputField arrowListInputField;
    [SerializeField] TMP_InputField detailedInputField;
    [SerializeField] TMP_InputField conversionRateInputField;
    [SerializeField] TMP_InputField horizontalSpacingInputField;
    [SerializeField] TMP_InputField verticalSpacingInputField;
    [SerializeField] Toggle detailedInputToggle;
    [SerializeField] private GameObject loadingScreenPanel;
    [SerializeField] Button graphTab; // graphTab is opened when starts to load the file
    [SerializeField] Button fileTab; // fileTab is re-opened if the file fails to load
    public static bool inputCorrect = true;

    [Header("Layout Settings")]
    public float horizontalSpacing = 4f;
    public float verticalSpacing = 2f;

    enum GraphInputType
    {
        conversionRate,
        nodes,
        roads,
        quarters
    }
    GraphInputType readingNow;

    private Dictionary<int, GraphNode> nodeTransforms = new();

    [SerializeField] bool updateNeeded;

    public static CancellationTokenSource conversionTokenSource = new();

    public static FileGraphConverter instance { get; private set; }
    private void Awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this);
        }
        else
        {
            instance = this;
        }
        readingNow = GraphInputType.nodes;
    }

    public void UpdateNeeded()
    {
        //Debug.LogWarning((new System.Diagnostics.StackTrace()).GetFrame(1).GetMethod().Name);
        updateNeeded = true;
        OutputFileToSimulationData.instance.ResetSimulation();
        //OutputFileToSimulationData.simulationUpdateNeeded = true;
    }
    public void UpdateNotNeeded()
    {
        updateNeeded = false;
    }
    private class GraphProcessResult
    {
        public List<GraphNodeData> Nodes;
        public List<Arrow> Arrows;
    }

    private class GraphNodeData
    {
        public int Id;
        public Vector3 Position;
        public GraphNodeData(int id, Vector3 pos)
        {
            Id = id;
            Position = pos;
        }
    }

    private class Arrow
    {
        public int from;
        public int to;
        public float flow;
        public Arrow(int _from, int _to, float _flow)
        {
            from = _from;
            to = _to;
            flow = _flow;
        }
    }
    private void OnEnable()
    {
        arrowListInputField.gameObject.SetActive(false);
        
        detailedInputToggle.isOn = true;
    }
    public async void ConvertGraphMain()
    {
        Debug.Log("ConvertGraphMain");
        loadingScreenPanel.SetActive(true); // show loading screen
        //if (!updateNeeded) return;

        // clear the graph of all children (nodes and arrows)
        await ConvertGraphMainAsync();
    }
    async Task ConvertGraphMainAsync()
    {
        CancellationToken token = conversionTokenSource.Token;

        graphTab.onClick.Invoke(); // open the graph tab

        await GraphManager.instance.ClearGraphTask(token);
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.preparing);
        //await GraphManager.instance.ClearGraphTask();

        // check first line to check the format
        int wordsInHeader = FileToTMPInput.GetAutosaveFirstLine().Split(' ').Length;
        Debug.Log("words in header: " + wordsInHeader);

        // convert text to graph depending on format
        if (wordsInHeader == 2)
        {
            ConvertArrowListToGraphAsync(token);
        }
        else
        {
            ConvertDetailedListToGraphAsync(token);
        }
    }

    public async void ConvertArrowListToGraphAsync(CancellationToken token)
    {
        Debug.Log("Converting Arrow list to graph");
        

        string data = FileToTMPInput.GetAutosaveText();

        string[] lines = data.Split(new[] { '\n', '\r' }, System.StringSplitOptions.RemoveEmptyEntries);
        Dictionary<int, GraphNode> nodeObjects = new();
        int i = 0;
        // parse & prepare layout in background thread
        GraphProcessResult result = await Task.Run(() => ProcessArrowListData(lines, token), token);
        /*if (inputCorrect)
        {
            //fileOperationInfoText.SetText(string.Empty);
        }*/
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingGraph);
        if (result == null)
        {
            inputCorrect = false;
            FileOperationInfoText.instance.ShowArrowsParseError();
            loadingScreenPanel.SetActive(false);
            return; 
        }

        Debug.Log("Generating graph from arrow list data");
        // back on main thread: create nodes
        try
        {
            foreach (var node in result.Nodes)
            {
                token.ThrowIfCancellationRequested(); // will stop if cancelled

                GraphNode gNode = GraphManager.instance.CreateNode(node.Position, GraphNode.NodeType.brak, 0f, true);
#if UNITY_EDITOR
                gNode.name = $"Node_{node.Id}";
                //Debug.Log("Created node with id " + node.Id);
#endif
                nodeObjects[node.Id] = gNode;
            i++;
            
                if (i % GraphManager.generationBatching == 0) { await Task.Yield(); } // yield to keep UI responsive
            
            
            }
            await Task.Yield();
        }
        catch (Exception e) { Debug.LogWarning("Error while generating nodes from GraphProcessResult: " + e); return; }
        i = 0;
        
        // create arrows
        try
        {
            foreach (var arrow in result.Arrows)
            {
                token.ThrowIfCancellationRequested();
                Debug.Log($"arrow nr {i}: trying to create an arrow from {arrow.from} to {arrow.to}");
            GraphManager.instance.CreateArrow(
                nodeObjects[arrow.from],
                nodeObjects[arrow.to],
                arrow.flow,
                0,
                true
            );
            i++;
            
                if (i % GraphManager.generationBatching*2 == 0) { await Task.Yield(); } // slow down for large graphs
            }
        }
        catch (Exception e) { Debug.LogWarning("Error while generating arrows from GraphProcessResult: " + e); return; }
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.synchronizing); // update progress text
        GraphToTextConverter.instance.ConvertGraphToText(); // convert graph to detailed list

        loadingScreenPanel.SetActive(false); // hide loading screen

    }

    private GraphProcessResult ProcessArrowListData(string[] lines, CancellationToken token)
    {
        token.ThrowIfCancellationRequested();
        Debug.Log("Preparing Arrow list data");

        List<bool> visited = new();
        List<Arrow> arrows = new();
        Dictionary<int, List<int>> adjacency = new();
        Dictionary<int, Vector3> nodePositions = new();
        try
        {
            string[] header = lines[0].Split(' ');
            int nodeCount = int.Parse(header[0]);
            visited = new(nodeCount);
            for (int i = 0; i < nodeCount; i++)
            {
                visited.Add(false);
            }
            int arrowCount = int.Parse(header[1]);

            /*for (int i = 0; i < nodeCount; i++)
                adjacency[i] = new();*/

            for (int i = 1; i <= arrowCount; i++)
            {
                string[] parts = lines[i].Split(' ');
                int from = int.Parse(parts[0]);
                int to = int.Parse(parts[1]);
                int flow = int.Parse(parts[2]);

                arrows.Add(new Arrow(from, to, flow));
                if (!adjacency.ContainsKey(from)) adjacency[from] = new();
                if (!adjacency.ContainsKey(to)) adjacency[to] = new();
                adjacency[from].Add(to);
            }
        }
        catch (Exception e)
        {
            Debug.LogError(e.Message);
            return null;
        }
        inputCorrect = true;
        


        // assign levels using BFS from source node 0
        Dictionary<int, int> levels = new();
        Queue<int> queue = new();


        
        
        int unvisited = adjacency.Keys.Min();
        //for(int j=0; j<2; j++)
        while (unvisited != -1)
        {
            levels[unvisited] = 0;
            visited[unvisited] = true;
            Debug.Log("starting BFS from " + unvisited);
            queue.Enqueue(unvisited);
            

            while (queue.Count > 0)
            {
                token.ThrowIfCancellationRequested();
                int current = queue.Dequeue();
                foreach (var neighbor in adjacency[current])
                {
                    //Debug.Log("neighbor: " + neighbor);
                    if (!levels.ContainsKey(neighbor))
                    {
                        //Debug.Log("visited neighbor: " + neighbor);
                        visited[neighbor] = true;
                        levels[neighbor] = levels[current] + 1;
                        queue.Enqueue(neighbor);
                    }
                }
            }
            levels[levels.Keys.Max()] = levels.Values.Max() + 1;
            
            // start BFS again from an unvisited node if there are unvisited nodes
            unvisited = -1;
            for (int i = 0; i<visited.Count; i++)
            {
                if (!visited[i]) { unvisited = i; /*Debug.Log("unvisited: " + unvisited);*/ break; }
            }
        }
        

        // group nodes by level
        var nodesByLevel = levels.GroupBy(kvp => kvp.Value)
                                 .ToDictionary(g => g.Key, g => g.Select(kvp => kvp.Key).ToList());

        foreach (var level in nodesByLevel)
        {
            float x = level.Key * horizontalSpacing;
            float yOffset = -(level.Value.Count - 1) * verticalSpacing / 2f;

            for (int i = 0; i < level.Value.Count; i++)
            {
                token.ThrowIfCancellationRequested();
                int nodeId = level.Value[i];
                Vector3 pos = new(x, -(yOffset + i * verticalSpacing), 0);
                nodePositions[nodeId] = pos;
            }
        }

        return new GraphProcessResult
        {
            Nodes = nodePositions.Select(kv => new GraphNodeData(kv.Key, kv.Value)).ToList(),
            Arrows = arrows,
        };
        
    }

    /// <summary>
    /// DETAILED DATA PARSING AND GENERATION
    /// </summary>
    /// <param name="token"></param>












    async void ConvertDetailedListToGraphAsync(CancellationToken token)
    {
        Debug.Log("Converting Detailed list to graph");
        nodeTransforms.Clear();
        GraphNode.generatingGraph = true;
        int currentLine = 0;
        string line = String.Empty;
        float savedGridSize = GraphManager.instance.GetGridSize();
        try
        {
            // variables for use by arrows and StringBuilder
            int parsedNodeID = 0, fromID, toID, arrowsCount = 0;
            float flow, quarterYield = 0;
            uint repairCost;
            readingNow = GraphInputType.quarters;
            //List<Vector2> quarterVertices = new(); // vertices creating a perimeter of a quarter
            //StringBuilder arrowListBuilder = new();
            List<KeyValuePair<int, float>> fields = new(); // store IDs and capacity of fields to convert to edge list later (adding the start node)
            List<int> pubs = new(); // store IDs of pubs to add sink node later
            const Int32 BufferSize = 128;
            GraphManager.instance.SetGridSize(0.01f);
            using (var fileStream = File.OpenRead(FileToTMPInput.autosaveFilePath))
            {
                using var streamReader = new StreamReader(fileStream, Encoding.UTF8, true, BufferSize);

                while ((line = streamReader.ReadLine()) != null)
                {
                    token.ThrowIfCancellationRequested();
                    if (currentLine % GraphManager.generationBatching == 0)
                    {
                        await Task.Yield();
                    }
                    currentLine++;
                    line = line.Trim();
                    if (string.IsNullOrEmpty(line))
                        continue;

                    switch (line.ToUpper())
                    {
                        case "KONWERSJA":
                            {
                                readingNow = GraphInputType.conversionRate;
                                Debug.Log($"readingNow: {readingNow}");
                                continue; // go to next line
                            }
                        case "PUNKTY":
                            {
                                if (readingNow != GraphInputType.conversionRate)
                                {
                                    throw new FormatException("The input file is missing the keyword \"KONWERSJA\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.nodes;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingNodes);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                GraphInputManager.instance.SetQuarterEditMode(false);
                                continue; // go to next line
                            }
                        case "DROGI":
                            {
                                if (readingNow != GraphInputType.nodes)
                                {
                                    throw new FormatException("The input file is missing the keyword \"PUNKTY\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.roads;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingArrows);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                GraphInputManager.instance.SetQuarterEditMode(false);
                                GraphNode.nextID = parsedNodeID + 1; // set the next node ID to be the last of read from file + 1
                                continue; // go to next line
                            }
                        case "CWIARTKI":
                            {
                                if (readingNow != GraphInputType.roads)
                                {
                                    throw new FormatException("The input file is missing the keyword \"DROGI\" or the keywords are in an incorrect order");
                                }
                                readingNow = GraphInputType.quarters;
                                LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.generatingQuarters);
                                await Task.Yield();
                                Debug.Log($"readingNow: {readingNow}");
                                GraphInputManager.instance.SetQuarterEditMode(true);
                                GraphArrow.nextID = arrowsCount; // set the next arrow ID to be the last of read IDs + 1
                                continue; // go to next line
                            }
                        default: break;
                    }

                    string[] parts = line.Split(' ');

                    Debug.Log($"parts.Length: {parts.Length}: {String.Join(" ", parts)}");
                    if (parts.Length == 0) { continue; } // skip empty lines
                    switch (readingNow)
                    {
                        case GraphInputType.conversionRate:
                            {
                                float value = float.Parse(parts[0], CultureInfo.InvariantCulture); // throws exception if value is not a float
                                // make sure the value is in the correct range
                                if (value < 0f) throw new ArgumentOutOfRangeException("breweries conversion rate input value too low");
                                /*if (value > 1f) throw new ArgumentOutOfRangeException("breweries conversion rate input value");*/
                                Debug.Log("parts[0]: " + parts[0]);
                                conversionRateInputField.text = value.ToString("0.##");
                                break;
                            }
                        case GraphInputType.nodes:
                            {
                                // parse node
                                parsedNodeID = int.Parse(parts[0]);
                                float x = float.Parse(parts[1], CultureInfo.InvariantCulture);
                                float y = float.Parse(parts[2], CultureInfo.InvariantCulture);
                                string typeStr = parts[3].ToLower();
                                GraphNode.NodeType type = GraphNode.GetNodeTypeByName(typeStr);

                                float capacity = 0;
                                switch (type)
                                {
                                    case GraphNode.NodeType.browar:
                                        {
                                            capacity = (float)Math.Round(float.Parse(parts[4], CultureInfo.InvariantCulture), 2);
                                            break;
                                        }
                                    default: break;
                                }

                                Vector3 position = new(x, y, 0f);
                                GraphNode node = GraphManager.instance.CreateNode(position, type, capacity, true, parsedNodeID);
#if UNITY_EDITOR
                                //node.name = $"Node_{id}";
                                //Debug.Log("Created node with id " + id);
#endif
                                nodeTransforms[parsedNodeID] = node;
                                break;
                            }
                        case GraphInputType.roads:
                            {
                                // parse arrow
                                fromID = int.Parse(parts[0]);
                                toID = int.Parse(parts[1]);
                                //if (maxID < toID) { maxID = toID; }
                                flow = (float)Math.Round(float.Parse(parts[2], CultureInfo.InvariantCulture), 2);
                                repairCost = uint.Parse(parts[3], CultureInfo.InvariantCulture);
                                GraphNode fromT = nodeTransforms[fromID];
                                GraphNode toT = nodeTransforms[toID];
                                GraphManager.instance.CreateArrow(fromT, toT, flow, repairCost, true);
                                // add arrow data to StringBuilder
                                //arrowListBuilder.Append($"{fromID-1} {toID-1} {flow}\n");
                                arrowsCount++;
                                break;
                            }
                        case GraphInputType.quarters:
                            {
                                quarterYield = (float)Math.Round(float.Parse(parts[0], CultureInfo.InvariantCulture), 2); // get the fields' yield in the quarter
                                // get border points of the quarter
                                for (int p = 1; p < parts.Length; p += 2)
                                {
                                    /*Debug.Log($"p: {p}, p+1: {p + 1}");*/
                                    GraphManager.instance.CreateNode(new(float.Parse(parts[p], CultureInfo.InvariantCulture), float.Parse(parts[p + 1], CultureInfo.InvariantCulture)), GraphNode.NodeType.cwiartka, quarterYield, true);
                                    //.Add(new(float.Parse(parts[p]), float.Parse(parts[p + 1])), CultureInfo.InvariantCulture); 
                                }
                                GraphManager.instance.InitializeQuarterArea();
                                break;
                            }
                        default: break;
                    }
                }
            }
        }
        catch (Exception e)
        {
            inputCorrect = false;
            GraphNode.generatingGraph = false;
            GraphManager.instance.SetGridSize(savedGridSize);
            loadingScreenPanel.SetActive(false); // hide loading screen
            Debug.LogWarning(e.ToString());
            if (e is not OperationCanceledException) // unless the operation was cancelled by user
            {
                FileOperationInfoText.instance.ShowFileParseError(currentLine, line, e.Message); // display the message if File tab
                fileTab.onClick.Invoke(); // open the file tab
            }
            
            return;
        }
        GraphNode.generatingGraph = false;
        GraphManager.instance.SetGridSize(savedGridSize);
        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.verifyingNodes);
        await Task.Yield();
        await GraphManager.instance.CheckAllNodesCorrectPosition(token);

        LoadingScreenText.instance.SetOperationState(LoadingScreenText.OperationState.synchronizing);
        await Task.Yield();
        // successfully generated the graph

        if (!inputCorrect) // if last attempt was incorrect
        {
            //fileOperationInfoText.SetText(string.Empty);
            inputCorrect = true;
        }

        
        //GraphManager.instance.InitializeAllQuarterAreas();
        //FileOperationInfoText.instance.ClearInfoText();
        GraphToTextConverter.instance.ConvertGraphToText();
        //GraphManager.instance.InitializeQuarterEdges();
        GraphManager.instance.DeselectAllElements();
        GraphInputManager.instance.SetQuarterEditMode(false);
        updateNeeded = false;
        loadingScreenPanel.SetActive(false); // hide loading screen
        
    }

    public void CancelPreviousConversion()
    {
        if (conversionTokenSource != null)
        {
            conversionTokenSource.Cancel();
            conversionTokenSource.Dispose();
        }
        conversionTokenSource = new CancellationTokenSource();
        LaunchExternalExecutable.instance.ForceKillRunningPrograms();
        GraphManager.instance.CancelPreviousAsync();
        Debug.Log("FileGraphConverter: Async tasks cancelled.");
        loadingScreenPanel.SetActive(false);
    }


    public void UpdateDetailedList(string graphData)
    {
        detailedInputField.text = graphData;
    }

    public void SetVerticalSpacingFromInput(string input)
    {
        if (float.TryParse(input, out float newSize) && Mathf.Abs(newSize) < 1000f && newSize != 0f)
        {
            verticalSpacing = newSize;
            verticalSpacingInputField.text = newSize.ToString("0.##");
        }
        else // failed to parse - empty string
        {
            verticalSpacingInputField.text = "2";
            verticalSpacingInputField.onDeselect.Invoke(verticalSpacingInputField.text);
        }
    }
    public void SetHorizontalSpacingFromInput(string input)
    {
        if (float.TryParse(input, out float newSize) && Mathf.Abs(newSize) < 1000f && newSize != 0f)
        {
            horizontalSpacing = newSize;
            horizontalSpacingInputField.text = newSize.ToString("0.##");
        }
        else // failed to parse - empty string
        {
            horizontalSpacingInputField.text = "4";
            horizontalSpacingInputField.onDeselect.Invoke(horizontalSpacingInputField.text);
        }
    }
    public bool GetInputCorrect()
    {
        return inputCorrect;
    }
    public bool GetUpdateNeeded()
    {
        return updateNeeded;
    }
}