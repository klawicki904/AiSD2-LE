using UnityEngine;
using TMPro;

public class ArrowInfoPanel : MonoBehaviour
{
    public TMP_InputField flowInputField; 
    public TMP_InputField repairCostInputField;
}
