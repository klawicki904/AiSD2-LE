using UnityEngine;
using UnityEngine.Events;

public class OnActiveChangeUnityEvent : MonoBehaviour
{
    [SerializeField] bool onlyOnEnable = true;
    [SerializeField] bool onlyOnDisable;
    [Tooltip("When enabled, setting object's parent inactive will not trigger OnDisable behavior")]
    [SerializeField] bool explicitlyDisabled;

    [SerializeField] UnityEvent onActiveChange = new();

    private void OnEnable()
    {
        if (!onlyOnDisable)
        {
            onActiveChange.Invoke();
        }
    }
    private void OnDisable()
    {
        if (!onlyOnEnable)
        {
            if (explicitlyDisabled && gameObject.activeSelf) { return; }
            onActiveChange.Invoke();
        }
    }
}
